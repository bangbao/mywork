# coding: utf-8

import json
from django.test import TestCase
from ym.apps.user import logics as user_logics
from ym.apps.perm import logics as perm_logics
from scripts import init_table
from .helper import TestClient


class AdmTests(TestCase):

    def setUp(self):
        user_info = dict(p_id='root1', nickname='root1', email='root@test.com')
        self.user1 = user_logics.create_or_sync_user(user_info)
        self.client = TestClient()
        self.client.login(username='root1')
        perm_logics.sync_perm_config()
        init_table.init_group_perm()
        init_table.init_grouplevel()

    def test_staff_titles(self):
        response = self.client.get('/ym/adm/staff_titles/')
        self.assertEqual(response.data['code'], 0)

        print json.dumps(response.data['result'], ensure_ascii=False)
