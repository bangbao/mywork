# coding: utf-8

from django.test import TestCase
from django.contrib.auth.models import User
from ym.apps.perm import logics as user_level


class UserLevelTests(TestCase):

    def setUp(self):
        self.user1, _ = User.objects.get_or_create(username='root1')
        self.user2, _ = User.objects.get_or_create(username='root2')
        self.user3, _ = User.objects.get_or_create(username='root3')
        self.user4, _ = User.objects.get_or_create(username='root4')
        self.user5, _ = User.objects.get_or_create(username='root5')
        self.user6, _ = User.objects.get_or_create(username='root6')
        self.user7, _ = User.objects.get_or_create(username='root7')

        user_level.create_userlevel(None, self.user1.id)
        user_level.create_userlevel(self.user1.id, self.user2.id)
        user_level.create_userlevel(self.user1.id, self.user3.id)
        user_level.create_userlevel(self.user3.id, self.user4.id)
        user_level.create_userlevel(self.user3.id, self.user6.id)

    def test_get_parent_uids(self):
        diff_uids = [self.user1.id, self.user3.id]
        parent_uids = user_level.get_parent_uids(self.user4.id)
        self.assertSetEqual(set(diff_uids), set(parent_uids))

    def test_get_child_uids(self):
        diff_uids = [self.user4.id, self.user6.id]
        child_uids = user_level.get_child_uids(self.user3.id)
        self.assertSetEqual(set(diff_uids), set(child_uids))

    def test_create_userlevel(self):
        user_level.create_userlevel(self.user4.id, self.user5.id)

        diff_childs = [self.user2.id, self.user3.id, self.user4.id,
                       self.user5.id, self.user6.id]
        child_uids = user_level.get_child_uids(self.user1.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_parents = [self.user1.id, self.user3.id, self.user4.id]
        parent_uids = user_level.get_parent_uids(self.user5.id)
        self.assertSetEqual(set(diff_parents), set(parent_uids))

    def test_change_userlevel(self):
        user_level.change_userlevel(self.user2.id, self.user6.id)

        diff_childs = [self.user6.id]
        child_uids = user_level.get_child_uids(self.user2.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_childs = [self.user4.id]
        child_uids = user_level.get_child_uids(self.user3.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_parents = [self.user1.id, self.user2.id]
        parent_uids = user_level.get_parent_uids(self.user6.id)
        self.assertSetEqual(set(diff_parents), set(parent_uids))

    def test_delete_userlevel(self):
        user_level.delete_userlevel(self.user3.id, total=True)

        diff_childs = [self.user2.id]
        child_uids = user_level.get_child_uids(self.user1.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))


def main():
    #     user_level.create_userlevel(None, 1)
    #     user_level.create_userlevel(1, 2)
    #     user_level.create_userlevel(1, 3)
    #     user_level.create_userlevel(1, 4)
    #     user_level.create_userlevel(3, 7)
    #     user_level.create_userlevel(4, 8)
    #     user_level.create_userlevel(4, 9)
    #     user_level.create_userlevel(7, 10)
    #     user_level.create_userlevel(10, 11)
    #     user_level.create_userlevel(1, 12)

    print 'child1', user_level.get_child_uids(3)
    print 'child2', user_level.get_child_uids(2)
    user_level.change_userlevel(2, 7)
    print 'child1', user_level.get_child_uids(3)
    print 'child2', user_level.get_child_uids(2)
    # print 'child2', user_level.get_child_uids(3)
    # print 'parent', user_level.get_parent_uids(3)


if __name__ == '__main__':
    main()
