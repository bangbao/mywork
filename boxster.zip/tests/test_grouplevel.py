# coding: utf-8

from django.test import TestCase
from ym.apps.perm.models import Group, GroupLevel
from ym.apps.perm import logics as perm_logics


class GroupLevelTests(TestCase):

    def setUp(self):
        self.group1 = perm_logics.add_group_perm('group1')
        self.group2 = perm_logics.add_group_perm('group2')
        self.group3 = perm_logics.add_group_perm('group3')
        self.group4 = perm_logics.add_group_perm('group4')
        self.group5 = perm_logics.add_group_perm('group5')
        self.group6 = perm_logics.add_group_perm('group6')

        perm_logics.create_grouplevel(None, self.group1.id)
        perm_logics.create_grouplevel(self.group1.id, self.group2.id)
        perm_logics.create_grouplevel(self.group1.id, self.group3.id)
        perm_logics.create_grouplevel(self.group3.id, self.group4.id)
        perm_logics.create_grouplevel(self.group3.id, self.group6.id)

    def test_show_grouplevel(self):
        r1 = Group.objects.values()
        r2 = GroupLevel.objects.values()
        print r1
        print r2

    def test_get_grouplevel_all(self):
        result = perm_logics.get_grouplevel_all()
        ids = [obj['id'] for obj in result]
        check_ids = [self.group1.id, self.group2.id, self.group3.id,
                     self.group4.id, self.group6.id]
        self.assertListEqual(ids, check_ids)

    def test_get_grouplevel_parents(self):
        group_id = self.group6.id
        result = set(perm_logics.get_grouplevel_parents(group_id))
        check_ids = set([self.group1.id, self.group3.id])
        self.assertSetEqual(result, check_ids)

    def test_get_grouplevel_childs(self):
        group_id = self.group1.id
        result = set(perm_logics.get_grouplevel_childs(group_id))
        check_ids = set([self.group2.id, self.group3.id, self.group4.id,
                         self.group6.id])
        self.assertSetEqual(result, check_ids)

    def test_get_grouplevel_childs_depth(self):
        group_id = self.group1.id
        result = set(perm_logics.get_grouplevel_childs(group_id, 1))
        check_ids = set([self.group2.id, self.group3.id])
        self.assertSetEqual(result, check_ids)

    def test_create_grouplevel(self):
        perm_logics.create_grouplevel(self.group4.id, self.group5.id)

        diff_childs = [self.group2.id, self.group3.id, self.group4.id,
                       self.group5.id, self.group6.id]
        child_uids = perm_logics.get_grouplevel_childs(self.group1.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_parents = [self.group1.id, self.group3.id, self.group4.id]
        parent_uids = perm_logics.get_grouplevel_parents(self.group5.id)
        self.assertSetEqual(set(diff_parents), set(parent_uids))

    def test_change_grouplevel(self):
        perm_logics.change_grouplevel(self.group2.id, self.group6.id)

        diff_childs = [self.group6.id]
        child_uids = perm_logics.get_grouplevel_childs(self.group2.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_childs = [self.group4.id]
        child_uids = perm_logics.get_grouplevel_childs(self.group3.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))

        diff_parents = [self.group1.id, self.group2.id]
        parent_uids = perm_logics.get_grouplevel_parents(self.group6.id)
        self.assertSetEqual(set(diff_parents), set(parent_uids))

    def test_delete_grouplevel(self):
        perm_logics.delete_grouplevel(self.group3.id, total=True)

        diff_childs = [self.group2.id]
        child_uids = perm_logics.get_grouplevel_childs(self.group1.id)
        self.assertSetEqual(set(diff_childs), set(child_uids))
