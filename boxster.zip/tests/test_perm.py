# coding: utf-8

import json

from django.core.urlresolvers import reverse
from django.test import TestCase
from django.contrib.auth.models import User
from ym.apps.perm import consts as perm_consts
from ym.apps.perm import logics as perm_logics
from ym.apps.perm.models import (
    Perm, Group, GroupPerm
)


class PermTests(TestCase):

    def setUp(self):
        self.user, _ = User.objects.get_or_create(username='root',
                                                  is_active=True,
                                                  is_staff=True)
        self.perm_manager = self.user.perm_manager

        add_objs = [Perm(codename=k, name=v)
                    for _, (k, v) in enumerate(perm_consts.PERMS.iteritems())]
        Perm.objects.bulk_create(add_objs)
        perm_logics.add_group_perm(u'测试分组1',
                                   [perm_consts.PERM_POTENTIAL_LIST])
        perm_logics.add_group_perm(u'测试分组2',
                                   [perm_consts.PERM_POTENTIAL_LIST])
        perm_logics.add_group_perm(u'测试分组3',
                                   [perm_consts.PERM_APPOINT_ADVISOR])

    def test_add_group_perm(self):
        perm_logics.add_group_perm(u'测试分组4',
                                   [perm_consts.PERM_POTENTIAL_ADD])

        group_id = Group.objects.get(name=u'测试分组4').id
        perm_ids = [obj.perm_id
                    for obj in GroupPerm.objects.filter(group_id=group_id)]
        self.assertListEqual([perm_consts.PERM_POTENTIAL_ADD], perm_ids)

    def test_change_group_perm(self):
        group_id = Group.objects.get(name=u'测试分组1').id
        perm_logics.change_group_perm(group_id, [perm_consts.PERM_POTENTIAL_ADD])

        perm_ids = [obj.perm_id
                    for obj in GroupPerm.objects.filter(group_id=group_id)]
        self.assertListEqual([perm_consts.PERM_POTENTIAL_ADD], perm_ids)

    def test_change_user_group(self):
        user_id = self.user.id
        group_names = [u'测试分组1', u'测试分组2']
        group_ids = [obj.id
                     for obj in Group.objects.filter(name__in=group_names)]
        perm_logics.change_user_group(user_id, group_ids=group_ids)

        result = [obj.group_id for obj in self.user.related_usergroup.all()]
        self.assertListEqual(group_ids, result)

    def test_change_user_perm(self):
        user_id = self.user.id
        perm_ids = set([perm_consts.PERM_POTENTIAL_ADD,
                        perm_consts.PERM_POTENTIAL_EDIT])
        perm_logics.change_user_perm(user_id, perm_ids)

        result = set([obj.perm_id for obj in self.user.related_userperm.all()])
        self.assertSetEqual(perm_ids, result)

    def test_perm_manager(self):
        user_id = self.user.id
        group_names = [u'测试分组2', u'测试分组3']
        group_ids = [obj.id
                     for obj in Group.objects.filter(name__in=group_names)]
        perm_logics.change_user_group(user_id, group_ids)
        perm_logics.change_user_perm(user_id, [perm_consts.PERM_POTENTIAL_ADD])

        user_perms = set([
            perm_consts.PERM_POTENTIAL_ADD,
        ])
        self.assertSetEqual(user_perms, self.perm_manager.get_user_perms())

        group_perms = set([
            perm_consts.PERM_POTENTIAL_LIST,
            perm_consts.PERM_APPOINT_ADVISOR,
        ])
        self.assertSetEqual(group_perms, self.perm_manager.get_group_perms())

        all_perms = set([
            perm_consts.PERM_POTENTIAL_LIST,
            perm_consts.PERM_APPOINT_ADVISOR,
            perm_consts.PERM_POTENTIAL_ADD,
        ])
        self.assertSetEqual(all_perms, self.perm_manager.get_all_perms())

        has_perm1 = self.perm_manager.has_perm(perm_consts.PERM_POTENTIAL_ADD)
        non_perm2 = self.perm_manager.has_perm(perm_consts.PERM_POTENTIAL_EDIT)
        self.assertTrue(has_perm1)
        self.assertFalse(non_perm2)
        print self.perm_manager.get_all_perms()

        perm_logics.set_user_super(self.user)
        self.perm_manager = self.user.perm_manager
        non_perm2 = self.perm_manager.has_perm(perm_consts.PERM_POTENTIAL_EDIT)
        self.assertTrue(non_perm2)
        print self.perm_manager.get_all_perms()


def test():
    u = User.objects.get(id=2)
    user_id = u.id
    ugpm = u.perm_manager

    # perm_logics.add_group_perm(u'测试分组1',
    #                            [perm_consts.PERM_POTENTIAL_LIST])
    # perm_logics.add_group_perm(u'测试分组2',
    #                            [perm_consts.PERM_POTENTIAL_LIST])
    # perm_logics.add_group_perm(u'测试分组3',
    #                            [perm_consts.PERM_APPOINT_ADVISOR])
    # perm_logics.add_group_perm(u'测试分组4',
    #                            [perm_consts.PERM_POTENTIAL_ADD])
    # print
    #
    # group_id = Group.objects.get(name=u'测试分组1').id
    # perm_logics.change_group_perm(group_id, [perm_consts.PERM_POTENTIAL_ADD])
    # print
    #
    # group_ids = [obj.id for obj in Group.objects.filter(
    #              name__in=[u'测试分组1', u'测试分组2'])]
    # perm_logics.change_user_group(user_id, group_ids=group_ids)
    # print
    #
    # perm_ids = [perm_consts.PERM_POTENTIAL_ADD,
    #             perm_consts.PERM_POTENTIAL_EDIT]
    # perm_logics.change_user_perm(user_id, perm_ids)
    # print

    print ugpm.get_user_perms()
    print
    print ugpm.get_group_perms()
    print
    print ugpm.get_all_perms()


def test_compare_user_perm_old2new():
    from django.contrib.auth.models import User
    from ym.apps.perm import manager as perm_manager
    from ym.apps.perm import consts as perm_consts
    from ym.apps.user import logics as user_logics
    from ym.apps.user.models import Users

    has_perm = perm_manager.has_perm
    compare_funcs = [
        (perm_consts.PERM_POTENTIAL_LIST, user_logics.had_advisor_potentials_perm),
        (perm_consts.PERM_APPOINT_ADVISOR, user_logics.had_appoint_advisor_perm),
        (perm_consts.PERM_POTENTIAL_ADD, user_logics.had_potential_add_perm),
        (perm_consts.PERM_POTENTIAL_EDIT, user_logics.had_potential_edit_perm),
        (perm_consts.PERM_MOBILE_VIEW, user_logics.can_see_mobile_perm),
        (perm_consts.PERM_POTENTIAL_VIEW, user_logics.can_see_all_potential_perm),
    ]

    for user in User.objects.all():
        if not Users.objects.filter(uid=user.id).exists():
            continue
        print
        print user.id, user.users.user_name
        for perm, perm_func in compare_funcs:
            print perm, perm_func(user) == has_perm(user, perm)

        if user_logics.is_super_user(user):
            print 'is_super', user.perm_manager.is_super()


if __name__ == '__main__':
    test()
