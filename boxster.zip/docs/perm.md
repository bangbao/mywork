
### 管理后台接口文档

`测试地址: http://ymtest.shunshunliuxue.com`
<br/>
`正式地址: http://ym.shunshunliuxue.com`


#### 权限列表
+ Request
`GET /ym/perm/perm_list/`


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": [
        {
            "codename": "advisor_potentials",
            "name": "资源面板"
        },
        {
            "codename": "appoint_advisor",
            "name": "转资源"
        },
    ],
}
```


#### 权限分组列表
+ Request
`GET /ym/perm/group_list/`


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": [
        {
            "id": 1,
            "name": "超级用户"
        }
    ],
}
```


#### 权限分组详情
+ Request
`GET /ym/perm/group_info/`
```
    group_id: 权限分组id
```


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": {
        "group_perms": [
            {
                "codename": "is_super",
                "name": "超级用户"
            }
        ],
        "id": 1,
        "name": "超级用户"
    }
}
```


#### 权限分组编辑
+ Request
`POST /ym/perm/group_edit/`
```
    group_id: 权限分组id
    name: 权限分组name
    group_perms: [codename, codename]
```


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": {
        "group_perms": [
            {
                "codename": "is_super",
                "name": "超级用户"
            }
        ],
        "id": 1,
        "name": "超级用户"
    }
}
```


#### 权限分组添加
+ Request
`POST /ym/perm/group_add/`
```
    name: 权限分组name
    group_perms: [codename, codename]
```


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": 'ok'
}
```


#### 权限分组删除
+ Request
`DELETE /ym/perm/group_delete/`
```
    group_id: 权限分组id
```


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": 'ok'
}
```

