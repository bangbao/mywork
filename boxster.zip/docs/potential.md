## 准则

- 遵循restful
- 所有资源包含创建时间，修改时间
"create_at":1457496551000,
"modify_at":1457496609000
- 资源有复数，则api使用复数形式
- 所有populate的字段需要提供主键

## Advisor_potential
资源操作

### 新增资源数据 [/ym/advisor_potential_add/]

+ Request
    `POST /ym/advisor_potential_add/`
```
    {
        "full_name":"",             // 姓名  必填
        "mobile": "",               // 电话  与微信二选一
        "wechat": "",               // 微信  与电话二选一
        "countries_programs": [     // 申请的国家项目列表数据  选填
            {"country": "美国",      // 申请国家名
             "has_visa": true,      // 是否该国签证
             "programs": [          // 申请的项目们
                 {"program": "技术移民"},   // 项目名
                 {"program": "投资移民"},   // 项目名
             ],
            },
        ],
        "expendable_fund": "",      // 可用资金  选填 默认为0
        "gross_assets": "",         // 总资产    选填 默认为0
        "rate": "",                 // 用户星级  必填
        "bm_experience": "",        // 商业管理经验
        "comefrom": "",             // 来源, 选填
        "xifenqudao": "",           // 细分渠道, 选填
        "qudao_details": "",        // 渠道详情, 选填
        "follow_persion": "",       // 指定顾问, 选填
    }
```

+ Response 201 (application/json)
```
    {
        "result": "success",
        "alert_msg": u"有撞单风险",       //为空时不提示消息
    }
```


### 国家项目关联列表 [/ym/countries_programs/]

+ Request
    `GET /ym/countries_programs/`


+ Response 200 (application/json)
```
{
    "result": [
        {
            "text": "美国",
            "value": "美国",
            "programs": [
                {
                    "text": "投资EB-5",
                    "value": "投资EB-5"
                },
                {
                    "text": "家庭团聚",
                    "value": "家庭团聚"
                },
            ]
        },
    ]
}
```


#### 更新资源 [PUT]

+ Request
    `PUT /ym/advisor_potentials/101/`
```
        {
            "qq": "13414134",
            "email": "xxx@xxx.com"
        }
```

+ Response 200 (application/json)
```
        {
            "result":{
                "id":64516,
                "create_at":1457496551000,
                "full_name":"苏缨翔",
                "mobile":"15291871217",
                "phone":"15291871217",
                "other_phone": "15291871217"
                "follow_status":"未跟进", // 未跟进，为联系上，无效放弃
                "rate":1,
                "qq": "13412341",
                "marital_status": "未婚", // 未婚，已婚，已婚离异
                "linguistic_competence": "初级", // 初级，中级，高级
                "comefrom":"集团渠道",
                "email": "xxx@xxx.com",
                "remarks":[
                    {
                        "id":298692,
                        "create_at":1457496609000,
                        "modify_at":1457496609000,
                        "content":"回访内容：学生信息！！！希望老师有传媒类的，华威，谢大的案例最好了！1.学生是西北大学，传媒专业，g点81分，硕士，大二，去英国，211，不是985，目标想去华威，谢大，考虑找机构，老师可以好好联系下，学生会雅思考完了以后见面聊聊的，之前有咨询过威久留学！2.谢谢老师了，辛苦了！微信：15291871217！",
                        "created_by": {
                            "id": 123,
                            "nickname": "abc"
                        } // 创建者
                    }
                ],
                "applied_countries": [
                    {
                        "id": 3456,
                        "country": "美国",
                        "has_visa": true,
                        "has_relatives": false,
                        "type": 1, // 1 首选国家，0 候选国家
                        "create_at":1457496551000,
                        "modify_at":1457496609000
                    }
                ],
                "applied_programs": [
                    {
                        "id": 434,
                        "program": "技术移民", // 技术移民，投资移民
                        "type": 1, // 1 首选国家，0 候选国家
                        "create_at":1457496551000,
                        "modify_at":1457496609000
                    }
                ]
            }
        }
```

#### 获取单个资源 [GET]

+ Request
`GET /ym/advisor_potentials/101/`


+ Response 200 (application/json)
```
{
    "result":{
        "id":64516,
        "create_at":1457496551000,
        "full_name":"苏缨翔",
        "mobile":"15291871217",
        "phone":"15291871217",
        "other_phone": "15291871217"
        "follow_status":"未跟进", // 未跟进，为联系上，无效放弃
        "rate":1,
        "qq": "13412341",
        "marital_status": "未婚", // 未婚，已婚，已婚离异
        "linguistic_competence": "初级", // 初级，中级，高级
        "comefrom":"集团渠道",
        "email": "xxx@xxx.com",
        "remarks":[
            {
                "id":298692,
                "create_at":1457496609000,
                "modify_at":1457496609000,
                "content":"回访内容：学生信息！！！希望老师有传媒类的，华威，谢大的案例最好了！1.学生是西北大学，传媒专业，g点81分，硕士，大二，去英国，211，不是985，目标想去华威，谢大，考虑找机构，老师可以好好联系下，学生会雅思考完了以后见面聊聊的，之前有咨询过威久留学！2.谢谢老师了，辛苦了！微信：15291871217！",
                "created_by": {
                    "id": 123,
                    "nickname": "abc"
                } // 创建者
            }
        ],
        "applied_countries": [
            {
                "id": 1234,
                "country": "美国",
                "has_visa": true,
                "has_relatives": false,
                "type": 1, // 1 首选国家，0 候选国家
                "create_at":1457496551000,
                "modify_at":1457496609000
            }
        ],
        "applied_programs": [
            {
                "id": 434,
                "program": "技术移民", // 技术移民，投资移民
                "type": 1, // 1 首选项目，0 候选项目
                "create_at":1457496551000,
                "modify_at":1457496609000
            }
        ],
         "countries_programs": [
            {
                "id": 58,
                "create_at": 1459474718000,
                "modify_at": 1459474718000,
                "country": "阿尔巴尼亚",
                "has_visa": false,
                "has_relatives": null,
                "type": 1,
                "potential_id": 47,
                "advisor_uid": 6,
                "student_uid": null,
                "programs": [
                  {
                    "id": 26,
                    "create_at": 1459474718000,
                    "modify_at": 1459474718000,
                    "country": "阿尔巴尼亚",
                    "program": "置业护照",
                    "type": 1,
                    "potential_id": 47,
                    "advisor_uid": 6,
                    "student_uid": null
                  }
                ]
            }
        ]
    }
}
```


#### 新增国家项目 [POST]

+ Request
    `POST /ym/potential_countries_programs/`
```
{
  "potential_id": 60,           // 资源id
  "has_visa": true,             // 是否签证
  "country": "英国4",            // 国家名字
  "programs": [                 // 新申请的项目名
    {
      "program": "技术移民5"
    }
  ]
}
```

+ Response 200 (application/json)
```
{
    "result": "success"
}
```


#### 修改国家项目 [POST]

+ Request
`POST /ym/potential_countries_programs/<国家ID>/`
```
{
  "potential_id": 60,           // 资源id
  "has_visa": true,             // 是否签证
  "programs": [                 // 新申请的项目名, 可不传
    {
      "program": "技术移民5"
    }
  ]
}
```

+ Response 200 (application/json)
```
{
    "result": "success"
}
```


#### 删除国家 [DELETE]

+ Request
`DELETE /ym/potential_applied_countries/<国家ID>/`

+ Response 200 (application/json)
```
{
    "result": "success"
}
```


#### 删除项目 [DELETE]

+ Request
`DELETE /ym/potential_applied_programs/<项目ID>/`

+ Response 200 (application/json)
```
{
    "result": "success"
}
```


###  移民推送留学页面数据

+ Request
    `GET /ym/potential/push_to_crp_info/`
```
    potential_id: 资源id
```

+ Response 200 (application/json)
```
{
    "code": 0,
    "result": {
        "mobile": "18673212466",
        "educations": [
            {
                "text": "夏校",
                "value": "夏校"
            }
        ],
        "countries": [
            {
                "text": "瑞士",
                "value": "瑞士"
            },
            {
                "text": "挪威",
                "value": "挪威"
            }
        ],
        "id": 137,
        "full_name": "肖鹰翼"
    }
}
```


###  移民推送留学页面数据

+ Request
    `POST /ym/potential/push_to_crp/`
```
{
    "potential_id": 137,        # 资源ID
    "full_name": "张先生",       # 资源姓名
    "mobile": "18911001212",    # 手机号
    "country": "瑞士",           # 留学国家
    "education": "夏校",         # 留学项目
    "planning_year": "",        # 留学时间
    "remark": "",               # 备注 非必填
    "follow_person": "王硕",     # 指定顾问 非必填
}
```

+ Response 200 (application/json)
```
{
    "code": 0,
    "result": 'ok'
}
```


###  移民获取留学备注

+ Request
    `GET /ym/potential/get_crp_remarks/`
```
    potential_id: 资源id
```

+ Response 200 (application/json)
```
{
    "code": 0,
    "result": {
        "remarks": [                        # 备注
            {
                "content": "hello 137",
                "create_at": 1466136364000
            }
        ],
        "follow_person": "王争",          # 跟进顾问
        "follow_status": "未跟进"          # 跟进状态
    }
}
```

