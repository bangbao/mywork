
#### CRP资源推送 [POST]

`测试地址: http://ymtest.shunshunliuxue.com`
`正式地址: http://ym.shunshunliuxue.com`

+ Request
`POST /ym/crp_potential_user/`
```
{
    "advisor_id": 6,               // 顾问ID
    "advisor_name": 6,             // 顾问名
    "potential_id": 41,            // 资源ID
    "name": "移民测试",              // 姓名
    "mobile": "12345678910",       // 电话
    "phone": null,                 // 座机
    "other_phone": null,           // 其他电话
    "qq": null,                    // QQ
    "email": null,                 // 电子邮箱
    "wechat": "ceshi5",            // 微信
    "advisor_city": "北京分公司",    // 所属分公司
    "comefrom": "在线资源",          // 来源
    "xifenqudao": "线上预约",        // 细分渠道
    "qudao_details": "测试",        // 渠道详情
    "country": "美国",              // 移民申请国家
    "program": "项目名",            // 项目名
    "gross_assets": 123,           // 总资产
    "expendable_fund": 12          // 可用资金
    "bm_experience": 12,           // 商业管理经验
    "rate": 3,                     // 客户星级
}
```

+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": "该资源已存在，无法推送",        // 失败原因或者具体内容
}
```


#### CRP获取对应资源信息 [GET]
+ Request
`GET /ym/crp_potential_info/`
```
    potential_id: crp资源id
```

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": {
        "remarks": [                                // 备注列表
          {
            "id": 18,
            "create_at": 1459503986000,
            "modify_at": 1459503986000,
            "potential_id": 47,
            "advisor_uid": 6,
            "student_uid": null,
            "content": "hello——来自顾问 游客41258",
            "bi_user_id": null,
            "ipaddr": null
          }
        ],
        "follow_status": "客户了解阶段",              // 跟进状态
        "follow_person": "张伟"                     // 跟进顾问
        "potential_id": 48,                        // crp资源id
    }
}
```


#### CRP获取下拉选项数据 [GET]
+ Request
`GET /ym/crp_option_info/`

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": {
        "countries_programs": [                     // 数据项目关联数据
            {
                "text": "澳洲",
                "value": "澳洲",
                "programs": [
                    {
                        "text": "商业居留许可",
                        "value": "商业居留许可"
                    }
                ]
            }
        ],
        "rates": [                                // 星级
            {
                "text": 5,
                "value": 5
            }
        ],
        "bm_experiences": [                       // 商业管理经历
            {
                "text": "股东",
                "value": "股东"
            }
        ]
    }
}
```


