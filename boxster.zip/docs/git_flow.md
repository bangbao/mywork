##工作流程


####初始化项目。我在我原来的git项目上执行以下命令来进行初始化
```
git flow init
```


### 它会创建或转换一个新的版本分支结构，当然在初始化的过程中，会问到以下这边问题，全部选择默认
```
Which branch should be used for bringing forth production releases?
   - master
Branch name for production releases: [master]
Branch name for "next release" development: [develop]

How to name your supporting branch prefixes?
Feature branches? [feature/]
Release branches? [release/]
Hotfix branches? [hotfix/]
Support branches? [support/]
Version tag prefix? []
```

### 增加一个功能特性
```
git flow feature start demo
```
它会基于develop创建一个分支feature/demo，并切换到该分支。
当功能完成：
```
git flow feature finish demo
```
它会有feature/demo分支合并到develop分支，然后切换回develop分支，并删除feature/demo分支。

功能完成，要合并到主分支，这时可以执行
```
git flow release start v0.7.0
```
它会基于develop创建一个release/v0.7.0分支，并切换到该分支。
然后在这里进行测试。如果测试没问题，则执行以下命令：
```
git flow release finish v0.7.0
```
它会将release/v0.7.0分支的内容合并到master分支和develop分支，并且打上tag v0.7.0，然后删除release/v0.7.0分支。


### 修复一个bug。
