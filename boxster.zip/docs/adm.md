
### 管理后台接口文档

`测试地址: http://ymtest.shunshunliuxue.com`
<br/>
`正式地址: http://ym.shunshunliuxue.com`


#### 员工分公司列表
+ Request
`GET /ym/adm/staff_attributions/`


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": [
        {
            "text": "北京市",
            "value": "北京市"
        },
        {
            "text": "武汉市",
            "value": "武汉市"
        }
    ],
}
```


#### 员工国家列表
+ Request
`GET /ym/adm/staff_countries/`


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": [
        {
            "text": "美国",
            "value": "美国"
        },
        {
            "text": "英国",
            "value": "英国"
        }
    ],
}
```


#### 员工岗位列表
+ Request
`GET /ym/adm/staff_titles/`


+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": [
        {'text': '顾问' 'value': '顾问',
        'levels': [{'name': '陈麒冲', 'uid': 1},
                  {'name': '智慧', 'uid': 2}]},
        {'text': '业务副总裁' 'value': '业务副总裁',
         'levels': [{'name': '陈麒冲', 'uid': 1}]}
    ],
}
```


#### 员工列表
+ Request
`GET /ym/adm/staff_list/`
```
    filters: {} (optional, json字符串) // key为
             attribution: 列表, title:文本, country: 列表
    keywords: - 搜索关键词，多个词用空格隔开
    page: 分页页数
    length: 每页长度
```

+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": {
        "dlist": [
            {
            "uid": 123,                # 员工UID
            "sysid": "100260",         # 员工编号
            "levels": [                # 员工角色
                "北京市总经理",
                "集团澳洲总监"
            ],
            "level_uid": 30,            # 上级领导uid
            "attribution": "",          # 分公司
            "name": "陈瑞华",            # 员工姓名
            "title": "北京分公司总经理"    # 岗位
            "country" "",               # 国家
            }
        ],        # 员工列表
        "page": 1,          # 当前页数
        "count" 10,         # 每页数量
}
```


#### 单个员工信息
+ Request
`GET /ym/adm/staff_info/`
```
    uid: 员工uid
```

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": {
        "uid": 123,                # 员工UID
        "sysid": "100260",         # 员工编号
        "levels": [                # 员工角色
            "北京市总经理",
            "集团澳洲总监"
        ],
        "level_uid": 30,            # 上级领导uid
        "attribution": "",          # 分公司
        "name": "陈瑞华",            # 员工姓名
        "title": "北京分公司总经理"    # 岗位
        "country": "",             # 国家
        "perms": [                             # 所有的权限值
            {
                "k": "adm",       # 权限codename
                "v": false,       # 权限值
                "n": "用户管理",    # 权限中文说明
                "p": [...],       # 子级权限, 为null表示没有
            },
            {
                "k": "perm",
                "v": false,
                "n": "权限管理",
                "p": [...],
            }
        ],
    }
}
```


#### 设定员工权限
+ Request
`POST /ym/adm/staff_set_perm/`
```
{
    uid: 员工uid
    user_perms: [codename, codename],   # 权限codename列表
    title: 岗位
    level_uid: 上级领导uid
}
```

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": {
        "uid": 123,                # 员工UID
        "sysid": "100260",         # 员工编号
        "levels": [                # 员工角色
            "北京市总经理",
            "集团澳洲总监"
        ],
        "attribution": "",          # 分公司
        "name": "陈瑞华",            # 员工姓名
        "title": "北京分公司总经理"    # 岗位
        "country": "",             # 国家
        "perms": [                       # 所有的权限值
            {
                "k": "adm",       # 权限codename
                "v": false,       # 权限值
                "n": "用户管理",    # 权限中文说明
                "p": [...],       # 子级权限, 为null表示没有
            },
            {
                "k": "perm",
                "v": false,
                "n": "权限管理",
                "p": [...],
            }
        ]
    }
}
```


#### 员工激活列表
+ Request
`GET /ym/adm/staff_active_list/`
```
    filters: {} (optional, json字符串) // key为
             attribution: 列表, title:文本, country: 列表
    keywords: - 搜索关键词，多个词用空格隔开
    page: 分页页数
    length: 每页长度
```

+ Response 200/400 (application/json)
```
{
    "code": 0,                            // 0为成功,其它失败
    "result": {
        "dlist": [
            {
            "uid": 123,                 # 员工UID
            "mobile": "100260",         # 手机号
            "user_name": "陈瑞华",       # 员工姓名
            "email": "北京分公司总经理"    # 邮件
            }
        ],        # 员工列表
        "page": 1,          # 当前页数
        "count" 10,         # 每页数量
}
```


#### 员工激活
+ Request
`POST /ym/adm/staff_active/`
```
{
    uid: 员工uid
    title: 岗位
    level_uid: 上属领导uid, 即是levels里的uid
}
```

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": "ok"
}
```


#### 员工冻结
+ Request
`POST /ym/adm/staff_freeze/`
```
{
    uid: 员工uid
}
```

+ Response 200/400 (application/json)
```
{
    "code": 0,
    "result": "ok"
}
```
