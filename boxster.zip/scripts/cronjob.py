# coding: utf-8

import os
import datetime
import tempfile
import xlwt
from django.conf import settings
from django.utils import timezone
from shunlib.utilities import mail
from shunlib.utilities import mytime
from shunlib.utilities.decorators import cronjob_decorator
from . import utils


@cronjob_decorator
def crp2ym_potential_count():
    """crp推送资源数量每日统计
    """
    from ym.apps.potential.models import Advisor_potential_student

    now = datetime.datetime.now()
    objs = Advisor_potential_student.objects.filter(source='crp')

    result = {}
    count = 0
    for obj in objs:
        tuijian_branch = obj.tuijian_branch
        result.setdefault(tuijian_branch, 0)
        result[tuijian_branch] += 1
        count += 1

    subject = u'CRP推送资源数每日统计'
    row0 = [u'序号', u'分公司', u'推送资源数量']
    trows = [utils.make_thead(row0)]
    for idx, (depart, num) in enumerate(sorted(result.iteritems(),
                                               key=lambda x: x[1],
                                               reverse=True)):
        values = [idx + 1, depart, num]
        trows.append(utils.make_trow(values))
    table = utils.make_table(trows)

    tables = [
        u'统计时间: {}'.format(now),
        u'CRP推送资源数: {}<br/>'.format(count),
        u'分公司推送资源数量统计:',
        table,
    ]
    message = utils.make_html(tables)

    if settings.DEBUG:
        print message
        print 'DEBUG mode, break to send mail'
    else:
        to_addrs = ['wardzhang@shunshunliuxue.com',
                    'liuyonghong@sihaiyimin.com',
                    'charleswu@shunshunliuxue.com',
                    'duzhang@shunshunliuxue.com',
                    'matthewliu@shunshunliuxue.com']
        mail.send_mail(subject, message, to_addrs)


@cronjob_decorator
def sync_user_employee_info():
    """同步用户员工人事数据
    """
    from shunlib.employee import get_employee_info
    from ym.apps.user.models import Users

    for users in Users.objects.filter(sysid__isnull=True):
        result = get_employee_info(users.dtp_id)
        if not result:
            print 'employee none: {}-{}'.format(users.uid, users.user_name)
            continue
        need_save = users.update_data(result)
        if need_save:
            users.sync_time = timezone.now()
            users.save()


@cronjob_decorator
def export_s1_potential():
    """每日发送s1资源反馈日报
    """
    from ym.apps.potential.models import (Advisor_potential_student,
                                          Advisor_student_country,
                                          Advisor_student_program,
                                          Advisor_student_remark)

    now = datetime.datetime.now()
    yestoday = now - datetime.timedelta(days=1)
    datetime_begin = yestoday.replace(hour=0, minute=0, second=0, microsecond=0)
    datetime_end = now.replace(hour=0, minute=0, second=0, microsecond=0)
    datetime_begin = timezone.make_aware(datetime_begin)
    datetime_end = timezone.make_aware(datetime_end)
    xifenqudaos = ('S1',)
    potential_query = Advisor_potential_student.objects.filter(
        xifenqudao__in=xifenqudaos).filter(create_at__gte=datetime_begin,
                                           create_at__lt=datetime_end)
    potential_ids = [obj.id for obj in potential_query]

    countrys_data = {}
    programs_data = {}
    remarks_data = {}
    for obj in Advisor_student_country.objects.filter(potential_id__in=potential_ids):
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.filter(potential_id__in=potential_ids):
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    for obj in Advisor_student_remark.objects.filter(potential_id__in=potential_ids):
        remarks_data.setdefault(obj.potential_id, {})[obj.id] = obj

    result = {}
    for obj in potential_query:
        potential_id = obj.id
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        remark_data = remarks_data.get(potential_id, {})
        create_at = mytime.format_utc_datetime(obj.create_at)
        xifenqudao = obj.xifenqudao
        row = [obj.full_name, obj.mobile, create_at,
               '', '', '', obj.follow_person, xifenqudao]
        if country_data:
            country_list = []
            program_list = []
            for country, _obj in country_data.iteritems():
                country_list.append(country)
                programs = program_data.get(country, {})
                if programs:
                    for program, _obj in programs.iteritems():
                        program_list.append(program)
            row[3] = ','.join(country_list)
            row[4] = ','.join(program_list)
        if remark_data:
            remark_list = []
            for rid, obj in sorted(remark_data.iteritems(),
                                   key=lambda x: x[1].create_at, reverse=True):
                create_at = mytime.format_utc_datetime(obj.create_at)
                remark = u'%s at %s' % (obj.content, create_at)
                remark_list.append(remark)
                break
            row[5] = '\n\n'.join(remark_list)
        result[potential_id] = row

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'S1渠道资源日报', cell_overwrite_ok=True)
    row0 = (u'姓名', u'电话', u'录入日期', u'国家', u'项目', u'备注信息', u'指定顾问',
            u'细分渠道')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(tempfile.gettempdir(), u'S1渠道资源日报.xls')
    f.save(filename)

    subject = u'S1渠道资源日报'
    tables = [
        u'统计时间: {}'.format(now),
    ]
    message = utils.make_html(tables)

    if settings.DEBUG:
        print message
        print 'DEBUG mode, break to send mail'
    else:
        to_addrs = ['mktbd@sihaiyimin.com',
                    'wardzhang@shunshunliuxue.com']
        mail.send_mail(subject, message, to_addrs, attachments=[filename])


@cronjob_decorator
def export_s3_potential():
    """每周一发送s3资源反馈日报
    """
    from ym.apps.potential.models import (Advisor_potential_student,
                                          Advisor_student_country,
                                          Advisor_student_program,
                                          Advisor_student_remark)

    now = datetime.datetime.now()
    last_monday = now - datetime.timedelta(days=now.weekday() + 7)
    datetime_begin = last_monday.replace(hour=0, minute=0, second=0, microsecond=0)
    datetime_end = datetime_begin + datetime.timedelta(days=7)
    datetime_begin = timezone.make_aware(datetime_begin)
    datetime_end = timezone.make_aware(datetime_end)
    xifenqudaos = ('S3',)
    potential_query = Advisor_potential_student.objects.filter(
        xifenqudao__in=xifenqudaos).filter(create_at__gte=datetime_begin,
                                           create_at__lt=datetime_end)
    potential_ids = [obj.id for obj in potential_query]

    countrys_data = {}
    programs_data = {}
    remarks_data = {}
    for obj in Advisor_student_country.objects.filter(potential_id__in=potential_ids):
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.filter(potential_id__in=potential_ids):
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    for obj in Advisor_student_remark.objects.filter(potential_id__in=potential_ids):
        remarks_data.setdefault(obj.potential_id, {})[obj.id] = obj

    result = {}
    for obj in potential_query:
        potential_id = obj.id
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        remark_data = remarks_data.get(potential_id, {})
        create_at = mytime.format_utc_datetime(obj.create_at)
        xifenqudao = obj.xifenqudao
        row = [obj.full_name, obj.mobile, create_at,
               '', '', '', obj.follow_person, xifenqudao]
        if country_data:
            country_list = []
            program_list = []
            for country, _obj in country_data.iteritems():
                country_list.append(country)
                programs = program_data.get(country, {})
                if programs:
                    for program, _obj in programs.iteritems():
                        program_list.append(program)
            row[3] = ','.join(country_list)
            row[4] = ','.join(program_list)
        if remark_data:
            remark_list = []
            for rid, obj in sorted(remark_data.iteritems(),
                                   key=lambda x: x[1].create_at, reverse=True):
                create_at = mytime.format_utc_datetime(obj.create_at)
                remark = u'%s at %s' % (obj.content, create_at)
                remark_list.append(remark)
                break
            row[5] = '\n\n'.join(remark_list)
        result[potential_id] = row

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'S3渠道资源日报')
    row0 = (u'姓名', u'电话', u'录入日期', u'国家', u'项目', u'备注信息', u'指定顾问',
            u'细分渠道')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(tempfile.gettempdir(), u'S3渠道资源日报.xls')
    f.save(filename)

    subject = u'S3渠道资源日报'
    tables = [
        u'统计时间: {}'.format(now),
    ]
    message = utils.make_html(tables)

    if settings.DEBUG:
        print message
        print 'DEBUG mode, break to send mail'
    else:
        to_addrs = ['mktbd@sihaiyimin.com',
                    'wardzhang@shunshunliuxue.com']
        mail.send_mail(subject, message, to_addrs, attachments=[filename])


@cronjob_decorator
def trans_invalid_potential():
    """自动把废弃资源转给特定顾问
    """
    from ym.apps.potential import logics as potential_logics

    potential_logics.auto_trans_invaild_potential()


@cronjob_decorator
def export_week_potential():
    """每周五12点把上周新进资源导出给mktbd
    """
    from ym.apps.option import logics as option_logics
    from ym.apps.potential.models import (Advisor_potential_student,
                                          Advisor_student_remark,
                                          Advisor_student_country,
                                          Advisor_student_program)

    now = datetime.datetime.now()
    last_monday = now - datetime.timedelta(days=7)
    datetime_begin = last_monday.replace(hour=12, minute=0, second=0, microsecond=0)
    datetime_end = datetime_begin + datetime.timedelta(days=7)
    datetime_begin = timezone.make_aware(datetime_begin)
    datetime_end = timezone.make_aware(datetime_end)
    potential_query = Advisor_potential_student.objects.filter(
        create_at__gte=datetime_begin,
        create_at__lt=datetime_end)
    potential_ids = [obj.id for obj in potential_query]

    countrys_data = {}
    programs_data = {}
    remark_data = {}
    follow_status_data = {}
    status_data = {}
    source_data = {
        'online': u'移民录入',
        'crp': u'留学推送',
        'crm': u'CRM推送',
    }
    for obj in Advisor_student_country.objects.filter(potential_id__in=potential_ids):
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.filter(potential_id__in=potential_ids):
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    for obj in Advisor_student_remark.objects.filter(
            potential_id__in=potential_ids).order_by('-create_at'):
        remark_data.setdefault(obj.potential_id, []).append(obj)

    for obj in option_logics.get_follow_statuses_list():
        follow_status_data[obj['value']] = obj['text']

    for obj in option_logics.get_statuses_list():
        status_data[obj['value']] = obj['text']

    result = {}
    for obj in potential_query:
        country = ','.join(countrys_data.get(obj.id, []))
        source = source_data[obj.source]
        create_at = mytime.format_utc_datetime(obj.create_at, fmt='%Y-%m-%d')
        full_name = None
        mobile = None
        remark = None
        last_follow_person = None
        if obj.follow_person == 'mktbd':
            last_follow_person_query = obj.audit_log.values_list(
                'follow_person').order_by('-action_id')
            for fp in last_follow_person_query:
                if fp[0] != obj.follow_person:
                    last_follow_person = fp[0]
                    break
            if not last_follow_person:
                print obj.id, last_follow_person_query
            full_name = obj.full_name
            mobile = obj.mobile
            if obj.id in remark_data:
                remark_obj = remark_data[obj.id][0]
                remark_create_at = mytime.format_utc_datetime(remark_obj.create_at)
                remark = u'%s at %s' % (remark_obj.content, remark_create_at)
        follow_status = follow_status_data[int(obj.follow_status)]
        status = status_data.get(obj.status, None)
        result[obj.id] = [obj.id, source, create_at, country, obj.comefrom,
                          obj.xifenqudao, obj.follow_person, last_follow_person,
                          follow_status, status,
                          obj.tuijian_name, obj.tuijian_branch,
                          full_name, mobile, remark]

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'每周移民资源导出表')
    row0 = [u'客户ID', u'资源来源路径', u'录入日期', u'申请国家', u'来源', u'细分渠道',
            u'跟进顾问', u'上个跟进顾问', u'跟进状态', u'资源状态',
            u'推荐人姓名', u'推荐人所属分公司', u'姓名', u'电话', u'最新备注']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(tempfile.gettempdir(), u'每周移民资源导出表.xls')
    f.save(filename)

    subject = u'每周移民资源导出表'
    tables = [
        u'统计时间: {}'.format(now),
    ]
    message = utils.make_html(tables)

    if settings.DEBUG:
        print message
        print 'DEBUG mode, break to send mail'
    else:
        to_addrs = ['mktbd@sihaiyimin.com',
                    'wardzhang@shunshunliuxue.com']
        mail.send_mail(subject, message, to_addrs, attachments=[filename])


if __name__ == '__main__':
    crp2ym_potential_count()
