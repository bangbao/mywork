# coding: utf-8

import os
import time
import xlwt
from collections import defaultdict


def export_potential_attribution(f):
    """地区属性资源数量趋势图
    """
    from ym.models import Advisor_potential_student

    objs = Advisor_potential_student.objects.all()
    date = time.strftime('%Y-%m-%d')

    result = {}
    for obj in objs:
        data = result.setdefault(obj.attribution, defaultdict(int))
        data['date'] = date
        data['attribution'] = obj.attribution
        data['total'] += 1
        rate_key = 'rate_{}'.format(obj.rate or 1)
        data[rate_key] += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'地区属性资源数量趋势图', cell_overwrite_ok=True)
    row0 = [u'日期', u'客户所在地', u'资源数量', u'一级数量', u'二级数量', u'三级数量',
            u'四级数量', u'五级数量']
    keys = ('date', 'attribution', 'total', 'rate_1', 'rate_2', 'rate_3',
            'rate_4', 'rate_5')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, data in sorted(result.iteritems()):
        row += 1
        for col, key in enumerate(keys):
            sheet1.write(row, col, data.get(key))

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_country(f):
    """国家资源数量趋势图
    """
    from ym.models import (Advisor_potential_student,
                                          Advisor_student_country)

    potential_query = Advisor_potential_student.objects.all()
    all_potential_ids = [obj.id for obj in potential_query]
    countrys = Advisor_student_country.objects.filter(
        potential_id__in=all_potential_ids)
    date = time.strftime('%Y-%m-%d')

    countrys_data = {}
    for obj in countrys:
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    result = {'': [date, '', 0]}
    for obj in potential_query:
        potential_id = obj.id
        country_data = countrys_data.get(potential_id)
        if country_data:
            for country, _cobj in country_data.iteritems():
                data = result.setdefault(country, [date, country, 0])
                data[2] += 1
        else:
            result[''][2] += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'国家资源数量趋势图', cell_overwrite_ok=True)
    row0 = [u'日期', u'国家', u'申请资源数']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, data[col])

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_program(f):
    """项目资源数量趋势图
    """
    from ym.models import Advisor_student_country_program_list
    from ym.models import (Advisor_potential_student,
                                          Advisor_student_country,
                                          Advisor_student_program)

    potential_query = Advisor_potential_student.objects.all()
    date = time.strftime('%Y-%m-%d')

    countrys_data = {}
    programs_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.all():
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    result = {}
    for obj in potential_query:
        potential_id = obj.id
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        if country_data:
            for country, _obj in country_data.iteritems():
                result.setdefault(country, {})
                programs = program_data.get(country, {})
                if programs:
                    for program, _obj in programs.iteritems():
                        result[country].setdefault(program, [date, country, program, 0])
                        result[country][program][3] += 1
                else:
                    result[country].setdefault('', [date, country, '', 0])
                    result[country][''][3] += 1
        else:
            result.setdefault('', {}).setdefault('', [date, '', '', 0])
            result[''][''][3] += 1

    # country_program_query = Advisor_student_country_program_list.objects.all()
    # result = {}
    # result.setdefault('', {}).setdefault('', {'total': 0})
    # for obj in country_program_query:
    #     result.setdefault(obj.country, {}).setdefault(obj.program, {'total': 0})
    #     result.setdefault(obj.country, {}).setdefault('', {'total': 0})

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'项目资源数量趋势图', cell_overwrite_ok=True)
    row0 = [u'日期', u'国家', u'项目', u'申请资源数']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        for (_, col_list) in sorted(data.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, col_list[col])

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_program_info(f):
    """申请项目明细表
    只排列有项目的资源
    """
    from django.conf import settings
    from ym.models import (Advisor_potential_student,
                                          Advisor_student_country,
                                          Advisor_student_program)

    potential_query = Advisor_potential_student.objects.all()

    countrys_data = {}
    programs_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.all():
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    result = {}
    for obj in potential_query:
        potential_id = obj.id
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        create_at = obj.create_at.strftime('%Y-%m-%d %H:%M:%S')
        row = ['', '', potential_id, obj.full_name,
               obj.rate, obj.attribution, create_at,
               obj.follow_person]
        if country_data:
            for country, _obj in country_data.iteritems():
                row[1] = country
                result.setdefault(country, {})
                programs = program_data.get(country, {})
                if programs:
                    for program, _obj in programs.iteritems():
                        result[country].setdefault(program, [])
                        row[0] = program
                        result[country][program].append(row)
                else:
                    result[country].setdefault('', []).append(row)
        else:
            result.setdefault('', {}).setdefault('', []).append(row)

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'申请项目明细表', cell_overwrite_ok=True)
    row0 = (u'申请项目', u'申请国家', u'资源ID', u'资源名称', u'资源等级', u'客户地区',
            u'资源录入时间', u'留学顾问')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        for (_, data2) in sorted(data.iteritems()):
            for col_list in sorted(data2):
                row += 1
                for col, _ in enumerate(row0):
                    sheet1.write(row, col, col_list[col])

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_follow_status(f):
    """顾问跟进数量趋势图
    """
    from django.conf import settings
    from ym.models import Advisor_potential_student

    objs = Advisor_potential_student.objects.all()
    date = time.strftime('%Y-%m-%d')

    result = {}
    for obj in objs:
        follow_person = obj.follow_person
        data = result.setdefault(follow_person, [date, follow_person, 0, 0, 0])
        data[2] += 1
        if obj.follow_status == 66:
            data[4] += 1
        else:
            data[3] += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'顾问跟进数量趋势图', cell_overwrite_ok=True)
    row0 = [u'日期', u'顾问姓名', u'客户数量', u'未签约数量', u'已签约数量']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, col_list) in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, col_list[col])

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_tuijian(f):
    """北京留学顾问推荐资源数量表
    """
    from ym.models import Advisor_potential_student

    objs = Advisor_potential_student.objects.filter(crp_potential_id__gte=1)

    result = {}
    for obj in objs:
        tuijian_branch = obj.tuijian_branch or ''
        tuijian_name = obj.tuijian_name or ''
        tuijian_country = obj.country or ''

        data = result.setdefault(tuijian_branch, {}).setdefault(
            tuijian_name, {}).setdefault(tuijian_country,
                                         [tuijian_branch, tuijian_name, tuijian_country, 0])
        data[3] += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'北京留学顾问推荐资源数量表', cell_overwrite_ok=True)
    row0 = [u'分公司', u'留学顾问', u'国家', u'推荐数量']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data1) in sorted(result.iteritems()):
        for (_, data2) in sorted(data1.iteritems()):
            for (_, data3) in sorted(data2.iteritems()):
                row += 1
                for col, _ in enumerate(row0):
                    sheet1.write(row, col, data3[col])

    # filename = os.path.join(settings.PROJECT_DIR, u'地区属性资源数量趋势图.xls')
    # f.save(filename)


def export_potential_all():
    from django.conf import settings
    from ym.models import Advisor_potential_student

    potential_query = Advisor_potential_student.objects.all()

    result = {}
    for obj in potential_query:
        result[obj.id] = [obj.id, obj.full_name, obj.mobile, obj.attribution,
                          obj.follow_person]

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'无客户所在地资源表', cell_overwrite_ok=True)
    row0 = [u'资源ID', u'资源姓名', u'电话', u'客户所在地区', u'跟进顾问']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(settings.PROJECT_DIR, u'无客户所在地资源表.xls')
    f.save(filename)


def export_crp_zhuangdan_baobiao(delete_res=False):
    """与crp撞单报表
    """
    from django.conf import settings
    from shunlib import crp
    from shunlib.utilities import mytime
    from ym.apps.crm.models import ResourceToCrm
    from ym.apps.potential.models import Advisor_potential_student

    result = {}
    need_delete_res_mobiles = []
    for obj in ResourceToCrm.objects.filter(flag=2):
        mobile = obj.mobile
        print obj.name, obj.mobile
        try:
            potential_obj = Advisor_potential_student.objects.get(mobile=mobile)
        except Advisor_potential_student.DoesNotExist:
            need_delete_res_mobiles.append(mobile)
            print 'ym mobile {} not exists'.format(mobile)
            continue
        crp_info = crp.get_potential_by_mobile(mobile)
        if not crp_info:
            print 'crp mobile: {} not exists'.format(mobile)
            continue

        obj_create_at = mytime.format_utc_datetime(potential_obj.create_at)
        crp_create_at = mytime.strftime2dt(crp_info['create_at'],
                                           '%Y-%m-%dT%H:%M:%SZ')
        crp_create_at = mytime.format_utc_datetime(crp_create_at)
        result[potential_obj.id] = [
            potential_obj.id, potential_obj.full_name, potential_obj.mobile,
            potential_obj.follow_person, potential_obj.xifenqudao,
            obj_create_at,
            crp_info['potential_id'], crp_info['name'], crp_info['mobile'],
            crp_info['advisor_name'], crp_info['xifenqudao'],
            crp_create_at,
        ]

    if delete_res and need_delete_res_mobiles:
        print 'delete res_mobiles: {}'.format(need_delete_res_mobiles)
        ResourceToCrm.objects.filter(flag=2,
                                     mobile__in=need_delete_res_mobiles).delete()

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'移民疑似撞单报表')
    row0 = [u'移民资源ID', u'移民客户姓名', u'移民客户手机号码', u'移民顾问',
            u'移民细分渠道', u'移民资源录入时间', u'留学资源ID', u'留学客户姓名',
            u'留学客户手机号码', u'留学顾问', u'留学细分渠道', u'留学资源录入时间']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(settings.PROJECT_DIR, u'移民疑似撞单报表.xls')
    f.save(filename)


def export_potential_all_by_zhangmoran():
    from django.conf import settings
    from shunlib.utilities import mytime
    from ym.apps.option import logics as option_logics
    from ym.apps.potential.models import (Advisor_potential_student,
                                          Advisor_student_country,
                                          Advisor_student_program)

    potential_query = Advisor_potential_student.objects.all()
    potential_ids = [obj.id for obj in potential_query]

    countrys_data = {}
    programs_data = {}
    follow_status_data = {}
    status_data = {}
    source_data = {
        'online': u'移民录入',
        'crp': u'留学推送',
        'crm': u'CRM推送',
    }
    for obj in Advisor_student_country.objects.filter(potential_id__in=potential_ids):
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.filter(potential_id__in=potential_ids):
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    for obj in option_logics.get_follow_statuses_list():
        follow_status_data[obj['value']] = obj['text']

    for obj in option_logics.get_statuses_list():
        status_data[obj['value']] = obj['text']

    result = {}
    for obj in potential_query:
        country = ','.join(countrys_data.get(obj.id, []))
        source = source_data[obj.source]
        create_at = mytime.format_utc_datetime(obj.create_at, fmt='%Y-%m-%d')
        last_follow_person = None
        if obj.follow_person == 'mktbd':
            last_follow_person_query = obj.audit_log.values_list(
                'follow_person').order_by('-action_id')
            for fp in last_follow_person_query:
                if fp[0] != obj.follow_person:
                    last_follow_person = fp[0]
                    break
            if not last_follow_person:
                print obj.id, last_follow_person_query
        follow_status = follow_status_data[int(obj.follow_status)]
        status = status_data.get(obj.status, None)

        result[obj.id] = [obj.id, source, create_at, country, obj.comefrom,
                          obj.xifenqudao, obj.follow_person, last_follow_person,
                          follow_status, status,
                          obj.tuijian_name, obj.tuijian_branch]

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'移民资源导出表')
    row0 = [u'客户ID', u'资源来源路径', u'录入日期', u'申请国家', u'来源', u'细分渠道',
            u'跟进顾问', u'上个跟进顾问', u'跟进状态', u'资源状态',
            u'推荐人姓名', u'推荐人所属分公司']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(settings.PROJECT_DIR, u'移民资源导出表.xls')
    f.save(filename)


def export_data():
    from django.conf import settings

    f = xlwt.Workbook()
    export_potential_attribution(f)
    export_potential_country(f)
    export_potential_program(f)
    export_potential_program_info(f)
    export_potential_follow_status(f)
    export_potential_tuijian(f)

    filename = os.path.join(settings.PROJECT_DIR, u'移民导出数据.xls')
    f.save(filename)


def export_potential_all_by_sunjun():
    """export_potential_all_by_sunjun
    """
    import datetime
    import tempfile
    from django.conf import settings
    from shunlib.utilities import mail
    from shunlib.utilities import mytime
    from . import utils
    from ym.apps.option import logics as option_logics
    from ym.apps.potential.models import (Advisor_potential_student,
                                          Advisor_student_remark,
                                          Advisor_student_country,
                                          Advisor_student_program)

    now = datetime.datetime.now()
    potential_query = Advisor_potential_student.objects.filter(
        tuijian_name=u'孙军')
    potential_ids = [obj.id for obj in potential_query]

    countrys_data = {}
    programs_data = {}
    remark_data = {}
    follow_status_data = {}
    status_data = {}
    for obj in Advisor_student_country.objects.filter(potential_id__in=potential_ids):
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.filter(potential_id__in=potential_ids):
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    for obj in Advisor_student_remark.objects.filter(
            potential_id__in=potential_ids).order_by('-create_at'):
        remark_data.setdefault(obj.potential_id, []).append(obj)

    for obj in option_logics.get_follow_statuses_list():
        follow_status_data[obj['value']] = obj['text']

    for obj in option_logics.get_statuses_list():
        status_data[obj['value']] = obj['text']

    result = {}
    for obj in potential_query:
        create_at = mytime.format_utc_datetime(obj.create_at, fmt='%Y-%m-%d')
        remark = None
        if obj.id in remark_data:
            remark_obj = remark_data[obj.id][0]
            remark_create_at = mytime.format_utc_datetime(remark_obj.create_at)
            remark = u'%s at %s' % (remark_obj.content, remark_create_at)
        follow_status = follow_status_data[int(obj.follow_status)]
        status = status_data.get(obj.status, None)
        result[obj.id] = [obj.full_name, obj.mobile, create_at, obj.follow_person,
                          follow_status, status, remark]

    f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'孙军推荐资源导出表')
    row0 = [u'姓名', u'电话', u'录入日期', u'跟进顾问', u'跟进状态', u'资源状态',
            u'最新备注']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for _, row_data in sorted(result.iteritems()):
        row += 1
        for col, _ in enumerate(row0):
            sheet1.write(row, col, row_data[col])

    filename = os.path.join(tempfile.gettempdir(), u'孙军推荐资源导出表.xls')
    f.save(filename)

    subject = u'孙军推荐资源导出表'
    tables = [
        u'统计时间: {}'.format(now),
    ]
    message = utils.make_html(tables)

    if settings.DEBUG:
        print message
        print 'DEBUG mode, break to send mail'
    else:
        to_addrs = [# 'mktbd@sihaiyimin.com',
                    'wardzhang@shunshunliuxue.com']
        mail.send_mail(subject, message, to_addrs, attachments=[filename])


if __name__ == '__main__':
    export_data()
