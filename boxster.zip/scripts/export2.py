# coding: utf-8

import os
import time
import xlwt


def export_potential_follow_status(f):
    """资源阶段情况汇总
    """
    from ym.models import (Advisor_potential_student,
                           Advisor_student_follow_status_list)

    follow_status_map = dict(
        [(obj.value, obj.text)
         for obj in Advisor_student_follow_status_list.objects.all()]
    )
    potential_query = Advisor_potential_student.objects.all()

    total = 0
    result = {}
    for obj in potential_query:
        follow_person = obj.follow_person
        follow_status = int(obj.follow_status)
        follow_text = follow_status_map[follow_status]
        data = result.setdefault(follow_person, {}).setdefault(
            follow_text, [follow_person, follow_text, 0])
        data[2] += 1
        total += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'资源阶段情况汇总', cell_overwrite_ok=False)
    row0 = [u'顾问姓名', u'跟进状态', u'资源数量']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data1) in sorted(result.iteritems()):
        for _, data2 in sorted(data1.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, data2[col])

    sheet1.write(row + 1, 1, 'TOTAL')
    sheet1.write(row + 1, 2, total)


def export_potential_program_rate(f):
    """国家投资资源情况
    """
    from ym.models import (Advisor_potential_student,
                           Advisor_student_country,
                           Advisor_student_program)

    potential_query = Advisor_potential_student.objects.all()

    countrys_data = {}
    programs_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.all():
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    result = {}
    total = 0
    for obj in potential_query:
        potential_id = obj.id
        rate = obj.rate or 1
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        had_touzi = False
        if country_data:
            for country, _obj in country_data.iteritems():
                programs = program_data.get(country, {})
                if u'投资移民' in programs:
                    had_touzi = True
                    row = result.setdefault(country, {}).setdefault(
                        rate, [country, rate, 0])
                    row[2] += 1
                    total += 1
                    break
        if not had_touzi:
            row = result.setdefault('', {}).setdefault(
                rate, ['', rate, 0])
            row[2] += 1
            total += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'国家投资资源情况', cell_overwrite_ok=True)
    row0 = (u'国家投资移民', u'星级', u'数量')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        for (_, data2) in sorted(data.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, data2[col])

    sheet1.write(row + 1, 1, 'TOTAL')
    sheet1.write(row + 1, 2, total)


def export_potential_country_rate(f):
    """国家资源情况
    """
    from ym.models import (Advisor_potential_student,
                           Advisor_student_country)

    potential_query = Advisor_potential_student.objects.all()

    countrys_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    result = {}
    total = 0
    for obj in potential_query:
        potential_id = obj.id
        rate = obj.rate or 1
        country_data = countrys_data.get(potential_id)
        if country_data:
            for country, _cobj in country_data.iteritems():
                row = result.setdefault(country, {}).setdefault(
                    rate, [country, rate, 0])
                row[2] += 1
                total += 1
        else:
            row = result.setdefault('', {}).setdefault(
                rate, ['', rate, 0])
            row[2] += 1
            total += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'国家资源情况', cell_overwrite_ok=True)
    row0 = [u'国家', u'星级', u'数量']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        for (_, data2) in sorted(data.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, data2[col])

    sheet1.write(row + 1, 1, 'TOTAL')
    sheet1.write(row + 1, 2, total)


def export_potential_follow_person(f):
    """顾问资源情况
    """
    from ym.models import Advisor_potential_student, Advisor_student_country

    potential_query = Advisor_potential_student.objects.all()
    countrys_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    result = {}
    total = 0
    for obj in potential_query:
        follow_person = obj.follow_person
        potential_id = obj.id
        country_data = countrys_data.get(potential_id)
        if country_data:
            for country, _cobj in country_data.iteritems():
                row = result.setdefault(follow_person, {}).setdefault(
                    country, [follow_person, country, 0])
                row[2] += 1
                total += 1
        else:
            row = result.setdefault(follow_person, {}).setdefault(
                '', [follow_person, '', 0])
            row[2] += 1
            total += 1
    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'顾问资源情况', cell_overwrite_ok=False)
    row0 = [u'顾问姓名', u'申请国家', u'资源数量']
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data1) in sorted(result.iteritems()):
        for _, data2 in sorted(data1.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, data2[col])

    sheet1.write(row + 1, 1, 'TOTAL')
    sheet1.write(row + 1, 2, total)


def export_potential_follow_country(f):
    """顾问投资资源情况
    """
    from ym.models import (Advisor_potential_student,
                           Advisor_student_country,
                           Advisor_student_program)

    potential_query = Advisor_potential_student.objects.all()

    countrys_data = {}
    programs_data = {}
    for obj in Advisor_student_country.objects.all():
        countrys_data.setdefault(obj.potential_id, {})[obj.country] = obj

    for obj in Advisor_student_program.objects.all():
        programs_data.setdefault(obj.potential_id, {}).setdefault(
            obj.country, {})[obj.program] = obj

    result = {}
    total = 0
    for obj in potential_query:
        follow_person = obj.follow_person
        potential_id = obj.id
        country_data = countrys_data.get(potential_id, {})
        program_data = programs_data.get(potential_id, {})
        had_touzi = False
        if country_data:
            for country, _obj in country_data.iteritems():
                programs = program_data.get(country, {})
                if u'投资移民' in programs:
                    had_touzi = True
                    row = result.setdefault(follow_person, {}).setdefault(
                        country, [follow_person, country, 0])
                    row[2] += 1
                    break
        if not had_touzi:
            row = result.setdefault(follow_person, {}).setdefault(
                '', [follow_person, '', 0])
            row[2] += 1
        total += 1

    # f = xlwt.Workbook()
    sheet1 = f.add_sheet(u'顾问投资资源情况', cell_overwrite_ok=True)
    row0 = (u'顾问姓名', u'国家投资移民', u'资源数量')
    # 生成第一行
    for i in xrange(0, len(row0)):
        sheet1.write(0, i, row0[i])

    row = 0
    for (_, data) in sorted(result.iteritems()):
        for (_, data2) in sorted(data.iteritems()):
            row += 1
            for col, _ in enumerate(row0):
                sheet1.write(row, col, data2[col])

    sheet1.write(row + 1, 1, 'TOTAL')
    sheet1.write(row + 1, 2, total)


def export_data():
    from django.conf import settings

    f = xlwt.Workbook()

    export_potential_follow_status(f)
    export_potential_program_rate(f)
    export_potential_country_rate(f)
    export_potential_follow_person(f)
    export_potential_follow_country(f)

    filename = u'移民导出数据-{}.xls'.format(time.strftime('%Y-%m-%d-%H%M%S'))
    f.save(os.path.join(settings.PROJECT_DIR, filename))


if __name__ == '__main__':
    export_data()
