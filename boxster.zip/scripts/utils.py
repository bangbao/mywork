# coding: utf-8


def make_thead(field_names):
    lis = []
    for label in field_names:
        lis.append('<th>%s</th>' % label)
    return u'<tr align="center">%s</tr>' % ''.join(lis)


def make_trow(field_names):
    lis = []
    for field in field_names:
        lis.append('<td>%s</td>' % field)
    return u'<tr align="center">%s</tr>' % ''.join(lis)


def make_table(trows):
    values = ''.join(trows)
    return '<table border=1>%s</table><br />' % values


def make_html(tables):
    values = '<br />'.join(tables)
    return """<html><body>%s</body></html>""" % values
