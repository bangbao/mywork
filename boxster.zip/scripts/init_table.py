# coding: utf-8

import datetime


def test_crontab():
    """测试django crontab的运行
    """
    print "test_crontab run at %s" % datetime.datetime.now()


def django_bulk_create(query, data_list, check_empty=True):
    """批量insert数据
    """
    query_name = query.__name__
    if check_empty and query.objects.exists():
        print 'table %s not empty, break!' % query_name
        return

    worklist = [query(**data) for data in data_list]
    query.objects.bulk_create(worklist)
    print 'table %s init success' % query_name


def init_table_data():
    """项目搭建后要初始化一些表的数据
    """
    exclude_funcs = ('init_table_data',)
    global_data = globals()
    for name, func in global_data.iteritems():
        if name.startswith('init_table_') and name not in exclude_funcs:
            func()


def init_table_Advisor_student_country_program_list():
    from ym.apps.option.models import Advisor_student_country_program_list as query
    result = [{'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe6\x8a\x80\xe6\x9c\xafEB-1A'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe6\x8a\x80\xe6\x9c\xafEB-1C'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe9\xad\x81\xe7\x9c\x81\xe6\x8a\x95\xe8\xb5\x84'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91PEI'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91\xe6\x9b\xbc\xe7\x9c\x81'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91\xe9\xad\x81\xe7\x9c\x81\xe4\xbc\x81\xe4\xb8\x9a\xe5\xae\xb6'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91\xe9\xad\x81\xe7\x9c\x81PEO'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe8\x81\x94\xe9\x82\xa6\xe6\x8a\x80\xe6\x9c\xaf'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91Express Entry'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '200\xe4\xb8\x87\xe8\x8b\xb1\xe9\x95\x91\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '20\xe4\xb8\x87\xe4\xbc\x81\xe4\xb8\x9a\xe5\xae\xb6'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe6\x8a\xa4\xe7\x85\xa7'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe6\x8a\xa4\xe7\x85\xa7'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe6\x8a\xa4\xe7\x85\xa7'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xbd\xae\xe4\xb8\x9a\xe6\xac\xa7\xe7\x9b\x9f\xe6\x8a\xa4\xe7\x85\xa7'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xbd\xae\xe4\xb8\x9a\xe6\xac\xa7\xe7\x9b\x9f\xe6\x8a\xa4\xe7\x85\xa7'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe7\xbd\xae\xe4\xb8\x9a\xe9\xbb\x84\xe9\x87\x91\xe5\xb1\x85\xe7\x95\x99\xe6\x9d\x83'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x95\x86\xe4\xb8\x9a188A\xef\xbc\x88\xe5\x95\x86\xe4\xb8\x9a\xe5\x88\x9b\xe6\x96\xb0\xef\xbc\x89'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x95\x86\xe4\xb8\x9a188B\xef\xbc\x88\xe6\x8a\x95\xe8\xb5\x84\xe8\x80\x85\xef\xbc\x89'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x95\x86\xe4\xb8\x9a188C\xef\xbc\x88\xe5\xa4\xa7\xe9\xa2\x9d500\xe4\xb8\x87\xef\xbc\x89'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe6\x8a\x80\xe6\x9c\xaf457'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe6\x8a\x80\xe6\x9c\xaf186/187'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x85\xb6\xe4\xbb\x96', 'program': '\xe6\x8a\x80\xe6\x9c\xaf\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x85\xb6\xe4\xbb\x96', 'program': '\xe6\x8a\x95\xe8\xb5\x84\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe5\x85\xb6\xe4\xbb\x96', 'program': '\xe5\x88\x9b\xe4\xb8\x9a\xe7\xa7\xbb\xe6\xb0\x91'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe5\x85\xb6\xe4\xbb\x96', 'program': '\xe5\x95\x86\xe4\xb8\x9a\xe5\xb1\x85\xe7\x95\x99\xe8\xae\xb8\xe5\x8f\xaf'}, {'country': '\xe7\xbe\x8e\xe5\x9b\xbd', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe5\x8a\xa0\xe6\x8b\xbf\xe5\xa4\xa7', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe8\x8b\xb1\xe5\x9b\xbd', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe5\xb0\xbc\xe7\xbb\xb4\xe6\x96\xaf', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe5\xae\x89\xe6\x8f\x90\xe7\x93\x9c', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe6\xa0\xbc\xe6\x9e\x97\xe7\xba\xb3\xe8\xbe\xbe\xe5\xa4\x9a\xe7\xb1\xb3\xe5\xb0\xbc\xe5\x85\x8b', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe5\xa1\x9e\xe6\xb5\xa6\xe8\xb7\xaf\xe6\x96\xaf', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe5\xb8\x8c\xe8\x85\x8a', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe9\xa9\xac\xe8\x80\xb3\xe4\xbb\x96', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe8\x91\xa1\xe8\x90\x84\xe7\x89\x99', 'program': '\xe5\x85\xb6\xe4\xbb\x96'}, {'country': '\xe6\xbe\xb3\xe6\xb4\xb2', 'program': '\xe5\x85\xb6\xe4\xbb\x96'},
              {'country': '\xe5\x85\xb6\xe4\xbb\x96', 'program': '\xe5\x85\xb6\xe4\xbb\x96'},
              {'country': u'美国', 'program': u'投资EB-5'}]

    new = []
    for obj in result:
        if obj['country'] == u'澳洲':
            new.append({'country': u'新西兰', 'program': obj['program']})
            obj['country'] = u'澳大利亚'
    result.extend(new)

    django_bulk_create(query, result, check_empty=True)


def fix_table_Advisor_student_country_program_list():
    from ym.apps.option.models import Advisor_student_country_program_list as query
    new = []
    for obj in query.objects.filter(country=u'澳洲'):
        new.append({'country': u'新西兰', 'program': obj.program})

    if new:
        django_bulk_create(query, new, check_empty=False)
        query.objects.filter(country=u'澳洲').update(country=u'澳大利亚')


def add_new_country_program(country):
    """添加新国家
    """
    from ym.apps.option.models import Advisor_student_country_program_list as query
    common_programs = [u'技术移民', u'投资移民', u'创业移民', u'商业居留许可', u'其他']
    result = []
    for program in common_programs:
        result.append({'country': country, 'program': program})

    django_bulk_create(query, result, check_empty=False)


# def init_table_Advisor_student_comefrom_list():
#     from ym.apps.option.models import Advisor_student_comefrom_list as query
#     result = [
#         {"text": "在线资源", "value": "在线资源"},
#         {"text": "线下资源", "value": "线下资源"},
#         {"text": "数据营销", "value": "数据营销"},
#         {"text": "集团渠道", "value": "集团渠道"},
#         {"text": "集团客服", "value": "集团客服"},
#         {"text": "客户宝", "value": "客户宝"},
#         {"text": "顾问口碑", "value": "顾问口碑"},
#         {"text": "本地渠道", "value": "本地渠道"}
#     ]
#
#     django_bulk_create(query, result, check_empty=True)


def init_table_Advisor_student_follow_status_list():
    from ym.apps.option.models import Advisor_student_follow_status_list as query
    result = [
        {"value": 0, "text": "未跟进"},
        {"value": 1, "text": "未联系上"},
        # {"value": 10, "text": "无效放弃"},
        # {"value": 20, "text": "不确定是否移民"},
        {"value": 30, "text": "客户需求了解阶段"},
        {"value": 40, "text": "约访阶段"},
        {"value": 50, "text": "面谈后跟进阶段"},
        {"value": 60, "text": "签约谈判阶段"},
        {"value": 66, "text": "签约付款", "disabled": True},
        {"value": 70, "text": "停止跟进", "disabled": True},
        # {"value": 12, "text": "冻结中", "disabled": True},
        # {"value": 11, "text": "再激活", "disabled": True},
    ]

    django_bulk_create(query, result, check_empty=True)


def fix_table_unuse_follow_status():
    from ym.apps.option.models import Advisor_student_follow_status_list as query

    query.objects.filter(value__in=(10, 20, 11, 12)).delete()
    result = [
        {"value": 70, "text": "停止跟进", "disabled": True},
    ]
    django_bulk_create(query, result, check_empty=False)


def init_table_Advisor_student_branch_company_list():
    from ym.apps.option.models import Advisor_student_branch_company_list as query
    branchs = [
        "北京市",
        "长沙市",
        "成都市",
        "广州市",
        "贵阳市",
        "哈尔滨市",
        "杭州市",
        "集团",
        "济南市",
        "南京市",
        "宁波市",
        "青岛市",
        "上海市",
        "深圳市",
        "天津市",
        "武汉市",
        "西安市",
        "厦门市",
        "郑州市",
        "重庆市",
    ]
    result = [{'text': i, 'value': i} for i in branchs]

    django_bulk_create(query, result, check_empty=True)


def init_table_Advisor_student_xifenqudao_list():
    from ym.apps.option.models import Advisor_student_xifenqudao_list as query

    result = [
        {'comefrom': u'留学顾问口碑', 'xifenqudao': u'留学顾问口碑'},
        {'comefrom': u'留学顾问非口碑', 'xifenqudao': u'留学顾问非口碑'},
        {'comefrom': u'移民顾问口碑', 'xifenqudao': u'移民顾问口碑'},
        {'comefrom': u'移民员工推荐', 'xifenqudao': u'移民员工推荐'},
        {'comefrom': u'留学员工推荐', 'xifenqudao': u'留学员工推荐'},

        {'comefrom': u'市场渠道', 'xifenqudao': u'直接上门'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'市场活动'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'400电话'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'百度推广'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'社群'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'新媒体'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'网站直电'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'在线客服'},
        {'comefrom': u'市场渠道', 'xifenqudao': u'网站评估表'},

        {'comefrom': u'本地渠道', 'xifenqudao': u'银行渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'金融渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'旅游渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'俱乐部渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'行业协会渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'商会渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'进修班渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'地产渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'个人渠道'},
        {'comefrom': u'本地渠道', 'xifenqudao': u'其他渠道'},
    ]
    django_bulk_create(query, result, check_empty=True)


def fix_crp_crm_potential():
    from ym.models import Advisor_potential_student

    for obj in Advisor_potential_student.objects.filter(crp_potential_id__gte=1):
        if obj.comefrom in (u'顾问口碑', u'客户宝'):
            print '1', obj.comefrom, obj.xifenqudao, u'留学顾问口碑'
            obj.comefrom = u'留学顾问口碑'
            obj.xifenqudao = u'留学顾问口碑'
            obj.save()
        elif obj.comefrom in (u'线下资源', u'在线资源', u'数据营销', u'集团渠道',
                              u'集团客服', u'本地渠道', u'员工推荐', u'渠道推荐'):
            print '2', obj.comefrom, obj.xifenqudao, u'留学顾问非口碑'
            obj.comefrom = u'留学顾问非口碑'
            obj.xifenqudao = u'留学顾问非口碑'
            obj.save()
        else:
            print '3', obj.comefrom, obj.xifenqudao


def init_table_Advisor_student_bm_experience_list():
    from ym.apps.option.models import Advisor_student_bm_experience_list as query
    result = [
        {'text': u'高管', 'value': u'高管'},
        {'text': u'股东', 'value': u'股东'},
        {'text': u'其他', 'value': u'其他'},
        {'text': u'无', 'value': u'无'},
    ]
    django_bulk_create(query, result, check_empty=True)


def init_table_Perm():
    from ym.apps.perm import consts
    from ym.apps.perm.models import Perm as query

    result = [{'codename': k, 'name': v}
              for _, (k, v) in enumerate(consts.PERMS.iteritems())]

    django_bulk_create(query, result, check_empty=True)


def init_default_user_perm():
    from django.contrib.auth.models import User
    from ym.apps.user import logics as user_logics
    from ym.apps.perm import logics as perm_logics
    from ym.apps.perm import consts as perm_consts
    from ym.apps.perm.models import Perm
    from ym.apps.perm import potential as perm_potential

    perm_logics.sync_perm_config()

    codename_id_map = {}
    for obj in Perm.objects.all():
        codename_id_map[obj.codename] = obj.codename

    for user in User.objects.all():
        user_id = user.id
        perm_ids = []
        if user_logics.is_super_user(user):
            perm_logics.set_user_super(user)
        if user_logics.can_see_all_potential_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_VIEW])
        if user_logics.had_advisor_potentials_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_LIST])
        if user_logics.had_appoint_advisor_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_APPOINT_ADVISOR])
        if user_logics.had_potential_add_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_ADD])
        if user_logics.had_potential_edit_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_EDIT])
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_REMARK])
            perm_ids.append(codename_id_map[perm_consts.PERM_POTENTIAL_PROGRAM])
        if user_logics.can_see_mobile_perm(user):
            perm_ids.append(codename_id_map[perm_consts.PERM_MOBILE_VIEW])

        for _, codename in perm_potential.yield_perm_fields_codename():
            if (codename != perm_consts.PERM_MOBILE_VIEW and
                    codename not in perm_ids):
                perm_ids.append(codename)
        if perm_ids:
            perm_logics.change_user_perm(user_id, perm_ids)
            print user_id, perm_ids


def init_group_perm():
    from ym.apps.perm import logics as perm_logics
    from ym.apps.perm import consts as perm_consts
    from ym.apps.perm import potential as perm_potential

    default_perm_potential = set([i[1] for i in perm_potential.yield_perm_fields_codename()])
    default_perm_potential.update([
        perm_consts.PERM_POTENTIAL_LIST,
        perm_consts.PERM_POTENTIAL_EDIT,
        perm_consts.PERM_POTENTIAL_PROGRAM,
        perm_consts.PERM_POTENTIAL_REMARK,
    ])
    default_perms = {
        u'VP': set([perm_consts.PERM_POTENTIAL_ADD, perm_consts.PERM_APPOINT_ADVISOR,
                    perm_consts.PERM_POTENTIAL_VIEW]),
        u'业务副总裁': set([perm_consts.PERM_APPOINT_ADVISOR]),
        u'精英合伙级顾问': set([perm_consts.PERM_APPOINT_ADVISOR]),
        u'顾问': set(),
    }
    for name, v in default_perms.iteritems():
        perm_ids = v | default_perm_potential
        try:
            perm_logics.add_group_perm(name, perm_ids)
        except Exception as e:
            print repr(e)
            perm_logics.change_group_perm_by_name(name, perm_ids)


def init_users_title_and_userlevel():
    from ym.apps.perm import logics as perm_logics
    from ym.apps.user.models import Users
    title_map = {
        u'VP': [u'王硕'],
        u'业务副总裁': [u'陈麒冲', u'智慧'],
        u'顾问': [u'赵娟', u'刘建平', u'胡佳乐', u'逯克伟', u'周松柏'],
    }

    VP_UID = Users.objects.get(name=u'王硕').uid
    CVP_UID = Users.objects.get(name=u'陈麒冲').uid
    ZVP_UID = Users.objects.get(name=u'智慧').uid
    for title, names in title_map.iteritems():
        for name in names:
            u = Users.objects.get(name=name)
            u.title = title
            u.save()
            print u.uid, u.name, u.title
            if title == 'VP':
                level_uid = None
            elif title == u'业务副总裁':
                level_uid = VP_UID
            elif name == u'刘建平':
                level_uid = ZVP_UID
            else:
                level_uid = CVP_UID
            perm_logics.create_userlevel(level_uid, u.uid)


def init_grouplevel():
    from ym.apps.perm import logics as perm_logics
    from ym.apps.perm.models import Group

    lv_map = {
        u'VP': None,
        u'业务副总裁': u'VP',
        u'精英合伙级顾问': u'VP',
        u'顾问': u'业务副总裁',
    }
    for title, pt in lv_map.iteritems():
        group_id = Group.objects.get(name=title).id
        parent_group_id = Group.objects.get(name=pt).id if pt else None
        try:
            perm_logics.create_grouplevel(parent_group_id, group_id)
        except Exception as e:
            print repr(e)
            perm_logics.change_grouplevel(parent_group_id, group_id)
