# coding: utf-8

import json
import urllib
import datetime


def test_crontab():
    """测试django crontab的运行
    """
    print "test_crontab run at %s" % datetime.datetime.now()


def add_foreign_key():
    from ym.apps.potential.models import (
        Advisor_potential_student, Advisor_student_country,
        Advisor_student_program, Advisor_student_remark)

    for obj in Advisor_student_country.objects.filter(potential_foreign_id=None):
        apses = Advisor_potential_student.objects.filter(id=obj.potential_id)
        if not apses.exists():
            continue
        aps = apses[0]
        aps.related_countries.add(obj)
        print 'related_countries:', aps.uid, obj.id, obj.potential_foreign_id

    for obj in Advisor_student_program.objects.filter(potential_foreign_id=None):
        apses = Advisor_potential_student.objects.filter(id=obj.potential_id)
        if not apses.exists():
            continue
        aps = apses[0]
        aps.related_programs.add(obj)
        print 'related_programs:', aps.uid, obj.id, obj.potential_foreign_id

    for obj in Advisor_student_remark.objects.filter(potential_foreign_id=None):
        apses = Advisor_potential_student.objects.filter(id=obj.potential_id)
        if not apses.exists():
            continue
        aps = apses[0]
        aps.related_remarks.add(obj)
        print 'related_remarks:', aps.uid, obj.id, obj.potential_foreign_id


def sync_follow_person():
    from ym.apps.potential.models import Advisor_potential_student, Advisor_info

    advisor_names = dict(Advisor_info.objects.values_list('uid', 'full_name'))
    for obj in Advisor_potential_student.objects.all():
        if not obj.follow_person:
            if obj.uid in advisor_names:
                advisor_name = advisor_names[obj.uid]
                obj.follow_person = advisor_name
                obj.save()
                print 'sync follow_person potenial {} advisor {}'.format(obj.full_name,
                                                                         advisor_name)
            else:
                obj.delete()
                print 'delete potenial {}'.format(obj.full_name)


def sync_potential_to_crm():
    """同步部分手机资源数据到crm
    """
    from ym.utilities.crmcomm import MyCrmComm
    from ym.apps.crm.models import ResourceToCrm

    mobiles = (13512516116, 18663836743, 18046289623)
    update_keys = (
        'name', 'sex', 'mobile', 'phone', 'other_phone',
        'attribution', 'planning_year', 'line_item',
        'apply_contry', 'apply_education', 'graduate_school',
        'current_education', 'gpa_performance', 'average_score',
        'level_adjust', 'comefrom', 'xifenqudao', 'qudao_details',
        'follow_person', 'remark', 'create_user')

    for mobile in mobiles:
        instance = ResourceToCrm.objects.get(mobile=str(mobile))

        insert_data = dict()
        for key in update_keys:
            insert_data[key] = getattr(instance, key)

        insert_data.update(
            business_init=u'海外移民',
            comefrom=u'集团渠道',
            xifenqudao=u'移民推荐',
            qudao_details=u'移民推荐',
            create_user=7001,
            level_adjust=insert_data['level_adjust'] and int(insert_data['level_adjust']) or 1,
            contacts_type=u'其他',
            apply_contry=insert_data['apply_contry'] or u'其它',
            branch_company=u'北京分公司',
        )
        res = MyCrmComm().crm_potential_info_update(insert_data)
        print mobile, res


def fix_potential_crp_xifenqudao():
    """
    """
    from ym.apps.crm.models import Crm_User_info
    from ym.apps.potential.allocation import allocator
    from ym.apps.potential.models import Advisor_potential_student

    crp_xc_map = allocator.crp_xifenqudao_code_map
    xifenqudaos = (u'留学顾问非口碑', u'留学顾问口碑')
    query = Advisor_potential_student.objects.filter(source__in=('crm', 'crp'),
                                                     xifenqudao__in=xifenqudaos)
    result = {}
    for obj in query:
        crm = Crm_User_info.objects.get(mobile=obj.mobile)
        result[obj.id] = (obj.comefrom, obj.xifenqudao)
        if crm.xifenqudao in crp_xc_map:
            obj.xifenqudao = crp_xc_map[crm.xifenqudao]
            obj.comefrom = crm.comefrom
        else:
            obj.comefrom = crm.comefrom
            obj.xifenqudao = crm.xifenqudao
        obj.save()
    print result


def regist_user_to_dtp(username, password='shunshun66', project_type=None,
                       login_type='email', nickname=None):
    """注册用户到dtp系统中
    """
    from django.conf import settings
    from shunlib.utilities import http

    regist_path = '/dtp/userlogin/crp_set_chosen_register/'
    post_data = urllib.urlencode({
        'username': username,
        'password': password,
        'project_type': project_type or settings.DTP_PROJECT_TYPE,
        'login_type': login_type,
    })
    url = '%s%s' % (settings.DTP_HOST, regist_path)
    code, content = http.post(url, post_data)
    print 'regist_user_to_dtp:', url
    print code, content
    result = json.loads(content)['result']
    if code != 200:
        return None

    if nickname:
        p_id = result['p_id']
        result = change_user_info(p_id, project_type, nickname=nickname)
    return result


def get_user_info(p_id, project_type=None):
    """获取用户信息
    """
    from django.conf import settings
    from shunlib.utilities import http

    modify_path = '/dtp/userlogin/user_info/'
    query_params = urllib.urlencode({
        'p_id': p_id,
        'project_type': project_type or settings.DTP_PROJECT_TYPE,
    })
    url = '%s%s?%s' % (settings.DTP_HOST, modify_path, query_params)
    code, content = http.get(url)
    print 'change_user_info:', url
    print code, content
    if code != 200:
        return None
    return json.loads(content)['result']


def change_user_info(p_id, project_type=None, **kwargs):
    """修改用户信息
    """
    from django.conf import settings
    from shunlib.utilities import http

    modify_path = '/dtp/userlogin/user_info/'
    kwargs.update({
        'p_id': p_id,
        'project_type': project_type or settings.DTP_PROJECT_TYPE,
    })
    url = '%s%s' % (settings.DTP_HOST, modify_path)
    code, content = http.post(url, kwargs, tp='json')
    print 'change_user_info:', url
    print code, content
    if code != 200:
        return None
    return json.loads(content)['result']


def init_user(user_list=[('mktbd@sihaiyimin.com', 'mktbd', True)]):
    """新建账号
    Args:
        user_list: [('mktbd@sihaiyimin.com', 'mktbd', True)]
    """
    from ym.apps.user import logics as user_logics

    user_list = [
        ('mktbd@sihaiyimin.com', 'mktbd', True),
    ]
    for email, nickname, is_advisor in user_list:
        result = regist_user_to_dtp(email, nickname=nickname)
        if result:
            user = user_logics.create_or_sync_user(result)
            if is_advisor:
                user_logics.trans_user2advisor(user, title=u'顾问')


def sync_user(p_id_list=[('2171f6863f2d11e6872a', 'mktbd', True)]):
    """已有账号同步数据
    Args:
        p_id_list: [('2171f6863f2d11e6872a', 'mktbd', True)]
    """
    from ym.apps.user import logics as user_logics

    for p_id, nickname, is_advisor in p_id_list:
        result = change_user_info(p_id, nickname=nickname)
        if result:
            user = user_logics.create_or_sync_user(result)
            if is_advisor:
                user_logics.trans_user2advisor(user, title=u'顾问')
