#/bin/bash

ENV_NAME=local
PYTHON_BIN="/usr/local/bin/python"
if ! [ -x "$PYTHON_BIN" ]; then
    PYTHON_BIN="/usr/bin/python";
fi

OSNAME=(`uname -s`)
P_DIR=$(cd `dirname $0`; pwd -P)
export PYTHONPATH=${PYTHONPATH}${P_DIR}
export PYTHONIOENCODING=UTF-8

if [ `uname -n` == "iZ25ysyv8v6Z" ]; then
    PRODUCT_DIR=/data/sites/ym/server_${ENV_NAME}
else
    PRODUCT_DIR=$P_DIR
fi

shell()
{
    cmd=$1
    if [ "$cmd" == "" ]; then
        cmd='shell'
    fi
    python $P_DIR/manage.py $cmd $2 $3 $4
}

start()
{
    uwsgi -x $PRODUCT_DIR/src/ym/uwsgi_conf/$ENV_NAME.xml
    echo "start uwsgi done"
}

stop()
{
    echo "stop uwsgi"
    kill -9 `cat $PRODUCT_DIR/.uwsgi.pid`
}

restart()
{
    echo "restart uwsgi"
    pidfile=$PRODUCT_DIR/.uwsgi.pid
    if [ ! -f "$pidfile" ]; then
        start
    else
        touch $PRODUCT_DIR/.reload
    fi
    # stop
    # sleep 1
    # start
}

set_envname()
{
    envname=$1
    echo "OSNAME=${OSNAME}"
    if [ "$OSNAME" == "Darwin" ]; then
        sed -i '' "3s/^ENV_NAME=.*$/ENV_NAME=${envname}/g" ${P_DIR}/control.sh;
        sed -i '' "s/^ENV_NAME = \".*\"$/ENV_NAME = \"${envname}\"/g" ${P_DIR}/manage.py;
        sed -i '' "s/^ENV_NAME = \".*\"$/ENV_NAME = \"${envname}\"/g" ${P_DIR}/wsgi.py;
    else
        sed -i "3s/^ENV_NAME=.*$/ENV_NAME=${envname}/g" ${P_DIR}/control.sh;
        sed -i "s/^ENV_NAME = \".*\"$/ENV_NAME = \"${envname}\"/g" ${P_DIR}/manage.py;
        sed -i "s/^ENV_NAME = \".*\"$/ENV_NAME = \"${envname}\"/g" ${P_DIR}/wsgi.py;
    fi
}

# 代码发布到服务器
push_code()
{
    envname=$1
    case "$1" in
        test)
            T_HOST='zhangyanwei@123.57.72.210'
            T_PORT=8022
            T_DIR='/home/zhangyanwei/work/boxster/'
        ;;
        ymtest)
            T_HOST='admin@123.57.136.78'
            T_PORT=8022
            T_DIR='/data/sites/ym/server_ymtest/src/'
        ;;
        pre)
            T_HOST='admin@123.57.136.78'
            T_PORT=8022
            T_DIR='/data/sites/ym/server_pre/src/'
        ;;
        prod)
            T_HOST='admin@123.57.136.78'
            T_PORT=8022
            T_DIR='/data/sites/ym/server_prod/src/'
        ;;
        *)
            echo "usage: ./control.sh push_code [test|ymtest|pre|prod]";
            exit 1
        ;;
    esac

    temp_dir="/tmp/ym_temp_dir/"
    if [ ! -d "$temp_dir" ]; then
        mkdir $temp_dir
    else
        rm -rf $temp_dir/*
    fi

    rsync -rz -c --exclude='logs' --exclude='*.py[co]' --exclude='.[a-zA-Z0-9]*' $P_DIR/ $temp_dir/;
    echo `whoami` > ${temp_dir}/version
    bash ${temp_dir}/control.sh set_envname ${envname}

    if ! [ -n "$chk" ]; then
        rsync -rvz -c --rsh="ssh -p ${T_PORT}" --exclude='*.py[co]' --exclude='.[a-zA-Z0-9]*' --exclude='logs' --progress -n $temp_dir/ "${T_HOST}:${T_DIR}";
        read -p "Are you sure to release to $envname-${T_HOST}:${T_DIR}? (y to continue, else to quit) " chk;
    fi
    if [ "x$chk" = "xy" ]; then
        rsync -rvz -c --rsh="ssh -p ${T_PORT}" --exclude='*.py[co]' --exclude='.[a-zA-Z0-9]*' --exclude='logs' $temp_dir/ "${T_HOST}:${T_DIR}";
        echo "---- rsync done: $envname";
    else
        echo "Quit real run!"
        exit 0
    fi

#    echo "start push_code to ${T_HOST}:${T_DIR}";
#    rsync -rz --rsh="ssh -p ${T_PORT}" --exclude='.git*' --exclude='.py[co]' --exclude='.[a-z0-9]*' --exclude='logs' $P_DIR/ "${T_HOST}:${T_DIR}";
    ssh $T_HOST -p ${T_PORT} "mkdir -p ${T_DIR}logs;\
                              echo `whoami` > ${T_DIR}version;\
                              cd ${T_DIR};\
                              ${T_DIR}control.sh restart;"
    echo "push_code ${envname} done";
}

case "$1" in
    start) start;;
    stop) stop;;
    restart) restart;;
    set_envname) set_envname $2 $3 $4;;
    push_code) push_code $2;;
    shell) shell $2 $3 $4;;
    *) shell $1 $2 $3 $4;;
        #echo "Usage $0 (start|stop|restart|shell)"
        #exit 1
        #;;
esac

