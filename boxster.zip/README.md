# boxster | 移民项目

#### 安装必须软件, 如果一键安装失败, 请自行安装
`pip install -r requirements.txt`


#### 使用django框架提供服务, 配置文件settings使用不同文件名区分不同环境配置, 使用时需要先设定环境`ym/settings/[test|prod].py`,  使用uwsgi运行进程, 使用配置请查看`ym/uwsgi_conf/[test|prod].xml`, 使用方法看下面`control.sh`的使用.


#### 控制脚本 `control.sh`, 在django-manage.py功能基础上做了一些扩展
>设定环境: `./control.sh set_envname [test|pre|prod]`
><br/>
>启动服务: `./control.sh start`
><br/>
>停止服务: `./control.sh stop`
><br/>
>重载服务: `./control.sh restart`
><br/>
>进入shell: `./control.sh [shell]`
><br/>
>其它manage.py命令全支持: `./control.sh [command]`
><br/>
>临时发布代码到服务器: `./control.sh push_code [test|ymtest]`


####接口文档见`docs/*.md`, 或者查看[移民接口文档](http://code.shunshunliuxue.com/guest/crp-api-md/blob/master/移民.md)


####正式发布代码使用`walle`发布, 如何使用请咨询管理员.
