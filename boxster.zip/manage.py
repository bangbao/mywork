#!/usr/bin/env python
import os
import sys

ENV_NAME = "local"
os.environ.setdefault("ENV_NAME", ENV_NAME)


if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ym.settings")

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
