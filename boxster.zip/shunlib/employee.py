# coding: utf-8

import json
import urllib
from django.conf import settings
from shunlib.utilities import http


def get_employee_info(dtp_id):
    """根据dtp_id获取对应人事数据信息
    Args:
        dtp_id: 统一登陆用户标识id
    Returns:
        {                        # 员工数据
            "sysid": "100260",         # 员工编号
            "levels": [                # 员工角色
                "北京市总经理",
                "集团澳洲总监"
            ],
            "attribution": "",          # 分公司
            "name": "陈瑞华",            # 员工姓名
            "title": "北京分公司总经理"    # 岗位
        }
    """
    path = '/employee_infos/'

    filters = json.dumps({
        'dtp_ids': [dtp_id],
    })
    query_params = urllib.urlencode({'filters': filters})
    url = '{}{}?{}'.format(settings.EMPLOYEE_HOST, path, query_params)
    code, content = http.get(url)
    if code != 200:
        return None

    result = json.loads(content)
    if not result['result']:
        return None

    return result['result'][0]


if __name__ == '__main__':
    print get_employee_info('f454de40f09711e58d3b')
