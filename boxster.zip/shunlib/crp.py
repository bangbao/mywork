# coding: utf-8

import json
import urllib
from django.conf import settings
from shunlib.utilities import http


def get_potential_by_mobile(mobile):
    """通过手机号获取crp资源信息
    Args:
        mobile: 手机号码
    Returns:
        {
            "potential_id": 497,                   # 留学资源ID
            "name": "李雨虹",                       # 留学客户姓名
            "mobile": "15210176798",               # 留学客户手机号码
            "advisor_name": "刘云霞",               # 留学顾问
            "xifenqudao": "上海富唐"                 # 留学细分渠道
            "create_at": "2015-07-23T11:23:10Z",   # 留学资源录入时间
        }
    """
    path = '/aws/ym_get_potential_info/'

    query_params = urllib.urlencode({'mobile': mobile})
    url = '{}{}?{}'.format(settings.CRP_HOST, path, query_params)
    code, content = http.get(url)
    if code != 200:
        return None

    result = json.loads(content)
    if result['code'] != 0:
        return None

    return result['result']


def get_potential_by_id(potential_id):
    """通过手机号获取crp资源信息
    Args:
        potential_id: crp_potential_id
    Returns:
        {
            "potential_id": 497,                   # 留学资源ID
            "name": "李雨虹",                       # 留学客户姓名
            "mobile": "15210176798",               # 留学客户手机号码
            "advisor_name": "刘云霞",               # 留学顾问
            "xifenqudao": "上海富唐"                 # 留学细分渠道
            "create_at": "2015-07-23T11:23:10Z",   # 留学资源录入时间
        }
    """
    path = '/aws/ym_get_potential_info/'

    query_params = urllib.urlencode({'potential_id': potential_id})
    url = '{}{}?{}'.format(settings.CRP_HOST, path, query_params)
    code, content = http.get(url)
    if code != 200:
        return None

    result = json.loads(content)
    if result['code'] != 0:
        return None

    return result['result']


def push_potential_to_crp(push_data):
    """推送资源到crp
    Args:
        push_data: 推送资源数据, json
            "potential_id": 137,        # 资源ID
            "mobile": "18911001212",    # 手机号
            "country": "瑞士",           # 留学国家
            "education": "夏校",         # 留学项目
            "planning_year": "",        # 留学时间
            "remark": "",               # 备注 非必填
            "follow_person": "王硕",     # 指定顾问 非必填
            "comefrom": "集团渠道",             # 来源
            "xifenqudao": "移民推荐（S38）",     # 细分渠道
            "qudao_details": "",              # 渠道补充细分
            "tuijian_name": "",               # 移民推荐人姓名
            "tuijian_mobile": "",             # 移民推荐人联系方式
            "branch_company": "",             # 所在分公司
            "phone": "",                  # 备用电话1
            "other_phone": "",            # 备用电话2
            "email": "",                  # 邮箱
            "qq": "",                     # qq
            "wechat": "",                 # 微信
            "gender": "",                 # 性别
    """
    path = '/aws/immigrant_to_study_abroad/'
    url = '%s%s' % (settings.CRP_HOST, path)
    _, content = http.post(url, push_data, tp='json')

    return json.loads(content)
