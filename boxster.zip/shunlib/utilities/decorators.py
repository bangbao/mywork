# coding: utf-8

import datetime
import functools
import traceback
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view as rest_api_view


def cronjob_decorator(func):
    """定时任务装饰器, 报错发邮件, debug格式打印错误
    """
    from django.conf import settings
    from shunlib.utilities import mail

    func_name = '%s:%s' % (func.__module__, func.__name__)

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            print '{} start job: {}'.format(datetime.datetime.now(), func_name)
            result = func(*args, **kwargs)
            print '{} ended job: {}'.format(datetime.datetime.now(), func_name)
            return result
        except Exception:
            now = datetime.datetime.now()
            tb = traceback.format_exc()
            error_msg = ("FUNC_NAME: {}\n\n"
                         "{}").format(func_name, tb)
            subject = ("[{} CRONJOB ERROR] - [{}]").format(settings.ENV_NAME,
                                                           now)
            if not settings.DEBUG:
                mail.send_mail_admins(subject, error_msg)
            print '{} execute job: {} error'.format(now, func_name)
            print error_msg
    return wrapper


def api_view(http_method_names=None):
    """装饰视图函数, 返回固定格式数据
    """
    rest_api = rest_api_view(http_method_names)

    def lazy_method_func(func):
        @functools.wraps(func)
        def method_func(request, *args, **kwargs):
            response = func(request, *args, **kwargs)
            if isinstance(response, dict):

                res_status = status.HTTP_200_OK
                if response.get('code', 0) != 0:
                    res_status = status.HTTP_400_BAD_REQUEST

                # 返回数据格式: code, result, alert_msg, ...
                response = Response(response, status=res_status)
            return response
        return method_func

    def decorator(func):
        func = lazy_method_func(func)

        def handler(request, *args, **kwargs):
            rest_method = rest_api(func)
            response = rest_method(request, *args, **kwargs)

            return response
        return handler
    return decorator
