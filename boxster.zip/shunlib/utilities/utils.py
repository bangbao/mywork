# coding: utf-8

import json
import hmac
import hashlib


def signature_data(data, key):
    """签名字典数据
    Args:
        data: 字典数据
        key: 签名用的key
    Returns:
        sign: 签名值
    """
    sign_data = json.dumps(data, sort_keys=True, ensure_ascii=False)
    sign_data += key
    return hashlib.md5(sign_data).hexdigest()


def verifiy_sign(data, key, sign):
    """验证签名
    Args:
        data: 字典数据
        key: 签名用的key
        sign: 签名
    Returns:
        bool: True成功 False失败
    """
    new_sign = signature_data(data, key)
    return sign == new_sign


def cover_mobile(mobile):
    """遮盖手机号码
    Args:
        mobile: 手机号码
    Returns:
        mobile: 中间4位不可见
    """
    if not mobile:
        return mobile
    return '{}****{}'.format(mobile[:3], mobile[7:])


def hmac_sha1_sign(key, data, hexdigest=True):
    """hmac_sha1算法签名
    Args:
        key: 签名密钥
        data: 要签名的数据
        hexdigest: 默认16进制
    Returns:
        签名后的16进制串
    """
    if isinstance(data, unicode):
        data = data.encode('utf-8')
    if hexdigest:
        return hmac.new(key, data, hashlib.sha1).hexdigest()
    else:
        return hmac.new(key, data, hashlib.sha1).digest()


def hashlib_md5_sign(sign_str):
    """hashlib_md5算法签名
    Args:
        sign_str: 要签名数据
    Returns:
        签名串
    """
    if isinstance(sign_str, unicode):
        sign_str = sign_str.encode('utf-8')
    return hashlib.md5(sign_str).hexdigest()
