# -*- coding: utf-8 -*-
import datetime
import time
from django.utils.timezone import utc
from rest_framework import serializers
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.response import Response


class UnixEpochDateField(serializers.DateTimeField):

    def to_representation(self, value):
        """ Return epoch time for a datetime object or ``None``"""
        try:
            return int(time.mktime(value.timetuple()) + (3600 * 8)) * 1000
        except (AttributeError, TypeError):
            return None

    def to_internal_value(self, value):
        if isinstance(value, datetime.datetime):
            dt = value
        else:
            dt = datetime.datetime.fromtimestamp(int(value) / 1000)
        return (dt - datetime.timedelta(hours=8)).replace(tzinfo=utc)


class NormalResponse(Response):

    def __init__(self, result=None, data=None, status=None):
        if status is None:
            status = HTTP_200_OK
        data = data or {}
        if result is not None:
            data["result"] = result
        return super(NormalResponse, self).__init__(data, status=status)


class ErrorResponse(Response):

    def __init__(self, error=None, errors=None, status=None):
        if status is None:
            status = HTTP_400_BAD_REQUEST
        errors = errors or []
        if error:
            errors.append(error)
        return super(ErrorResponse, self).__init__(
            {"result": errors}, status=status)
