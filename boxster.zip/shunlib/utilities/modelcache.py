# -*- coding: utf-8 -*-
__author__ = 'liling'

import cPickle as pickle
import redis
from django.core.cache import cache

class ModelRedisCache(object):
    """缓存Model对象到redis
    """
    client = redis.Redis(*cache._server.split(":"))
    key_prefix = "boxster"

    primary_key = None
    index_fields = ()
    cache_fields = ()

    @classmethod
    def _make_cache_key(cls, spark_mark = True, **kwargv):
        if not (cls.primary_key and cls.index_fields and cls.cache_fields):
            raise Exception("Class attribute 'index_fields' and 'cache_fields' must be declared.")
        index_fields = sorted({cls.primary_key} | set(cls.index_fields))
        for field in index_fields:
            if not field in kwargv:
                if not spark_mark:
                    raise Exception("'%s' field is required." % field)
                else:
                    kwargv[field] = "*"
        cache_key = "$".join(['%s:%s'%(field, kwargv[field]) for field in index_fields])
        return "%s|%s" % (cls.key_prefix, cache_key)

    @classmethod
    def get(cls, **kwargv):
        cache_key_mark = cls._make_cache_key(**kwargv)
        cache_keys = cls.client.keys(cache_key_mark)
        if not cache_keys:
            return None
        if len(cache_keys) > 1:
            raise Exception("get() returned more than one -- it returned %d!" % len(cache_keys))
        return pickle.loads(cls.client.get(cache_keys[0]))

    @classmethod
    def get_many(cls, **kwargv):
        cache_key_mark = cls._make_cache_key(**kwargv)
        cache_keys = cls.client.keys(cache_key_mark)
        if not cache_keys:
            return []
        return [pickle.loads(v) for v in cls.client.mget(cache_keys)]

    @classmethod
    def set(cls, instance):
        cache_key = cls.get_cache_key_from_instance(instance)
        cache_value = cls.get_cache_value_from_instance(instance)
        cls.client.set(cache_key, cache_value)

    @classmethod
    def get_cache_key_from_instance(cls, instance):
        cache_key = cls._make_cache_key(spark_mark = False,
            **dict([(k, getattr(instance, k)) for k in cls.index_fields]))
        return cache_key

    @classmethod
    def get_cache_value_from_instance(cls, instance):
        cache_dict = dict([(k, getattr(instance, k)) for k in cls.cache_fields])
        return pickle.dumps(cache_dict)

    @classmethod
    def set_many(cls, iter_instances):
        for instances in map(None, *[iter(iter_instances)] * 100):
            value = {}
            for instance in instances:
                if instance is None:
                    break
                value[cls.get_cache_key_from_instance(instance)] = \
                    cls.get_cache_value_from_instance(instance)
            cls.client.mset(value)

