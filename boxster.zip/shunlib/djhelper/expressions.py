# coding: utf-8

from django.db.models.expressions import Func, Value


class ReplaceF(Func):
    function = 'REPLACE'

    def __init__(self, field, replace_from, replace_to):
        replace_from = Value(replace_from)
        replace_to = Value(replace_to)
        super(ReplaceF, self).__init__(field, replace_from, replace_to)
