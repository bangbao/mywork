# -*- coding: utf-8 -*-
import urllib
import StringIO
import simplejson
import pycurl
import base64
from M2Crypto import RSA, BIO
from django.conf import settings

PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxZj+Ks6hridC6b76+l34
z5B/nQNqxGJ4/vGaliZg5dBONjQES4O4qgPmNSUjIrRaR+ROhfG1AQyGM5+idSfT
jq1ywfywP4oM2Sc12gt46tBMOYELqftOOdufhCLHTxhah01w5UWmW16YuEXaWAnH
X+bXIPpGRY1kKj5BV6ZwetA5t1mmMoM/Lhzw/HdAcZlmUp4fvtXtZJvMc0+5DyuB
oA1DgCTKwgBXDpINL00hCLZlxK8rw/p5hMPmoZUuc6+78CWBGTZT6UliQAYOHmKl
ydGzKNdwWyJBf8eoH73Og3b7fIOteq4SDTFYTogtw34U05qJwStTATzGKAqScaLB
OwIDAQAB
-----END PUBLIC KEY-----"""

bio = BIO.MemoryBuffer(PUBLIC_KEY)
RSA_KEY = RSA.load_pub_key_bio(bio)
#DTP_HOST = "http://123.57.72.210:9002"
DTP_HOST = settings.DTP_HOST
DTP_USER_API = "/dtp/userlogin/user_info/"


class DTP:
    """统一登录SDK
    """

    class NetworkError(Exception):  pass

    class DtpError(Exception):  pass

    def get_user_by_token(self, token, project_type):
        """解密token并从DTP服务器获取用户信息
        """
        login_info = self.decode_token(token)
        p_id = login_info["p_id"]
        return self.get_user(p_id, project_type)

    def decode_token(self, token):
        """用公钥解密token
        """
        if isinstance(token, unicode):
            token = token.encode('utf-8')
        ctxt64 = base64.b64decode(token)
        try:
            txt_pri = RSA_KEY.public_decrypt(ctxt64, RSA.pkcs1_padding)
        except RSA.RSAError, e:
            raise self.DtpError("token error: %s" % e.message)
        return simplejson.loads(txt_pri)

    def get_user(self, p_id, project_type):
        """从DTP服务器获取用户数据
        @params:
            p_id - 统一登录用户ID
            project_type - 统一登录APPID
        """
        api_url = "%s%s" % (DTP_HOST, DTP_USER_API)
        params = {
            "p_id": p_id,
            "project_type": project_type,
        }
        return self.get(api_url, params)["result"]

    def get(self, api_url, params=None, need_loads=True):
        query_string = urllib.urlencode(params)
        url = "%s?%s" % (api_url, query_string)
        print url

        crl = pycurl.Curl()
        crl.setopt(pycurl.URL, url)
        crl.setopt(pycurl.SSL_VERIFYHOST, False)
        crl.setopt(pycurl.SSL_VERIFYPEER, False)
        crl.fp = StringIO.StringIO()
        crl.setopt(crl.WRITEFUNCTION, crl.fp.write)
        try:
            crl.perform()
        except pycurl.error, e:
            raise self.NetworkError(e.message)

        res_str = crl.fp.getvalue().decode("utf-8", "ignore")
        print res_str
        if need_loads:
            res_data = simplejson.loads(res_str)
            if res_data["code"] != 0:
                raise self.DtpError(res_data["result"])
            return res_data
        return res_str

dtp = DTP()

