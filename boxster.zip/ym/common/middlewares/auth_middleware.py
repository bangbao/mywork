# -*- coding: utf-8 -*-
import json
from rest_framework import status
from django.http import HttpResponse
from ym.apps.user import logics as user_logics


class AuthMiddleware(object):
    def process_request(self, request):
        # if settings.DEBUG:
            # return

        IGNORE_METHOD = (
            "rest_framework", "userlogin", "marketregister",
            "crm_potential_user", "potential_student_register",
            "qiniuuploadcallback", "select_program", "advisor_name_list",
            "chinese_highschool", "chinese_university",
            "advisorpotentialstudents", "userlogout", "plannings", "test",
            "notifypaystatus", "advisor_details", "advisors_city",
            "aplipay_url_generate", "travel_pay_notify",
            "getqiniuuptoken", "expire_potential", "expire_detail",
            "advisorexperiences", "advisorids",
            "sem", "mobile", "chineseschools", "new_resource", "new",
            "getadvisorinfo", 'wap_resource', 'dtp_login', 'dtp', 'temp_login',
            "crp_potential_user", "crp_potential_info", "crp_option_info",
            "dtp_sync_user_info",
        )
        CHECK_PATH = ("ym")
        try:
            method_name = request.path.split('/')[2]
            path_name = request.path.split('/')[1]
        except Exception, e:
            print '>>> auth middleware exception:', e
            return

        if path_name not in CHECK_PATH:
            return

        if method_name in IGNORE_METHOD:
            print "INGORE_method_name=", method_name
            return

        try:
            res = user_logics.jwt_token_verify(request)
            # res = request.user.id
        except Exception as e:
            print e
            res = None
        if res is None:
            result_data = {
                'result': u"用户未登陆",
                'code': 1,
            }
            return HttpResponse(json.dumps(result_data),
                                status=status.HTTP_401_UNAUTHORIZED,
                                content_type='application/json')
        else:
            print "login ok user_id=", res
            request.uid = res
