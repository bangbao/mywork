# coding: utf-8

import time
from django.conf import settings
from .. import logger


class LogMiddleware(object):
    IGNORE_PATH = ("static.", )

    def process_request(self, request):
        self.start_time = time.time()
        path_name = request.path.strip('/').replace('/', '.')
        if not path_name:
            path_name = "[ROOT]"

        request.path_name = path_name
        request.log_args = {}.fromkeys(['v1', 'v2', 'v3', ])

    def process_response(self, request, response):
        if not hasattr(self, 'start_time'):
            return response

        path_name = request.path_name
        for ignore in self.IGNORE_PATH:
            if path_name.startswith(ignore):
                return response

        end_time = time.time()
        # 生成日志
        user_id = getattr(request, "uid", None)
        # 写入日志
        logger.Logger.log(request, response, user_id,
                          method=request.method,
                          action=path_name,
                          http_code=response.status_code,
                          exec_time='%.3f' % (end_time - self.start_time),
                          args=request.log_args)
        # 打印接口返回数据
        if settings.DEBUG:
            import json
            from django.http import HttpResponse
            from django.core.serializers.json import DjangoJSONEncoder
            from rest_framework.response import Response
            if isinstance(response, Response):
                data = response.data
            elif isinstance(response, HttpResponse):
                data = response.getvalue()
            else:
                data = None
            if data:
                if not isinstance(data, basestring):
                    data = json.dumps(data, cls=DjangoJSONEncoder, ensure_ascii=False)
                else:
                    data = 'too_long' if len(data) >= 100 else data
                print '-' * 50
                print 'TIME: %s' % time.strftime('%Y-%m-%d %H:%M:%S')
                print 'REQUEST: %s %s' % (request.method, request.get_full_path())
                print 'RESPONSE: %s %s' % (response.status_code, data)
                print '-' * 50
        return response


class DisableCSRFCheck(object):

    def process_request(self, request):
        setattr(request, '_dont_enforce_csrf_checks', True)
