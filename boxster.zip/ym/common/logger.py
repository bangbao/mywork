# -*- coding:utf-8 -*-

from django.conf import settings
import json
import datetime
import os
import re
import logging
import logging.handlers
import urllib

PATHNAME_FORMAT = settings.STATLOG_PATHNAME_FORMAT      # 日志文件名格式
LOGNAME_PREFIX = "boxster"                                  # 应用前缀
FORMATTER = logging.Formatter('%(name)s\t%(asctime)s\t%(message)s')     # 日志格式
MAX_BYTES = 1024 * 1000 * 100       # 日志文件最大100M
BACKUP_COUNT = 50000                # 最大日志文件数


class Logger():
    _stat_log = None
    _file_handler = None
    stat_dt = datetime.date.today()

    @classmethod
    def stat_log(cls):
        if cls._stat_log is None or cls.stat_dt != datetime.date.today():
            if cls._stat_log is not None:
                cls._stat_log.removeHandler(cls._file_handler)
            cls._stat_log = logging.getLogger(LOGNAME_PREFIX)
            folder_name = datetime.date.today().strftime("%Y%m%d")
            filename = PATHNAME_FORMAT % {"folder_name": folder_name}
            if not os.path.exists(os.path.dirname(filename)):
                os.makedirs(os.path.dirname(filename))
            cls._file_handler = logging.handlers.RotatingFileHandler(
                filename,
                maxBytes=MAX_BYTES,
                backupCount=BACKUP_COUNT
            )
            cls._file_handler.setFormatter(FORMATTER)
            cls._file_handler.setLevel(logging.NOTSET)
            cls._stat_log.addHandler(cls._file_handler)
        return cls._stat_log

    @classmethod
    def log(cls, request, response, user_id=None, method=None, action=None,
            http_code=None, exec_time=None, args=None):
        try:
            # 日志统计项
            data_format = ["action", "method", "uid", "v1", "v2",
                           "v3", "exec_time", "http_code", "url_params"]
            data_format_str = "\t".join(["%%(%s)s" % k for k in data_format])       # 日志格式
            log_params = {}.fromkeys(data_format)
            log_params["action"] = action or getattr(request, "path_name", None)
            log_params["uid"] = user_id
            log_params["url_params"] = request.META.get("QUERY_STRING")
            log_params["method"] = method
            log_params["http_code"] = http_code
            log_params["exec_time"] = exec_time

            # 把post参数也写到日志里
            if method == 'POST':
                try:
                    rest_request = response.renderer_context['request']
                    post_data = urllib.urlencode(rest_request.data)
                    if log_params["url_params"]:
                        post_data = '&%s' % cls.convert_log_str(post_data)
                        log_params["url_params"] += post_data
                    else:
                        log_params["url_params"] = post_data
                except Exception as e:
                    print repr(e)

            # 添加接口参数
            match = re.match("(.*?)(\.\d+)?$", action)
            if match:
                func_name = "API_%s" % match.groups()[0].replace(".", "_")
                func = globals().get(func_name)
                if callable(func):
                    func(request, response)
            if isinstance(args, dict):
                for k, v in args.iteritems():
                    if not args[k] is None:
                        log_params[k] = cls.convert_log_str(args[k])
            log_str = data_format_str % log_params
            cls.stat_log().log(100, log_str)
        except Exception, e:
            print '>>> Logger error:', e

    @staticmethod
    def convert_log_str(v_str):
        """转换成日志字符串
        """
        chr_mapping = {
            '\n': '',
            '\t': '',
        }
        if isinstance(v_str, unicode):
            convert = unichr
        elif isinstance(v_str, str):
            convert = str
        else:
            return v_str
        for c, r in chr_mapping.iteritems():
            v_str = v_str.replace(c, convert(r))
        return repr(v_str).strip('u\'').strip('\'')

# api statistics argument


def get_rest_data(request):
    post_data = dict(request.POST.items()).get("_content")
    try:
        return json.loads(post_data)
    except:
        return {}


def API_bi_auth(request, response):
    request.log_args['v1'] = request.user.username
