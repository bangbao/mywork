# coding: utf-8

import os
import inspect
from django.db import models


def is_django_model(x):
    return inspect.isclass(x) and issubclass(x, models.Model)


model_classes = {}
FILE_DIR = os.path.dirname(os.path.abspath(__file__))
apps_root = os.path.join(FILE_DIR, 'apps')
for root, dirs, files in os.walk(apps_root):
    for dname in dirs:
        module_name = 'ym.apps.{}.models'.format(dname)
        try:
            module = __import__(module_name, globals(), locals(), ['__name__'])
        except ImportError:
            continue
        for kname, kclass in inspect.getmembers(module, is_django_model):
            # print kname, kclass
            model_classes[kname] = kclass


globals().update(model_classes)
