# coding: utf-8

from django.core.management.base import BaseCommand
from django.core.management.color import color_style
from django.db import connection
from django.db.backends.mysql.schema import DatabaseSchemaEditor


class OnlyCollectSqlDatabaseSchemaEditor(DatabaseSchemaEditor):
    """只打印生成的sql, 不执行到数据库
    """
    def __init__(self, connection):
        super(OnlyCollectSqlDatabaseSchemaEditor, self).__init__(connection,
                                                                 collect_sql=True)

    def execute(self, sql, params=[]):
        """Executes the given SQL statement, with optional parameters.
        """
        # print '-------- %s' % sql
        ending = "" if sql.endswith(";") else ";"
        if params is not None:
            self.collected_sql.append((sql % tuple(map(self.quote_value, params))) + ending)
        else:
            self.collected_sql.append(sql + ending)


class Command(BaseCommand):
    help = "show create sql base on given model"

    def add_arguments(self, parser):
        parser.add_argument('c1', nargs='?', help='like ym.apps.user.models.Users')
        parser.add_argument('-c', help='like ym.apps.user.models.Users')

    def handle(self, *args, **options):
        classpath = options['c'] or options['c1']
        if classpath is None:
            return

        modname, classname = classpath.rsplit('.', 1)
        module = __import__(modname, globals(), locals(), [classname])
        model = getattr(module, classname)
        self.print_sql(model)

    def print_sql(self, model):
        with OnlyCollectSqlDatabaseSchemaEditor(connection) as dse:
            dse.create_model(model)
        print
        c = color_style()
        for sql in dse.collected_sql:
            print c.SQL_KEYWORD(sql)
