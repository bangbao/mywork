# coding: utf-8

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Runs every module and its functions."

    def add_arguments(self, parser):
        parser.add_argument('fm', nargs='?', help='execute given func_module')
        parser.add_argument('-m', help='execute pymodule.main')
        parser.add_argument('-f', help='execute pymodule.function')

    def handle(self, *args, **options):
        fm = options['fm']
        if fm is not None:
            try:
                module = __import__(fm, globals(), locals(), ['__name__'])
                module.main()
            except ImportError:
                modname, funcname = fm.rsplit('.', 1)
                module = __import__(modname, globals(), locals(), [funcname])
                func = getattr(module, funcname)
                func()

        modname = options['m']
        if modname is not None:
            module = __import__(modname, globals(), locals(), ['__name__'])
            module.main()

        funcpath = options['f']
        if funcpath is not None:
            modname, funcname = funcpath.rsplit('.', 1)
            module = __import__(modname, globals(), locals(), [funcname])
            func = getattr(module, funcname)
            func()
