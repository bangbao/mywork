# coding: utf-8

from django import forms
from django.contrib import admin
from django.http import HttpResponseRedirect
from ym.apps.crm.models import Crm_User_info
from ym.apps.potential.models import (
    Advisor_potential_student,
    RelatedPotentialStudent,
)
from ym.apps.option.models import (
    Advisor_student_comefrom_list,
    Advisor_student_country_program_list,
    Advisor_student_follow_status_list,
)


@admin.register(Advisor_student_comefrom_list)
class Advisor_student_comefrom_list_Admin(admin.ModelAdmin):
    list_display = ('id', 'text', 'value')
    search_fields = ('text', 'value')
    list_editable = ('text', 'value')
    ordering = ('id',)


@admin.register(Advisor_student_country_program_list)
class Advisor_student_country_program_list_Admin(admin.ModelAdmin):
    list_display = ('id', 'country', 'program')
    # list_display_links = ('text', 'value')
    search_fields = ('country', 'program')
    list_editable = ('country', 'program')
    ordering = ('id',)


@admin.register(Advisor_student_follow_status_list)
class Advisor_student_follow_status_list_Admin(admin.ModelAdmin):
    list_display = ('id', 'text', 'value', 'disabled')
    # list_display_links = ('text', 'value')
    search_fields = ('text', 'value')
    list_editable = ('text', 'value', 'disabled')
    ordering = ('id',)


# @admin.register(Advisor_student_program_list)
# class Advisor_student_program_list_Admin(admin.ModelAdmin):
#     list_display = ('id', 'text', 'value')
#     #list_display_links = ('text', 'value')
#     search_fields = ('text', 'value')
#     list_editable = ('text', 'value')
#     ordering = ('id',)


@admin.register(Advisor_potential_student)
class AdvisorPotentialStudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'full_name', 'crm_create_user', 'mobile',
                    'country', 'comefrom', 'xifenqudao', 'qudao_details', 'source',
                    'add_relate',
                    )
    list_display_links = ()
    search_fields = ('mobile', 'full_name', 'country', 'education',
                     'comefrom', 'xifenqudao', 'qudao_details',
                     )
    list_editable = ('crm_create_user',
                     'comefrom', 'xifenqudao', 'qudao_details')
    fields = ('uid', 'user_name', 'student_uid', 'first_name', 'last_name',
              'full_name', 'gender', 'mobile', 'phone', 'other_phone',
              'current_school', 'current_grade', 'current_professional',
              'program_title', 'country', 'education', 'professional',
              'planning_year', 'is_chosen', 'status', 'rate', 'entry_time',
              'rebate', 'create_at', 'modify_at', 'alloc_at', 'source',
              'comefrom', 'xifenqudao', 'qudao_details',
              'chosen_time', 'origin_id', 'crm_create_user',)
    readonly_fields = ('uid', 'user_name', 'student_uid',
                       'gender', 'mobile', 'phone', 'other_phone',
                       'current_school', 'current_grade', 'current_professional',
                       'program_title', 'country', 'education', 'professional',
                       'planning_year', 'is_chosen', 'status', 'rate', 'entry_time',
                       'rebate', 'create_at', 'modify_at', 'alloc_at', 'source',
                       'chosen_time', 'origin_id',)

    def add_relate(self, obj):
        url = '../relatedpotentialstudent/add/?'\
              'potential_id=%d&crm_create_user=%s&mobile=%s%%2B1&'\
              'country=%s&education=%s&first_name=%s&last_name=%s%%2B1'\
              % (obj.id, obj.crm_create_user or '', obj.mobile,
                 obj.country or '', obj.education or '', obj.first_name or '',
                 obj.last_name or obj.full_name or '')
        return '<a href="%s">添加关联资源</a>' % url

    add_relate.allow_tags = True
    add_relate.short_description = u'添加关联资源'


class RelatedPotentialStudentForm(forms.ModelForm):
    potential_id = forms.CharField(
        widget=forms.TextInput(attrs={'readonly': 'readonly'})
    )
    related_potential_id = forms.CharField(
        widget=forms.TextInput(attrs={'readonly': 'readonly', 'value': '-'})
    )
    country = forms.CharField(label=u'申请国家', required=False)
    education = forms.CharField(label=u'申请项目', required=False)
    first_name = forms.CharField(label=u'姓', required=False)
    last_name = forms.CharField(label=u'名')
    mobile = forms.CharField(label=u'手机号码')
    crm_create_user = forms.CharField(label=u'客服ID', required=False)

    def save(self, commit=True):
        potential_id = self.cleaned_data.get('potential_id')
        country = self.cleaned_data.get('country')
        education = self.cleaned_data.get('education')
        program_title = ''.join([country, education])
        first_name = self.cleaned_data.get('first_name')
        last_name = self.cleaned_data.get('last_name')
        full_name = ''.join([first_name, last_name])
        mobile = self.cleaned_data.get('mobile')
        crm_create_user = self.cleaned_data.get('crm_create_user')

        self.potential = Advisor_potential_student.objects.get(pk=potential_id)
        new_potential_info = Advisor_potential_student(
            mobile=mobile,
            country=country,
            education=education,
            program_title=program_title,
            first_name=first_name,
            last_name=last_name,
            full_name=full_name,
            crm_create_user=crm_create_user,
            source='related',
        )
        copy_fields = ('uid', 'comefrom', 'xifenqudao', 'qudao_details',
                       'current_school', 'current_grade', 'current_professional',
                       )
        for field in copy_fields:
            exec("new_potential_info.{0} = self.potential.{0}".format(field))

        new_potential_info.save()
        self.data['related_potential_id'] = str(new_potential_info.id)
        return super(RelatedPotentialStudentForm, self).save(commit=commit)

    class Meta:
        model = RelatedPotentialStudent
        fields = "__all__"


@admin.register(RelatedPotentialStudent)
class RelatedPotentialStudentAdmin(admin.ModelAdmin):
    form = RelatedPotentialStudentForm
    list_display = ('forbidden', )

    def forbidden(self, obj):
        return u'<a href="#"></a>禁止查看'
    forbidden.allow_tags = True

    fieldsets = (
        (u'填写资源信息', {
            'fields': ('country', 'education', 'first_name', 'last_name',
                       'mobile', ),
        }),
        (u'请勿修改', {
            'fields': ('potential_id', 'related_potential_id',
                       'crm_create_user'),
        }),
    )

    def save_model(self, request, obj, form, change):
        obj.potential_id = int(form.data['potential_id'])
        obj.related_potential_id = int(form.data['related_potential_id'])
        super(RelatedPotentialStudentAdmin, self).save_model(
            request, obj, form, change)

    def response_add(self, request, obj, post_url_continue=None):
        """This makes the response go to the newly created model's change page
        without using reverse"""
        return HttpResponseRedirect("../../advisor_potential_student/")


@admin.register(Crm_User_info)
class CrmUserInfoAdmin(admin.ModelAdmin):
    list_display = ('id', 'cuscode', 'name', 'mobile', 'follow_person',
                    'level_adjust', 'comefrom', 'xifenqudao', 'flag', 'crm_update_flag')
    list_display_links = ('id', 'cuscode')
    search_fields = ('cuscode', 'name', 'mobile', 'follow_person',
                     'comefrom', 'xifenqudao')
    list_editable = ('follow_person',)
    list_filter = ('flag', 'comefrom', )
    readonly_fields = ('id', 'cuscode', 'name', 'phone', 'mobile',
                       'other_phone', 'comefrom', 'create_user', 'line_item', 'sex',
                       'latest_status', 'age', 'graduate_school', 'current_education',
                       'current_professional', 'gpa_performance', 'average_score',
                       'apply_contry', 'target_school', 'apply_education',
                       'apply_professional', 'comefrompoint', 'email', 'create_time',
                       'flag', 'planning_year', 'follow_road', 'origin_id',
                       'current_grade', 'remark', 'contacts_type', 'contacts_name', 'qq',
                       'wechat', 'convenient_time', 'crm_update_flag', 'business_unit',
                       'xifenqudao', 'create_at', 'qudao_details', 'houxuan_country1',
                       'houxuan_country2', 'houxuan_country3', 'ignore_advisor', 'pusher',)


# @admin.register(Contract)
# class ContractAdmin(admin.ModelAdmin):
#     list_display = ('id', "contract_no", "get_potential_name",
#         "service_type", "status", "contract_amount", "payer_fullname",
#         "payment_amount", "first_submit_time", "create_at", "signed_at",)
#     list_display_links = ('id', "contract_no", )
#     search_fields = ('id', "contract_no",
#         "potential__mobile", "potential__full_name")
#     list_editable = ("service_type", "status", )
#
#     def get_potential_name(self, obj):
#         return obj.potential.full_name
