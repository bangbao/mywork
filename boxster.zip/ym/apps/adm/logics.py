# coding: utf-8

import re
from django.db.models import Q
from ym.apps.perm import logics as perm_logics
from ym.apps.perm import manager as perm_manager


def get_keywords_filters(keywords, keyword_fields):
    """获取模糊搜索Q对象
    Args:
        keywords: 关键词, 以空格分隔
        keyword_fields: 对应要搜索的字段
    Returns:
        filters: Q对象
    """
    keywords = re.sub(' +', ' ', keywords.strip())
    keywords = keywords.split(' ')

    filters = Q()
    for keyword in keywords:
        for field in keyword_fields:
            filters |= Q(**{"%s__icontains" % field: keyword})
    return filters


def get_user_staff_info(user):
    """获取用户员工相关信息
    """
    users = user.users
    userlevel_map = perm_logics.get_userlevel_map(user_id=user.id)

    result = {
        'uid': user.id,
        'sysid': users.sysid,
        'attribution': users.attribution,
        'name': users.name,
        'title': users.title,
        'country': users.country,
        'levels': users.levels,
        'perms': perm_manager.get_perm_client_data(user),
        'level_uid': userlevel_map.get(user.id),
    }
    return result

