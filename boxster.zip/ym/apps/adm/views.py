# coding: utf-8

import json
from shunlib.utilities.decorators import api_view
from ym.apps.user import logics as user_logics
from ym.apps.user.models import Users
from ym.apps.perm import consts as perm_consts
from ym.apps.perm import logics as perm_logics
from ym.apps.perm.manager import require_perm
from . import logics


@api_view(['GET'])
def staff_attributions(request):
    """分公司
    """
    attributions = Users.objects.filter(
        attribution__isnull=False).values('attribution').distinct()

    result = [{'text': data['attribution'], 'value': data['attribution']}
              for data in attributions]

    return {'code': 0, 'result': result}


@api_view(['GET'])
def staff_countries(request):
    """国家
    """
    countries = Users.objects.filter(
        country__isnull=False).values('country').distinct()

    result = [{'text': data['country'], 'value': data['country']}
              for data in countries]

    return {'code': 0, 'result': result}


@api_view(['GET'])
def staff_titles(request):
    """岗位及上级职员映射关系
    """
    title_map = perm_logics.get_grouplevel_map()
    title_sort_show = [obj[0] for obj in reversed(title_map.items())]
    result = [{'text': title, 'value': title}
              for title in title_sort_show]

    rev_title_map = {}
    for title, parent_title in title_map.iteritems():
        if parent_title:
            rev_title_map.setdefault(parent_title, []).append(title)

    objs = Users.objects.filter(title__in=set(rev_title_map))
    for obj in objs:
        for title in rev_title_map.get(obj.title, []):
            index = title_sort_show.index(title)
            levels = result[index].setdefault('levels', [])
            levels.append({'name': obj.name, 'uid': obj.uid})

    result.append({'text': u'其他', 'value': None})
    return {'code': 0, 'result': result}


@api_view(['GET'])
@require_perm(perm_consts.PERM_STAFF_ADMIN)
def staff_list(request):
    """员工列表
    Args:
        filters: {} (optional, json字符串) // key为
                 attribution: 列表, title:文本, country: 列表
        keywords: - 搜索关键词，多个词用空格隔开
        page: 分页页数
        length: 每页长度
    """
    filters = request.query_params.get("filters")               # 过滤条件
    keywords = request.query_params.get("keywords")             # 搜索
    page = int(request.query_params.get("page") or 0)           # 分页页数
    length = int(request.query_params.get("length") or 10)      # 每页长度

    user_query = Users.objects.filter(d_user__is_staff=True)
    if filters:
        filters = json.loads(filters)
        for key, value in filters.iteritems():
            if key == 'attribution':
                user_query = user_query.filter(attribution__in=value)
            elif key == 'country':
                user_query = user_query.filter(country__in=value)
            elif key == 'title':
                user_query = user_query.filter(title__icontains=value)
            else:
                user_query = user_query.filter(**{key: value})

    if keywords:
        keyword_fields = (
            'name', 'title', 'country', 'attribution', 'levels', 'sysid',
        )
        filters = logics.get_keywords_filters(keywords, keyword_fields)
        user_query = user_query.filter(filters)

    user_query.order_by('sysid')
    user_list = user_query.values('uid', 'sysid', 'attribution', 'name',
                                  'title', 'country', 'levels')
    count = len(user_list)
    user_list = user_list[page * length:(page + 1) * length]

    user_ids = [obj['uid'] for obj in user_list]
    userlevel_map = perm_logics.get_userlevel_map(user_id__in=user_ids)

    dlist = []
    for obj in user_list:
        obj['level_uid'] = userlevel_map.get(obj['uid'])
        dlist.append(obj)

    result = {
        'dlist': dlist,
        'count': count,
        'page': page,
    }
    return {'code': 0, 'result': result}


@api_view(['GET'])
@require_perm(perm_consts.PERM_STAFF_INFO)
def staff_info(request):
    """员工详细资料
    Args:
        uid: 员工uid
    """
    uid = request.query_params.get('uid')

    try:
        users = Users.objects.get(uid=uid)
        user = users.d_user
    except Users.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应用户'}

    result = logics.get_user_staff_info(user)

    return {'code': 0, 'result': result}


@api_view(['POST'])
@require_perm(perm_consts.PERM_STAFF_SET_PERM)
def staff_set_perm(request):
    """员工设置权限
    Args:
        uid: 员工uid
        user_perms: [codename, codename],   # 权限codename列表
        title: 岗位
        level_uid: 上属领导uid
    """
    uid = int(request.data['uid'])
    user_perms = request.data['user_perms']
    title = request.data['title']
    level_uid = int(request.data.get('level_uid') or 0) or None

    try:
        users = Users.objects.get(uid=uid)
        user = users.d_user
    except Users.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应用户'}

    if level_uid and level_uid == uid:
        return {'code': 1, 'result': u'自己不能是自己的上属领导'}

    if title:
        user_logics.trans_user2advisor(user, title)
        perm_logics.change_userlevel(level_uid, uid)
    else:
        user_logics.clear_user2advisor(user)
        perm_logics.delete_userlevel(user.id)

    perm_ids = [perm for perm in user_perms if perm in perm_consts.PERMS]
    perm_logics.change_user_perm(uid, perm_ids)

    return {'code': 0, 'result': 'ok'}


@api_view(['GET'])
@require_perm(perm_consts.PERM_STAFF_ACTIVE_LIST)
def staff_active_list(request):
    """未激活员工列表
    Args:
        filters: {} (optional, json字符串) // key为
                 attribution: 列表, title:文本, country: 列表
        keywords: - 搜索关键词，多个词用空格隔开
        page: 分页页数
        length: 每页长度
    """
    filters = request.query_params.get("filters")               # 过滤条件
    keywords = request.query_params.get("keywords")             # 搜索
    page = int(request.query_params.get("page") or 0)           # 分页页数
    length = int(request.query_params.get("length") or 10)      # 每页长度

    user_query = Users.objects.filter(d_user__is_staff=False)
    if filters:
        filters = json.loads(filters)
        for key, value in filters.iteritems():
            if key == 'user_name':
                user_query = user_query.filter(user_name__icontains=value)
            elif key == 'mobile':
                user_query = user_query.filter(mobile__icontains=value)
            elif key == 'email':
                user_query = user_query.filter(email__icontains=value)
            else:
                user_query = user_query.filter(**{key: value})

    if keywords:
        keyword_fields = ('user_name', 'mobile', 'email')
        filters = logics.get_keywords_filters(keywords, keyword_fields)
        user_query = user_query.filter(filters)

    user_query.order_by('uid')
    user_list = user_query.values('uid', 'user_name', 'mobile', 'email')
    count = len(user_list)
    user_list = user_list[page * length:(page + 1) * length]

    result = {
        'dlist': list(user_list),
        'count': count,
        'page': page,
    }
    return {'code': 0, 'result': result}


@api_view(['POST'])
@require_perm(perm_consts.PERM_STAFF_ACTIVE)
def staff_active(request):
    """激活员工
    Args:
        uid: 员工uid
        title: 岗位
        level_uid: 上属领导uid
    """
    uid = int(request.data['uid'])
    title = request.data.get('title')
    level_uid = int(request.data.get('level_uid') or 0) or None

    try:
        users = Users.objects.get(uid=uid)
        user = users.d_user
    except Users.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应用户'}

    if level_uid and level_uid == uid:
        return {'code': 1, 'result': u'自己不能是自己的上属领导'}

    # user.is_active = True
    user.is_staff = True
    user.save()

    if title:
        user_logics.trans_user2advisor(user, title)
        perm_logics.init_user_title_perm(user, title)
        perm_logics.create_userlevel(level_uid, uid)

    return {'code': 0, 'result': 'ok'}


@api_view(['POST'])
@require_perm(perm_consts.PERM_STAFF_FREEZE)
def staff_freeze(request):
    """冻结员工账号
    Args:
        uid: 员工uid
    """
    uid = request.data.get('uid')

    try:
        users = Users.objects.get(uid=uid)
        user = users.d_user
    except Users.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应用户'}

    # user.is_active = False
    user.is_staff = False
    user.is_superuser = False
    user.save()

    user_logics.clear_user2advisor(user)
    perm_logics.delete_user_perm(user.id)
    perm_logics.delete_userlevel(user.id)

    return {'code': 0, 'result': 'ok'}
