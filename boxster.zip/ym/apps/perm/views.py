# coding: utf-8

from shunlib.utilities.decorators import api_view
from . import consts
from . import logics
from .models import Group


@api_view(['GET'])
def perm_list(request):
    """所有权限列表
    """
    result = logics.get_perms_all()

    return {'code': 0, 'result': result}


@api_view(['GET'])
def group_list(request):
    """所有权限分组列表
    """
    result = logics.get_groups_all()

    return {'code': 0, 'result': result}


@api_view(['GET'])
def group_info(request):
    """权限分组详情
    """
    group_id = int(request.query_params['group_id'])

    try:
        group = Group.objects.get(id=group_id)
    except Group.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应权限分组'}

    result = {
        'id': group.id,
        'name': group.name,
        'group_perms': logics.get_group_perms(group_id),
    }
    return {'code': 0, 'result': result}


@api_view(['POST'])
def group_edit(request):
    """权限分组编辑
    """
    group_id = int(request.data['group_id'])
    name = request.data['name']
    group_perms = request.data['group_perms']

    try:
        group = Group.objects.get(id=group_id)
    except Group.DoesNotExist:
        return {'code': 1, 'result': u'没找到对应权限分组'}

    perm_ids = [perm for perm in group_perms if perm in consts.PERMS]
    logics.change_group_perm(group_id, perm_ids)

    if group.name != name:
        group.name = name
        group.save()

    result = {
        'id': group.id,
        'name': group.name,
        'group_perms': logics.get_group_perms(group_id),
    }
    return {'code': 0, 'result': result}


@api_view(['POST'])
def group_add(request):
    """添加权限分组
    """
    name = request.data['name']
    group_perms = request.data['group_perms']

    perm_ids = [perm for perm in group_perms if perm in consts.PERMS]
    logics.add_group_perm(name, perm_ids)

    return {'code': 0, 'result': 'ok'}


@api_view(['DELETE'])
def group_delete(request):
    """删除权限分组
    """
    group_id = int(request.data['group_id'])

    logics.delete_group(group_id)

    return {'code': 0, 'result': 'ok'}
