# coding: utf-8

from collections import OrderedDict
from . import consts
from . import logics


def _init_perm_all():
    """初始化生成权限相关配置数据
    """
    def setdefault_perms(data, key):
        if not key:
            return
        if '.' in key:
            k1, k2 = key.split('.', 1)
            data2 = data.setdefault(k1, OrderedDict())
            setdefault_perms(data2, k2)
        else:
            data.setdefault(key, False)

    for key, name, authkey in consts.PERMS_CONFIG:
        consts.PERMS_NAMES[key.rstrip('.')] = name
        setdefault_perms(consts.PERMS_ALL, key)
        if logics.is_perm_codename(key):
            consts.PERMS[key] = name
        if authkey:
            consts.USER_AUTH_PERMISSON_MAP[key] = authkey


def _init_table_field_perm():
    """初始化权限设置中一些表单字段的权限key
    """
    from . import potential

    for codename, name, authkey in potential.yield_perm_fields():
        consts.PERMS_CONFIG.append((codename, name, authkey))

    _init_perm_all()

try:
    _init_table_field_perm()
    # print '_init_table_field_perm success'
except Exception as e:
    print '_init_table_field_perm failure: {}'.format(repr(e))
