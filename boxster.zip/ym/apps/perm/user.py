# coding: utf-8

from . import consts


def get_user_auth_permission(user):
    """获取用户auth接口返回的权限数据
    Args:
        user: 用户对象
    Returns:
        权限字典
    """
    has_perm = user.perm_manager.has_perm

    permission = {}
    for codename, key in consts.USER_AUTH_PERMISSON_MAP.iteritems():
        permission[key] = has_perm(codename)

    return permission
