# coding: utf-8

from shunlib.utilities import utils


# 以下定义table字段展示权限相关
PERM_PREFIX = 'ps.field.'
PERM_FIELDS = [
    ('full_name', u'姓名', None),
    ('create_at', u'录入日期', None),
    ('mobile', u'电话', None),
    ('attribution', u'客户地区', None),
    ('rate', u'星级', None),
    ('follow_person', u'跟进顾问', None),
    ('follow_status', u'跟进状态', None),
    ('comefrom', u'来源', None),
    ('xifenqudao', u'细分渠道', None),
    ('wechat', u'微信', None),
    ('expendable_fund', u'可用资金', None),
    ('gross_assets', u'总资产', None),
    ('bm_experience', u'商业管理经验', None),
    ('marital_status', u'婚姻状况', None),
    ('linguistic_competence', u'语言能力', None),
    ('tuijian_name', u'推荐人姓名', None),
    ('tuijian_mobile', u'推荐人电话', None),
    ('tuijian_branch', u'推荐人所属分公司', None),
    ('tuijian_depart', u'推荐人所属部门', None),
    ('ym_mobile', u'移民联系人姓名', None),
    ('ym_username', u'移民联系人联系方式', None),
]


def yield_perm_fields():
    """返回生成field对应的权限
    Yields:
        codename, name, authkey
    """
    for field, name, authkey in PERM_FIELDS:
        codename = PERM_PREFIX + field
        yield codename, name, authkey


def yield_perm_fields_codename():
    """返回生成field对应的权限codename
    Yields:
        field, codename
    """
    for field, _, _ in PERM_FIELDS:
        codename = PERM_PREFIX + field
        yield field, codename


def get_forbidden_perm_fields(user):
    """获取用户不能查看的字段
    Args:
        user: 用户对象
    Returns:
        不能查看的字段
    """
    has_perm = user.perm_manager.has_perm

    forbidden_fields = []
    for key, codename in yield_perm_fields_codename():
        if not has_perm(codename):
            forbidden_fields.append(key)
    return forbidden_fields


def get_potential_forbidden_result(user, result, forbidden_fields=None):
    """应用权限后用户可看到的资源数据
    Args:
        user: 用户对象
        result: 一条资源数据
    Returns:
        新的资源数据
    """
    forbidden_fields = forbidden_fields or get_forbidden_perm_fields(user)

    for key in forbidden_fields:
        if key == 'mobile':
            result['mobile'] = utils.cover_mobile(result['mobile'])
        else:
            result[key] = '***'

    return result
