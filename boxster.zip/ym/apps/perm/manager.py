# coding: utf-8

import functools
from rest_framework import status
from rest_framework.response import Response
from . import consts
from . import logics


def has_perm(user, perm):
    """用户是否拥有指定权限
    Args:
        user: 用户对象
        perm: 指定权限
    Returns:
        bool值
    """
    return user.perm_manager.has_perm(perm)


def can_mobile_view(user):
    """可看手机号码
    Args:
        user: 用户对象
    Returns:
        bool值
    """
    return user.perm_manager.has_perm(consts.PERM_MOBILE_VIEW)


def can_potential_view(user):
    """可看所有资源
    Args:
        user: 用户对象
    Returns:
        bool值
    """
    return user.perm_manager.has_perm(consts.PERM_POTENTIAL_VIEW)


def require_perm_is_super(view_func):
    """检查超级用户权限
    """
    perm_codename = consts.PERM_IS_SUPER
    return require_perm(perm_codename)(view_func)


def require_perm(perm, http_methods=None):
    """权限校验装饰器
    """
    def wrapper(view_func):
        @functools.wraps(view_func)
        def view(request, *args, **kwargs):
            # 检查用户权限
            user = request.user
            if not has_perm(user, perm):
                if http_methods is None or request.method in http_methods:
                    return Response({'result': u'您没有权限', 'code': 1},
                                    status=status.HTTP_403_FORBIDDEN)
            return view_func(request, *args, **kwargs)
        return view
    return wrapper


def get_perm_client_data(user):
    """权限数据格式化给前端展示
    """
    own_perms = user.perm_manager.get_user_perms()
    PERMS_ALL = consts.PERMS_ALL
    names = consts.PERMS_NAMES

    def get_init_perm_data(k=None, n=None, v=False):
        return {'k': k, 'n': n, 'v': v, 'p': []}

    def perm_all_depth_scan(data, fdata):
        fkey = fdata['k']

        for ckey, cvalue in data.iteritems():
            k = '{}.{}'.format(fkey, ckey) if fkey else ckey
            n = names.get(k, ckey)
            cdata = get_init_perm_data(k, n)
            fdata['p'].append(cdata)

            if cvalue and isinstance(cvalue, dict):
                perm_all_depth_scan(cvalue, cdata)
            else:
                cdata['v'] = k in own_perms
                cdata.pop('p')

    result = get_init_perm_data()
    perm_all_depth_scan(PERMS_ALL, result)

    return result['p']


def yield_all_perms():
    """迭代返回全部权限
    """
    for codename, name in consts.PERMS.iteritems():
        yield codename, name


def get_userlevel_childs(user, depth=None):
    """获取用户下级所有用户
    """
    return logics.get_child_uids(user.id, depth)


def get_userlevel_parents(user):
    """获取用户上级所有用户
    """
    return logics.get_parent_uids(user.id)
