# coding: utf-8

import weakref
from django.db import models
from django.db.models import Q
from django.contrib.auth.models import User as D_User
from . import consts


class Group(models.Model):
    """分组模型
    """
    name = models.CharField(max_length=32, unique=True)             # 分组名


class Perm(models.Model):
    """权限模型
    """
    codename = models.CharField(max_length=32, primary_key=True)    # 英文说明
    name = models.CharField(max_length=32)                          # 中文说明


class UserPerm(models.Model):
    """用户-权限模型
    """
    user = models.ForeignKey(D_User, null=True, related_name='related_userperm')
    perm = models.ForeignKey(Perm, null=True, related_name='related_userperm')


class UserGroup(models.Model):
    """用户-分组模型
    """
    user = models.ForeignKey(D_User, null=True, related_name='related_usergroup')
    group = models.ForeignKey(Group, null=True, related_name='related_usergroup')


class GroupPerm(models.Model):
    """分组-权限模型
    """
    perm = models.ForeignKey(Perm, null=True, related_name='related_groupperm')
    group = models.ForeignKey(Group, null=True, related_name='related_groupperm')


class UserLevel(models.Model):
    """用户层级结构
    """
    user = models.OneToOneField(D_User)
    parent_id = models.CharField(max_length=128, null=True, blank=True,
                                 verbose_name=u'上级key')


class GroupLevel(models.Model):
    """分组职级层级结构
    """
    group = models.OneToOneField(Group)
    parent_id = models.CharField(max_length=128, null=True, blank=True,
                                 verbose_name=u'上级key')


class PermManager(object):
    """用户权限管理
    """
    # _perm_cache = None
    # _user_perm_cache = None
    # _group_perm_cache = None

    def __init__(self, user):
        self.user = weakref.proxy(user)

    def is_super(self):
        """是否超级用户
        """
        if self.user.is_superuser:
            return True
        return consts.PERM_IS_SUPER in self.get_user_perms()

    def has_perm(self, perm):
        """是否拥有指定权限
        """
        if not self.user.is_active:
            return False
        if not self.user.is_staff:
            return False
        if self.is_super():
            return True
        return perm in self.get_user_perms()

    def get_user_perms(self):
        """获取用户当前拥有基本权限集合
        """
        user = self.user

        if not hasattr(self, '_user_perm_cache'):
            if user.is_superuser:
                perm_objs = Perm.objects.all()
            else:
                perm_objs = Perm.objects.filter(
                    related_userperm__user_id=user.id)

            perms = [d['codename'] for d in perm_objs.values('codename')]
            self._user_perm_cache = set(perms)
        return self._user_perm_cache

    def get_group_perms(self):
        """获取用户当前拥有所有群组的权限集合
        """
        user = self.user

        if not hasattr(self, '_group_perm_cache'):
            if user.is_superuser:
                perm_objs = Perm.objects.all()
            else:
                perm_objs = Perm.objects.filter(
                    related_groupperm__group__related_usergroup__user_id=user.id)
            perms = [d['codename'] for d in perm_objs.values('codename')]
            self. _group_perm_cache = set(perms)
        return self._group_perm_cache

    def get_group_perms_one(self, group_id):
        """获取一个权限分组里的权限集合
        """
        perm_objs = Perm.objects.filter(related_groupperm__group_id=group_id)
        perms = [d['codename'] for d in perm_objs.values('codename')]
        return set(perms)

    def get_all_perms(self):
        """获取用户所有的权限集合
        """
        user = self.user

        if not hasattr(self, '_perm_cache'):
            if user.is_superuser:
                perm_objs = Perm.objects.all()
            else:
                filters = (Q(related_userperm__user_id=user.id) |
                           Q(related_groupperm__group__related_usergroup__user_id=user.id))
                perm_objs = Perm.objects.filter(filters)

            perms = [d['codename'] for d in perm_objs.values('codename')]
            self._perm_cache = set(perms)
        return self._perm_cache


def setdefault_user_perm_manager(user):
    """在用户对象上挂载权限管理对象
    Args:
        user: 用户对象
    Returns:
        PermManger对象
    """
    if not hasattr(user, '_perm_manager'):
        user._perm_manager = PermManager(user)
    return user._perm_manager


# 把权限管理挂到用户model上
D_User.perm_manager = property(setdefault_user_perm_manager)
