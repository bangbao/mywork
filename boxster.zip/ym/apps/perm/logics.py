# coding: utf-8

from collections import OrderedDict
from django.db.models import Q, Case, When, Value
from shunlib.djhelper.expressions import ReplaceF
from . import consts
from .models import (
    Group, GroupPerm, UserGroup, UserPerm, Perm,
    UserLevel, GroupLevel,
)


def add_group_perm(name, perm_ids=None):
    """创建一个权限分组
    Args:
        name: 分组名
        perm_ids: 权限标识列表, 可不传
    """
    perm_ids = perm_ids or []

    new_group = Group.objects.create(name=name)
    group_id = new_group.id
    add_objs = [GroupPerm(perm_id=perm_id, group_id=group_id)
                for perm_id in perm_ids]
    GroupPerm.objects.bulk_create(add_objs)
    return new_group


def change_group_perm(group_id, perm_ids):
    """修改权限分组里的权限
    Args:
        group_id: 分组id
        perm_ids: 权限标识列表
    """
    now_objs = GroupPerm.objects.filter(group_id=group_id)

    perm_ids = set(perm_ids)
    now_perm_ids = set([obj.perm_id for obj in now_objs])
    del_perm_ids = now_perm_ids - perm_ids
    add_perm_ids = perm_ids - now_perm_ids

    if del_perm_ids:
        GroupPerm.objects.filter(group_id=group_id,
                                 perm_id__in=del_perm_ids).delete()
    if add_perm_ids:
        add_objs = [GroupPerm(perm_id=perm_id, group_id=group_id)
                    for perm_id in add_perm_ids]
        GroupPerm.objects.bulk_create(add_objs)


def change_group_perm_by_name(name, perm_ids):
    """修改权限分组里的权限
    Args:
        name: 分组名(岗位名)
        perm_ids: 权限id列表
    """
    group_id = Group.objects.get(name=name).id

    change_group_perm(group_id, perm_ids)


def delete_group_perm(group_id, perm_ids):
    """删除权限分组里的一个权限
    Args:
        group_id: 分组id
        perm_ids: 权限标识列表
    """
    GroupPerm.objects.filter(group_id=group_id,
                             perm_id__in=perm_ids).delete()


def delete_group(group_id):
    """删除一个权限分组
    Args:
        group_id: 分组id
    """
    GroupPerm.objects.filter(group_id=group_id).delete()
    Group.objects.filter(id=group_id).delete()
    UserGroup.objects.filter(group_id=group_id).delete()


def add_user_group(user_id, group_ids):
    """添加用户权限分组
    Args:
        user_id: 用户id
        group_ids: 分组id列表
    """
    add_objs = [UserGroup(user_id=user_id, group_id=group_id)
                for group_id in group_ids]
    UserGroup.objects.bulk_create(add_objs)


def change_user_group(user_id, group_ids):
    """修改用户权限分组
    Args:
        user_id: 用户id
        group_ids: 分组id列表
    """
    now_objs = UserGroup.objects.filter(user_id=user_id)

    group_ids = set(group_ids)
    now_group_ids = set([obj.group_id for obj in now_objs])
    del_group_ids = now_group_ids - group_ids
    add_group_ids = group_ids - now_group_ids

    if del_group_ids:
        UserGroup.objects.filter(user_id=user_id,
                                 group_id__in=del_group_ids).delete()
    if add_group_ids:
        add_objs = [UserGroup(user_id=user_id, group_id=group_id)
                    for group_id in add_group_ids]
        UserGroup.objects.bulk_create(add_objs)


def delete_user_group(user_id, group_ids):
    """删除用户多个权限分组
    Args:
        user_id: 用户id
        group_ids: 分组id列表
    """
    UserGroup.objects.filter(user_id=user_id,
                             group_id__in=group_ids).delete()


def add_user_perm(user_id, perm_ids):
    """添加用户权限
    Args:
        user_id: 用户id
        perm_ids: 权限标识列表
    """
    add_objs = [UserPerm(user_id=user_id, perm_id=perm_id)
                for perm_id in perm_ids]
    UserPerm.objects.bulk_create(add_objs)


def change_user_perm(user_id, perm_ids):
    """修改用户权限
    Args:
        user_id: 用户id
        perm_ids: 权限标识列表
    """
    now_objs = UserPerm.objects.filter(user_id=user_id)

    perm_ids = set(perm_ids)
    now_perm_ids = set([obj.perm_id for obj in now_objs])
    del_perm_ids = now_perm_ids - perm_ids
    add_perm_ids = perm_ids - now_perm_ids

    if del_perm_ids:
        UserPerm.objects.filter(user_id=user_id,
                                perm_id__in=del_perm_ids).delete()
    if add_perm_ids:
        add_objs = [UserPerm(perm_id=perm_id, user_id=user_id)
                    for perm_id in add_perm_ids]
        UserPerm.objects.bulk_create(add_objs)


def delete_user_perm(user_id, perm_ids=None):
    """删除用户权限
    Args:
        user_id: 用户id
        perm_ids: 权限标识列表, 为None删除所有
    """
    filters = dict(user_id=user_id)
    if perm_ids is not None:
        filters.update(perm_id__in=perm_ids)
    UserPerm.objects.filter(**filters).delete()


def set_user_super(user):
    """设定用户为超级用户
    """
    if not user.is_superuser:
        user.is_superuser = True
        user.save()

    perm_id = consts.PERM_IS_SUPER
    if perm_id in consts.PERMS:
        change_user_perm(user.id, [perm_id])


def get_groups_all():
    """获取全部权限分组
    """
    groups_all = Group.objects.all().values('id', 'name').order_by('id')
    return list(groups_all)


def get_perms_all():
    """获取全部权限设置
    """
    perms_all = Perm.objects.all().values('codename', 'name')
    return list(perms_all)


def get_user_groups(user):
    """获取用户权限分组
    """
    groups = Group.objects.filter(
        related_usergroup__user_id=user.id).values('id', 'name')
    return list(groups)


def get_user_perms(user):
    """获取用户基本权限
    """
    perms = Perm.objects.filter(
        related_userperm__user_id=user.id).values('codename', 'name')
    return list(perms)


def init_user_title_perm(user, title):
    """初始化用户职位权限
    Args:
        user: 用户对象
        title: 用户职位
    """
    user_id = user.id
    group_name = title

    perm_objs = Perm.objects.filter(
        related_groupperm__group__name=group_name).values('codename')
    perm_ids = [obj['codename'] for obj in perm_objs]

    change_user_perm(user_id, perm_ids)


def get_group_perms(group_id):
    """获取分组权限
    Args:
        group_id: 分组ID
    Returns:
        该分组权限列表
    """
    perms = Perm.objects.filter(
        related_groupperm__group_id=group_id).values('codename', 'name')
    return list(perms)


def get_group_perms_by_name(group_name):
    """获取分组权限
    Args:
        group_name: 分组名
    Returns:
        该分组权限列表
    """
    perms = Perm.objects.filter(
        related_groupperm__group__name=group_name).values('codename', 'name')
    return list(perms)


def is_perm_codename(perm_key):
    """判断是否是权限的codename
    Args:
        perm_key: 权限值
    Returns:
        bool: True or False
    """
    return not perm_key.endswith('.')


def sync_perm_config():
    """同步代码里的权限配置到数据库里
    """
    now_objs = Perm.objects.values('codename')

    perm_ids = set(consts.PERMS)
    now_perm_ids = set([obj['codename'] for obj in now_objs])
    del_perm_ids = now_perm_ids - perm_ids
    add_perm_ids = perm_ids - now_perm_ids

    if del_perm_ids:
        Perm.objects.filter(codename__in=del_perm_ids).delete()
    if add_perm_ids:
        add_objs = [Perm(codename=perm_id, name=consts.PERMS[perm_id])
                    for perm_id in add_perm_ids]
        Perm.objects.bulk_create(add_objs)


def get_all_userlevel():
    """获取所有节点
    """
    # TODO 优化成一次查询
    userlevel = UserLevel.objects.get(parent_id=None)
    child_parent_id = make_parent_id(userlevel.parent_id, userlevel.user_id)
    query = UserLevel.objects.filter(
        parent_id__startswith=child_parent_id).values('user_id')
    return [d['user_id'] for d in query]


def get_parent_uids(uid):
    """获取一个用户所有的上职级用户uid
    Args:
        uid: 用户uid
    Returns:
        上职级用户uid列表
    """
    try:
        userlevel = UserLevel.objects.get(user_id=uid)
    except UserLevel.DoesNotExist:
        return []

    parent_id = userlevel.parent_id
    if parent_id:
        return parse_parent_id(parent_id)
    return []


def get_child_uids(uid, depth=None):
    """获取一个用户所有的下职级用户uid
    Args:
        uid: 用户uid
        depth: 取到第几级, 默认所有
    Returns:
        下级用户uid列表
    """
    try:
        userlevel = UserLevel.objects.get(user_id=uid)
    except UserLevel.DoesNotExist:
        return []

    child_parent_id = make_parent_id(userlevel.parent_id, userlevel.user_id)
    if depth is not None:
        if depth == 1:
            query = UserLevel.objects.filter(parent_id=child_parent_id)
        else:
            depth_re = '[.]?[0-9]*'
            regex = ['^', child_parent_id]
            regex.extend([depth_re for _ in xrange(depth)])
            regex.append('$')
            regex = ''.join(regex)
            query = UserLevel.objects.filter(parent_id__regex=regex)
    else:
        query = UserLevel.objects.filter(parent_id__startswith=child_parent_id)

    return [d['user_id'] for d in query.values('user_id')]


def parse_parent_id(parent_id):
    """解析职级标识key
    """
    level_ids = parent_id.split('.')
    return map(int, level_ids)


def make_parent_id(pre_parent_id, user_id):
    """生成职级标识key
    """
    if pre_parent_id:
        return '%s.%s' % (pre_parent_id, user_id)
    return '%s' % user_id


def create_userlevel(level_uid, uid):
    """插入一条新的职级
    Args:
        level_uid: 上职级用户uid or None
        uid: 当前职级用户uid
    """
    if level_uid:
        obj = UserLevel.objects.get(user_id=level_uid)
        parent_id = make_parent_id(obj.parent_id, obj.user_id)
    else:
        parent_id = None

    try:
        return UserLevel.objects.create(user_id=uid, parent_id=parent_id)
    except Exception as e:
        print repr(e)


def change_userlevel(new_level_uid, uid):
    """更改用户上职级节点
    """
    try:
        obj = UserLevel.objects.get(user_id=uid)
    except UserLevel.DoesNotExist:
        return create_userlevel(new_level_uid, uid)

    if new_level_uid:
        level_obj = UserLevel.objects.get(user_id=new_level_uid)
        new_parent_id = make_parent_id(level_obj.parent_id, level_obj.user_id)
        old_parent_id = make_parent_id(obj.parent_id, obj.user_id)
        uid_parent_id = new_parent_id
    else:
        new_parent_id = make_parent_id(None, uid)
        old_parent_id = make_parent_id(obj.parent_id, obj.user_id)
        uid_parent_id = None

    if new_parent_id == obj.parent_id:
        return

    filters = Q(parent_id__startswith=old_parent_id) | Q(user_id=uid)
    UserLevel.objects.filter(filters).update(
        parent_id=Case(
            When(user_id=uid, then=Value(uid_parent_id)),
            default=ReplaceF('parent_id', old_parent_id, new_parent_id)
        )
    )


def delete_userlevel(uid, total=False):
    """删除一个职级节点及其子节点
    """
    if not total:
        UserLevel.objects.filter(user_id=uid).delete()
        return

    userlevel = UserLevel.objects.get(user_id=uid)
    parent_id = make_parent_id(userlevel.parent_id, userlevel.user_id)

    filters = Q(user_id=uid) | Q(parent_id__startswith=parent_id)
    UserLevel.objects.filter(filters).delete()


def get_userlevel_map(**filters):
    """获取用户和上级的uid映射
    """
    query = UserLevel.objects.filter(**filters)
    level_map = {}
    for obj in query:
        par_id = None
        if obj.parent_id:
            par_id = parse_parent_id(obj.parent_id)[-1]
            level_map[obj.user_id] = par_id
    return level_map


def get_grouplevel_all():
    """获取所有节点
    """
    query = GroupLevel.objects.values(
        'group_id', 'parent_id', 'group__name').order_by('parent_id')

    return [{'name': obj['group__name'], 'id': obj['group_id']}
            for obj in query]


def get_grouplevel_map(**filters):
    """获取职级上下级映射
    """
    query = GroupLevel.objects.filter(**filters).values(
        'group_id', 'parent_id', 'group__name').order_by('parent_id')
    name_map = dict((obj['group_id'], obj['group__name']) for obj in query)
    level_map = OrderedDict()
    for obj in query:
        par_id = None
        if obj['parent_id']:
            par_id = parse_parent_id(obj['parent_id'])[-1]
        level_map[obj['group__name']] = name_map.get(par_id, None)
    return level_map


def get_grouplevel_parents(group_id):
    """获取一个职级所有的上职级id
    Args:
        group_id: group_id
    Returns:
        上职级id列表
    """
    try:
        level_obj = GroupLevel.objects.get(group_id=group_id)
    except GroupLevel.DoesNotExist:
        return []

    parent_id = level_obj.parent_id
    if parent_id:
        return parse_parent_id(parent_id)
    return []


def get_grouplevel_childs(group_id, depth=None):
    """获取一个职级所有的下职级id
    Args:
        group_id: 用户uid
        depth: 取到第几级, 默认所有
    Returns:
        下职级id列表
    """
    try:
        level_obj = GroupLevel.objects.get(group_id=group_id)
    except GroupLevel.DoesNotExist:
        return []

    child_parent_id = make_parent_id(level_obj.parent_id, level_obj.group_id)
    if depth is not None:
        if depth == 1:
            query = GroupLevel.objects.filter(parent_id=child_parent_id)
        else:
            depth_re = '[.]?[0-9]*'
            regex = ['^', child_parent_id]
            regex.extend([depth_re for _ in xrange(depth)])
            regex.append('$')
            regex = ''.join(regex)
            query = GroupLevel.objects.filter(parent_id__regex=regex)
    else:
        query = GroupLevel.objects.filter(parent_id__startswith=child_parent_id)

    return [d['group_id'] for d in query.values('group_id')]


def create_grouplevel(level_group_id, group_id):
    """插入一条新的职级
    Args:
        level_group_id: 上职级group_id or None
        group_id: 当前职级group_id
    """
    if level_group_id:
        level_obj = GroupLevel.objects.get(group_id=level_group_id)
        parent_id = make_parent_id(level_obj.parent_id, level_obj.group_id)
    else:
        parent_id = None

    try:
        return GroupLevel.objects.create(group_id=group_id, parent_id=parent_id)
    except Exception as e:
        print repr(e)


def change_grouplevel(new_level_group_id, group_id):
    """更改上职级节点
    """
    try:
        obj = GroupLevel.objects.get(group_id=group_id)
    except GroupLevel.DoesNotExist:
        return create_grouplevel(new_level_group_id, group_id)

    if new_level_group_id:
        level_obj = GroupLevel.objects.get(group_id=new_level_group_id)
        new_parent_id = make_parent_id(level_obj.parent_id, level_obj.group_id)
        old_parent_id = make_parent_id(obj.parent_id, obj.group_id)
        group_id_parent_id = new_parent_id
    else:
        new_parent_id = make_parent_id(None, group_id)
        old_parent_id = make_parent_id(obj.parent_id, obj.group_id)
        group_id_parent_id = None

    if new_parent_id == obj.parent_id:
        return

    filters = Q(parent_id__startswith=old_parent_id) | Q(group_id=group_id)
    GroupLevel.objects.filter(filters).update(
        parent_id=Case(
            When(group_id=group_id, then=Value(group_id_parent_id)),
            default=ReplaceF('parent_id', old_parent_id, new_parent_id)
        )
    )


def delete_grouplevel(group_id, total=False):
    """删除一个职级节点及其子节点
    """
    if not total:
        GroupLevel.objects.filter(group_id=group_id).delete()
        return

    level_obj = GroupLevel.objects.get(group_id=group_id)
    parent_id = make_parent_id(level_obj.parent_id, level_obj.group_id)

    filters = Q(group_id=group_id) | Q(parent_id__startswith=parent_id)
    GroupLevel.objects.filter(filters).delete()
