# coding: utf-8

from collections import OrderedDict

PERM_IS_SUPER = 'is_super'
PERM_POTENTIAL_ADD = 'potential_add'
PERM_POTENTIAL_LIST = 'ps.potentials'
PERM_APPOINT_ADVISOR = 'ps.appoint_advisor'
PERM_PUSH_CRP = 'ps.push_crp'
PERM_POTENTIAL_EDIT = 'ps.edit.potential'
PERM_POTENTIAL_VIEW = 'ps.potential_view'
PERM_POTENTIAL_SIGN = 'ps.sign'
PERM_POTENTIAL_REMARK = 'ps.edit.remark'
PERM_POTENTIAL_PROGRAM = 'ps.edit.program'
PERM_MOBILE_VIEW = 'ps.field.mobile'
PERM_STAFF_ADMIN = 'adm.staff_list'
PERM_STAFF_INFO = 'adm.staff_info'
PERM_STAFF_SET_PERM = 'adm.staff_set_perm'
PERM_STAFF_ACTIVE_LIST = 'adm.staff_active_list'
PERM_STAFF_ACTIVE = 'adm.staff_active'
PERM_STAFF_FREEZE = 'adm.staff_freeze'


# 权限树形结构配置, 以`.`结尾的key标识还有下一级, 不能作为权限的codename
# 一些table字段展示权限会在启动时动态映射到此配置
# 添加新权限后, 需要调用logics.sync_perm_config()同步到数据库
# 格式: (key, 中文名字, 前端auth接口返回定义的字段)
PERMS_CONFIG = [
    ('ps.', u'资源面板', None),
    (PERM_POTENTIAL_VIEW, u'查看所有资源', None),
    (PERM_POTENTIAL_LIST, u'资源列表', 'advisor_potentials'),
    ('ps.field.', u'查看', None),
    ('ps.edit.', u'编辑', None),
    (PERM_POTENTIAL_EDIT, u'编辑客户基本信息', 'potential_edit'),
    (PERM_POTENTIAL_REMARK, u'编辑备注', None),
    (PERM_POTENTIAL_PROGRAM, u'编辑申请项目', None),
    (PERM_POTENTIAL_SIGN, u'确认签约', 'potential_sign'),
    (PERM_APPOINT_ADVISOR, u'转资源', 'appoint_advisor'),
    (PERM_PUSH_CRP, u'推送留学', 'push_crp'),

    (PERM_POTENTIAL_ADD, u'资源录入', 'potential_add'),

    ('adm.', u'用户管理', None),
    (PERM_STAFF_ADMIN, u'员工管理', 'staff_admin'),
    (PERM_STAFF_INFO, u'员工查看', 'staff_info'),
    (PERM_STAFF_SET_PERM, u'员工设置权限', 'staff_set_perm'),
    (PERM_STAFF_ACTIVE_LIST, u'员工激活', 'staff_active_list'),
    (PERM_STAFF_ACTIVE, u'激活用户', 'staff_active'),
    (PERM_STAFF_FREEZE, u'冻结用户', 'staff_freeze'),

    # (PERM_IS_SUPER, u'超级用户', None),
]

# 在启动时生成内容
PERMS = OrderedDict()        # 会写到数据库里的数据{codename: name}
PERMS_ALL = OrderedDict()    # 字典可视格式
PERMS_NAMES = {}             # 所有PERMS_ALL中key对应的名字
USER_AUTH_PERMISSON_MAP = {}     # auth接口需要返回的key-codename映射
