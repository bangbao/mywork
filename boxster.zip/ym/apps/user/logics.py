# coding: utf-8

import urllib
from django.conf import settings
from django.contrib.auth import (login as dj_login,
                                 logout as dj_logout)
from django.contrib.auth.models import User
from django.utils import timezone
from shunlib.dtp import dtp
from ym.apps.perm import user as perm_user
from .models import Users


def get_user_auth(user):
    """获取用户基本数据
    Args:
        user: Users实例对象
    """
    users = user.users
    permission = perm_user.get_user_auth_permission(user)

    result = {
        "nickname": users.user_name,    # 来自统一登录
        "email": user.email,            # 来自统一登录
        "mobile": users.mobile,
        "avatar": users.avatar_file,
        "permission": permission,
    }
    return result


def is_super_user(user):
    """判断是否是管理者
    """
    uid = user.id
    if settings.DEBUG:
        return uid in (15, 16, 18, 19, 20, 29, 30, 31)
    return uid in (17, 18, 20, 33, 21)


def can_see_all_potential_perm(user):
    """是否能看所有资源
    """
    uid = user.id
    if not is_super_user(user):
        if settings.DEBUG:
            return uid in (25,)
        return uid in (32, 6, 15, 24, 37)
    return True


def had_advisor_potentials_perm(user):
    """资源面板查看权限
    """
    return True


def had_appoint_advisor_perm(user):
    """转资源权限
    """
    uid = user.id
    if not is_super_user(user):
        if settings.DEBUG:
            return uid in (15, 16, 18, 19, 20)
        return uid in (15,)
    return True


def had_potential_add_perm(user):
    """是否有资源录入权限
    """
    uid = user.id
    if not is_super_user(user):
        if settings.DEBUG:
            return uid in (20, 26, 16, 18, 19)
        return uid in (15, 24)
    return True


def had_potential_edit_perm(user):
    """是否有资源编辑权限
    """
    uid = user.id
    if not is_super_user(user):
        if settings.DEBUG:
            return uid not in (25,)
        return uid not in (32,)
    return True


def can_see_mobile_perm(user):
    """是否可看手机号
    """
    uid = user.id
    if settings.DEBUG:
        return uid not in (25,)
    return uid not in (32,)


def trans_user2advisor(user, title):
    """把用户转换成顾问身份
    """
    from ym.apps.potential.models import Advisor_info

    changed = False
    users = user.users
    if users.title != title:
        users.user_type = title
        users.title = users.user_type
        changed = True
    if not users.name:
        users.name = users.user_name
        changed = True
    if changed:
        users.save()

    nickname = users.user_name
    email = users.email
    # 加入顾问
    try:
        Advisor_info.objects.create(uid=users.uid, first_name=nickname[0],
                                    last_name=nickname[1:], full_name=nickname,
                                    advisor_type=users.user_type, email=email,
                                    visible=1, flag=0, offer_count=800,
                                    address_province=u'北京',
                                    address_city=u'北京市',
                                    address_district=u'朝阳区')
    except:
        Advisor_info.objects.filter(
            uid=user.id).exclude(visible=1).update(visible=1)


def clear_user2advisor(user):
    """把用户解除顾问身份
    """
    from ym.apps.potential.models import Advisor_info

    users = user.users
    users.user_type = None
    users.title = None
    users.save()

    Advisor_info.objects.filter(
        uid=user.id).exclude(visible=0).update(visible=0)


def create_or_sync_user(user_info, only_sync=False):
    """创建新用户或者同步统一登陆数据
    """
    # 查找用户对象
    dtp_id = user_info['p_id']
    mobile = user_info.get('mobile')
    email = user_info.get("email")
    users = None
    try:
        user = User.objects.get(users__dtp_id=dtp_id)
    except User.DoesNotExist:
        if only_sync:
            return None

        # 创建新用户
        user = User.objects.create(
            username=dtp_id,
            email=email,
            password=dtp_id,
            first_name=user_info.get("first_name") or "",
            last_name=user_info.get("last_name") or "",
        )
        users = Users(d_user=user)

    if users is None:
        try:
            users = user.users
        except Users.DoesNotExist:
            users = Users(d_user=user)

    need_save = users.update_data({
        'uid': user.id,
        "dtp_id": dtp_id,
        "user_name": user_info.get("nickname"),
        "mobile": mobile,
        "email": email,
        "sex": user_info.get("sex"),
        "avatar_file": user_info.get("avatar_file"),
        "name": user_info.get("nickname"),
    })
    if need_save:
        users.save()
    return user


def jwt_token_verify(request):
    """验证jwt_token是否有效
    jwt_token不存在或者过期, 判定用户登陆失效
    {'expires': '2016-07-29T02:59:51.542Z', 'p_id': '8629999af58a11e58e84'}
    """
    jwt_token = request.COOKIES.get('jwt-token')

    if not jwt_token:
        dj_logout(request)
        return None

    jwt_token = urllib.unquote(jwt_token)
    jwt_data = dtp.decode_token(jwt_token)

    p_id = jwt_data['p_id']
    expires = jwt_data['expires']
    now = timezone.now().strftime('%Y-%m-%dT%H:%M:%SZ')

    if expires <= now:
        dj_logout(request)
        return None

    if not request.user.is_authenticated() or request.user.users.dtp_id != p_id:
        try:
            user_info = dtp.get_user(p_id, project_type=settings.DTP_PROJECT_TYPE)
        except Exception as e:
            print e
            return None
        user = create_or_sync_user(user_info)
        user.backend = settings.AUTHENTICATION_BACKENDS[0]
        dj_login(request, user)

    return request.user.id
