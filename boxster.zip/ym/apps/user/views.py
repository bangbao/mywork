# coding: utf-8

from rest_framework import status
from rest_framework.response import Response
from django.conf import settings
from django.db.models import Q
from django.contrib.auth import (login as dj_login,
                                 logout as dj_logout)
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from shunlib.dtp import dtp
from shunlib.utilities.decorators import api_view
from ym.apps.user import logics as user_logics
from ym.apps.user.models import Users


@api_view(['GET'])
def dtp_login(request):
    """DTP token 登录
    """
    token = request.query_params.get('token')
    redirect_url = request.query_params.get("r")

    if not token:
        return Response({'code': 1, 'result': u'TOKEN错误'},
                        status=status.HTTP_400_BAD_REQUEST)

    try:
        user_info = dtp.get_user_by_token(token, project_type="boxster")
    except dtp.NetworkError, e:
        return Response({'code': 1, 'result': e.message},
                        status=status.HTTP_400_BAD_REQUEST)
    except dtp.DtpError, e:
        return Response({'code': 1, 'result': e.message},
                        status=status.HTTP_401_UNAUTHORIZED)

    user = user_logics.create_or_sync_user(user_info)
    # 写入登录信息
    user.backend = settings.AUTHENTICATION_BACKENDS[0]
    dj_login(request, user)

    # 判断是否跳转
    if redirect_url:
        headers = {'Location': redirect_url}
        return Response(status=status.HTTP_302_FOUND, headers=headers)
    return HttpResponseRedirect('/')


@api_view(['POST', 'GET'])
def userlogin(request):
    """系统登录
    TODO:
        临时使用. 统一登陆上线后要屏蔽
    """
    email = request.query_params.get('email', '').replace(' ', '+')
    mobile = request.query_params.get('mobile', '')

    if not email and not mobile:
        return {'code': 1, 'result': u'账户错误'}

    query = Users.objects.filter(Q(email=email) | Q(mobile=mobile))
    if not query.exists():
        return {'code': 1, 'result': u'没找到'}

    users = query[0]
    user = User.objects.get(id=users.uid)

    # 写入登录信息
    user.backend = settings.AUTHENTICATION_BACKENDS[0]
    dj_login(request, user)

    result = user_logics.get_user_auth(user)
    return {'code': 0, 'result': result}


# @api_view(['POST'])
# def register(request):
#     """BI系统注册
#     """
#     userinfo = {
#         "username": request.data['username'],
#         "email": request.data['email'],
#         "password": request.data['password'],
#         "first_name": request.data.get('first_name', ''),
#         "last_name": request.data.get('last_name', ''),
#     }
#     if User.objects.filter(username=userinfo["username"]).exists():
#         return Response({'result': '用户名已存在'},
#                         status=status.HTTP_403_FORBIDDEN)
#     if User.objects.filter(email=userinfo["email"]).exists():
#         return Response({'result': 'E-mail已存在'},
#                         status=status.HTTP_403_FORBIDDEN)
#
#     # 创建用户
#     user = User.objects.create_user(**userinfo)
#     user.save()
#
#     pmngr = PermissionManager(user)
#     result_dict = {
#         'result': {
#             'username': user.username,
#             'email': user.email,
#             'first_name': user.first_name,
#             'last_name': user.last_name,
#             'permission': {
#                 'name': pmngr.permission_model.name,
#                 'charts': [c.id for c in pmngr.permission_model.charts.all()],
#             },
#         },
#     }
#     result_dict['result']['permission'].update(
#         pmngr.permission_model.permissions)
#
#     # 自动登录
#     auth_user = authenticate(username=userinfo["username"],
#                              password=userinfo["password"])
#     dj_login(request, auth_user)
#     return Response(result_dict, status=status.HTTP_200_OK)


@api_view(['GET'])
def userlogout(request):
    """系统登出
    """
    dj_logout(request)
    return {'code': 0, 'result': u'登出成功'}


@api_view(['POST', 'GET'])
def get_auth(request):
    """获取用户基本信息
    """
    user = request.user
    users = getattr(user, 'users', None)
    if not users:
        try:
            users = Users.objects.get(uid=user.id)
        except Users.DoesNotExist:
            # django后台创建的用户登陆注册不走dtp_login, 刚调用时直接初始化Users表数据
            if user.is_staff:
                user_name = '{}{}'.format(user.first_name, user.last_name)
                users = Users.objects.create(uid=user.id,
                                             d_user_id=user.id,
                                             email=user.email,
                                             user_name=user_name)
            else:
                return Response({'result': u'没找到Users信息'},
                                status=status.HTTP_400_BAD_REQUEST)

    result = user_logics.get_user_auth(user)
    return {'code': 0, 'result': result}


@api_view(['POST'])
def dtp_sync_user_info(request):
    """同步统一登陆用户数据
    """
    user_info = request.data

    if 'p_id' not in user_info:
        return {'code': 1, 'result': 'error'}

    user = user_logics.create_or_sync_user(user_info, only_sync=True)

    if not user:
        return {'code': 2, 'result': 'not exists'}

    return {'code': 0, 'result': 'success'}
