# coding: utf-8

from django.db import models
from django.db.models.signals import post_save
from django.contrib.auth.models import User as D_User
from shunlib.djhelper import base_model


class Users(models.Model):
    """用户扩展基本数据
    """
    d_user = models.OneToOneField(D_User)
    uid = models.IntegerField(primary_key=True)
    dtp_id = models.CharField(max_length=40, null=True)
    user_name = models.CharField(max_length=255, null=True)
    email = models.CharField(max_length=255, null=True)
    mobile = models.CharField(max_length=16, null=True)
    avatar_file = models.CharField(max_length=128, null=True)
    sex = models.CharField(max_length=12, null=True, blank=True)
    user_type = models.CharField(max_length=10, null=True, blank=True)
    sysid = models.IntegerField(null=True, blank=True,
                                verbose_name=u'员工编号')
    name = models.CharField(max_length=128, null=True, blank=True,
                            verbose_name=u'员工姓名')
    attribution = models.CharField(max_length=128, null=True, blank=True,
                                   verbose_name=u'分公司')
    country = models.CharField(max_length=128, null=True, blank=True,
                               verbose_name=u'国家')
    title = models.CharField(max_length=128, null=True, blank=True,
                             verbose_name=u'岗位')
    levels = base_model.JSONField(null=True, blank=True,
                                  verbose_name=u'员工角色')
    sync_time = models.DateTimeField(max_length=20, null=True, blank=True)  # 同步时间

    def update_data(self, data):
        need_save = False
        for k, v in data.iteritems():
            if getattr(self, k) != v:
                setattr(self, k, v)
                need_save = True
        return need_save

    @classmethod
    def connect_signal(cls):
        from ym.apps.potential.callbacks import sync_user_advisor_info
        post_save.connect(receiver=sync_user_advisor_info, sender=cls)

Users.connect_signal()
