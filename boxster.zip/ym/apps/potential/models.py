# -*- coding: utf-8 -*-

import os
import copy
import datetime
from django.conf import settings
from django.db import models
from django.db.models import Q
from django.db.models.manager import Manager
from django.db.models.functions import Concat
from django.utils import timezone
from django.db.models.signals import post_save, pre_save
from shunlib.djhelper.base_model import AdvanceManager
from audit_log.models.managers import AuditLog
from . import consts
from .AuditLogs import AdvisorPotentialStudentAuditLog


class Advisor_info(models.Model):
    uid = models.IntegerField(unique=True)
    first_name = models.CharField(max_length=10)
    last_name = models.CharField(max_length=10)
    full_name = models.CharField(max_length=20)
    english_name = models.CharField(max_length=20)
    advisor_type = models.CharField(max_length=10, null=True)
    identity_number = models.CharField(max_length=30)
    birthday = models.DateField(null=True, blank=True, default=None)
    email = models.CharField(max_length=100)
    address_province = models.CharField(max_length=20)
    address_city = models.CharField(max_length=20)
    address_district = models.CharField(max_length=20)
    address_detail = models.CharField(max_length=100)
    address_postcode = models.CharField(max_length=10)
    strength_program = models.CharField(max_length=100)     # 格式：美国:本科;加拿大:研究生
    mobile = models.CharField(max_length=16)
    gender = models.CharField(max_length=10)
    visible = models.IntegerField(default=0)
    offer_count = models.IntegerField(null=True)
    pause_start = models.DateTimeField(null=True)
    pause_end = models.DateTimeField(null=True)
    entry_time = models.DateTimeField(null=True)
    flag = models.IntegerField(default=0)
    vacation_weekdays = models.CharField(max_length=32, null=True)  # 假日
    main_qualification = models.IntegerField(null=True)  # 主要资质
    other_qualifications = models.TextField(null=True)  # 次要资质
    crp_advisor_id = models.IntegerField(null=True)     # crp顾问id
    objects = AdvanceManager()
    search_fields = ["full_name"]
    audit_log = AuditLog()

    @classmethod
    def get_accept_source_query(cls):
        """可接收资源顾问的过滤条件
        """
        now = timezone.now()
        return(Q(flag=0) & (Q(pause_start__isnull=True) |
               Q(pause_start__gt=now) | Q(pause_end__lte=now)))

    @classmethod
    def get_refuse_source_query(cls):
        """不接收资源顾问的过滤条件
        """
        now = timezone.now()
        return Q(pause_start__lte=now, pause_end__gt=now)

    @classmethod
    def get_default_advisor(cls, only_name=False):
        """获取默认跟进顾问
        """
        query = cls.objects.order_by('-offer_count')[:1]
        if query:
            advisor = query[0]
        else:
            advisor = cls.objects.get(full_name=consts.FOLLOW_PERSON_DEFUALT)

        if only_name:
            return advisor.full_name
        return advisor

    def get_vacation_weekdays(self):
        weekdays = []
        if self.vacation_weekdays:
            weekdays += [int(d) for d in self.vacation_weekdays.split(",")]
        return weekdays

    def in_holiday(self):
        """判断顾问是否在假期
        """
        today = datetime.date.today()
        vacation_weekdays = self.get_vacation_weekdays()
        if today.weekday() in vacation_weekdays:
            workday = self.advisorvacationday_set.filter(
                advisor=self, date=today, work=True)
            if workday.exists():
                return False
            return True

        holiday = self.advisorvacationday_set.filter(
            advisor=self, date=today, work=False)
        return holiday.exists()


class AdvisorVacationDay(models.Model):
    """顾问假期机动配置
    """
    advisor = models.ForeignKey(Advisor_info)       # 顾问外键
    date = models.DateField()                       # 日期
    work = models.BooleanField(default=False)       # 0-假日，1-工作日

    class Meta:
        unique_together = ('advisor', 'date')


class Advisor_alloc_num(models.Model):
    """记录顾问被分配资源数
    """
    advisor_uid = models.IntegerField()                     # 顾问uid
    city = models.CharField(max_length=32, null=True)       # 城市
    country = models.CharField(max_length=32, null=True)    # 国家
    education = models.CharField(max_length=32, null=True)  # 项目
    alloc_num = models.IntegerField(default=0)              # 本轮已分配资源数
    weight = models.IntegerField(default=10)                # 配置权重
    dynamic_weight = models.IntegerField(default=10)        # 动态（计算）权重
    last_alloc_flag = models.IntegerField(default=0)        # 上次分配顾问标志


class Advisor_alloc_statistics(models.Model):
    """记录顾问被分配资源数统计
    """
    advisor_uid = models.IntegerField()                     # 顾问uid
    potential_id = models.IntegerField()                    # 分配的资源id
    city = models.CharField(max_length=32, null=True)       # 城市
    country = models.CharField(max_length=32, null=True)    # 国家
    education = models.CharField(max_length=32, null=True)  # 项目
    num = models.IntegerField(default=1)                    # 本轮已分配资源数
    is_specific = models.BooleanField(default=False)        # 是否指定分配
    create_at = models.DateTimeField(auto_now_add=True)


class Advisor_service_experience(models.Model):
    uid = models.IntegerField()
    customer_name = models.CharField(max_length=20)
    customer_city = models.CharField(max_length=20)
    customer_program = models.CharField(max_length=30)
    customer_service_description = models.TextField()
    customer_service_result = models.TextField()


class Advisor_potential_student_queryset(models.query.QuerySet):
    """支持全文搜索的queryset
    """
    # 需要搜索的字段
    search_fields = [
        'user_name', 'first_name', 'last_name', 'mobile', 'phone',
        'other_phone', 'full_name',
        'current_school', 'current_grade', 'program_title', 'planning_year',
        'comefrom', 'xifenqudao', 'id']

    def search(self, keywords, search_remark=False, search_advisor=False):
        search_query = self
        for keyword in keywords:
            filters = Q()

            for field in self.search_fields:
                filters |= Q(**{"%s__icontains" % field: keyword})
            # 搜索备注
            if search_remark:
                remark_query = Advisor_student_remark.objects.filter(
                    Q(content__icontains=keyword))
                potential_ids = [q["potential_id"] for q in
                                 remark_query.values("potential_id").distinct()]
                if potential_ids:
                    filters |= Q(id__in=set(potential_ids))
            # 搜索顾问
            if search_advisor:
                advisor_filters = Q(advisor_name__icontains=keyword) |\
                    Q(mobile__icontains=keyword) |\
                    Q(address_city__icontains=keyword)
                advisor_query = Advisor_info.objects.annotate(
                    advisor_name=Concat('first_name', 'last_name')).filter(
                        advisor_filters)
                advisor_uids = [q["uid"] for q in
                                advisor_query.values("uid").distinct()]
                if advisor_uids:
                    filters |= Q(uid__in=set(advisor_uids))
            search_query = search_query.filter(filters)
        return search_query

    def filter2(self, filter_country_program=False, **kwargs):
        search_query = self
        filters = Q()
        # 搜索移民国家和项目
        if filter_country_program:
            country_pids = []
            program_pids = []
            if kwargs['countries']:
                country_query = Advisor_student_country.objects.filter(
                    Q(country__in=kwargs['countries']))
                country_pids = [q["potential_id"] for q in
                                country_query.values("potential_id").distinct()]
            if kwargs['programs']:
                program_query = Advisor_student_program.objects.filter(
                    Q(program__in=kwargs['programs']))
                program_pids = [q["potential_id"] for q in
                                program_query.values("potential_id").distinct()]
            if kwargs['countries'] and kwargs['programs']:
                potential_ids = set(country_pids) & set(program_pids)
            elif kwargs['countries'] and not kwargs['programs']:
                potential_ids = set(country_pids)
            elif not kwargs['countries'] and kwargs['programs']:
                potential_ids = set(program_pids)
            else:
                potential_ids = None
            if potential_ids is not None:
                filters |= Q(id__in=potential_ids)

        search_query = search_query.filter(filters)
        return search_query


class Advisor_potential_student_manager(Manager):
    def get_queryset(self):
        return Advisor_potential_student_queryset(self.model, using=self._db)


class Advisor_potential_student(models.Model):
    uid = models.IntegerField(verbose_name=u'顾问uid')
    user_name = models.CharField(max_length=50, blank=True,
                                 null=True, verbose_name=u'用户名')
    student_uid = models.IntegerField(null=True, verbose_name=u'学生uid')
    first_name = models.CharField(max_length=20, blank=True, null=True)
    last_name = models.CharField(max_length=20, blank=True, null=True)
    full_name = models.CharField(max_length=40, blank=True,
                                 null=True, verbose_name=u'姓名')
    gender = models.CharField(max_length=10, blank=True, null=True)
    mobile = models.CharField(max_length=20, blank=True,
                              null=True, verbose_name=u'电话')
    phone = models.CharField(max_length=20, blank=True, null=True)          # 固定电话
    other_phone = models.CharField(max_length=20, blank=True, null=True)    # 其它电话
    qq = models.CharField(max_length=20, blank=True, null=True)             # QQ
    email = models.CharField(max_length=32, blank=True, null=True)          # 电子邮箱
    wechat = models.CharField(max_length=32, blank=True, null=True,
                              verbose_name=u'微信')
    current_school = models.CharField(max_length=30, blank=True, null=True)
    current_grade = models.CharField(max_length=8, blank=True, null=True)
    current_professional = models.CharField(max_length=32, null=True)   # 目前专业
    gpa = models.CharField(max_length=20, blank=True, null=True)
    SSAT = models.CharField(max_length=20, blank=True, null=True)
    SSAT_percent = models.CharField(max_length=20, blank=True, null=True)
    SAT = models.CharField(max_length=20, blank=True, null=True)
    SLEP = models.CharField(max_length=20, blank=True, null=True)
    toefl_total = models.CharField(max_length=20, blank=True, null=True)
    program_title = models.CharField(max_length=32, blank=True, null=True)
    country = models.CharField(max_length=30, null=True, verbose_name=u'申请国家')
    education = models.CharField(max_length=30, null=True, verbose_name=u'申请学历')
    professional = models.CharField(max_length=32, null=True,
                                    verbose_name=u'申请专业')
    planning_year = models.CharField(max_length=10, blank=True, null=True)
    product_id = models.IntegerField(null=True, default=0, blank=True)
    is_chosen = models.IntegerField(default=0, verbose_name=u'是否已签约')
    status = models.IntegerField(default=0, null=True, verbose_name=u'状态')
    rate = models.IntegerField(default=1, null=True,
                               verbose_name=u'星级')
    entry_time = models.DateTimeField(null=True)  # 录入时间
    rebate = models.CharField(max_length=20, null=True)  # 返点
    create_at = models.DateTimeField(auto_now_add=True,
                                     verbose_name=u'录入时间')
    modify_at = models.DateTimeField(auto_now=True)
    alloc_at = models.DateTimeField(auto_now_add=True)  # 资源分配时间
    source = models.CharField(max_length=20, null=True, verbose_name=u'数据源')
    comefrom = models.CharField(max_length=20, null=True, blank=True,
                                verbose_name=u'来源')
    xifenqudao = models.CharField(max_length=20, null=True, blank=True,
                                  verbose_name=u'细分渠道')
    qudao_details = models.CharField(max_length=32, null=True, blank=True,
                                     verbose_name=u'渠道详情')
    houxuan_country1 = models.CharField(max_length=32, null=True)
    houxuan_country2 = models.CharField(max_length=32, null=True)
    houxuan_country3 = models.CharField(max_length=32, null=True)
    chosen_time = models.DateTimeField(null=True)  # 签约时间
    latest_remark_time = models.DateTimeField(null=True)  # 最近备注时间
    origin_id = models.CharField(max_length=10, null=True)
    crm_create_user = models.CharField(max_length=12, null=True)  # crm座席ID
    follow_person = models.CharField(max_length=32, null=True,
                                     verbose_name=u'跟进顾问')
    resource_address = models.CharField(max_length=32, null=True)  # 资源地址
    visit_reminder_time = models.DateTimeField(null=True)  # 资源回访提醒时间
    freezing_end_time = models.DateTimeField(null=True)  # 资源冻结结束时间
    expire_time = models.DateTimeField(null=True)  # 过期时间
    expire_level = models.IntegerField(null=True)  # 应回访天
    VIP_intent = models.NullBooleanField(default=False)  # 尊享意向
    # 移民新增字段
    marital_status = models.CharField(max_length=32, null=True,
                                      verbose_name=u'婚姻状况')
    linguistic_competence = models.CharField(max_length=32, null=True,
                                             verbose_name=u'语言能力')
    gross_assets = models.IntegerField(default=0, null=True,
                                       verbose_name=u'总资产')
    follow_status = models.IntegerField(default=0, null=True,
                                        verbose_name=u'跟进状态')
    expendable_fund = models.IntegerField(default=0, null=True,
                                          verbose_name=u'可用资金')
    bm_experience = models.CharField(max_length=32, null=True,
                                     verbose_name=u'商业管理经验')
    crp_potential_id = models.IntegerField(null=True, blank=True,
                                           verbose_name=u'crp推送资源id')
    ym_mobile = models.CharField(max_length=20, blank=True, null=True,
                                 verbose_name=u'移民联系人联系方式')
    ym_username = models.CharField(max_length=30, blank=True, null=True,
                                   verbose_name=u'移民联系人姓名')
    tuijian_name = models.CharField(max_length=30, blank=True, null=True,
                                    verbose_name=u'推荐人姓名')
    tuijian_mobile = models.CharField(max_length=20, blank=True, null=True,
                                      verbose_name=u'推荐人电话')
    tuijian_branch = models.CharField(max_length=20, blank=True, null=True,
                                      verbose_name=u'推荐人所属分公司')
    tuijian_depart = models.CharField(max_length=20, blank=True, null=True,
                                      verbose_name=u'推荐人所属部门')
    attribution = models.CharField(max_length=20, blank=True, null=True,
                                   verbose_name=u'用户所在地')
    is_push_crp = models.NullBooleanField(default=False)

    objects = Advisor_potential_student_manager()
    audit_log = AdvisorPotentialStudentAuditLog()

    class Meta:
        verbose_name = "资源"
        verbose_name_plural = "资源分配表"

    def __init__(self, *argv, **kwargs):
        super(Advisor_potential_student, self).__init__(*argv, **kwargs)
        # 记录下该条记录的初始状态
        self._init_instance = copy.deepcopy(self)

    def __del__(self):
        if hasattr(self, "_init_instance"):
            del self._init_instance

    def save(self, *args, **kwargv):
        if not self.full_name:
            if self.first_name or self.last_name:
                self.full_name = (self.first_name or '') +\
                                 (self.last_name or '')
            elif self.user_name:
                self.full_name = self.user_name
        if str(self.is_chosen) == '1' or str(self.status) == '66':
            self.is_chosen = 1
            self.status = 66
            if not self.chosen_time:
                self.chosen_time = timezone.now()
        # 规范手机号格式
        if self.mobile and not self.mobile.isdigit():
            self.mobile = self.mobile.strip()
            self.mobile = ''.join([x for x in self.mobile
                                   if x.isdigit() or x == '+'])
        super(Advisor_potential_student, self).save(*args, **kwargv)

        if hasattr(self, "_init_instance"):
            del self._init_instance
        self._init_instance = copy.deepcopy(self)

    @classmethod
    def connect_signal(cls):
        from ym.utilities.callbacks import update_crm_resource
        post_save.connect(receiver=update_crm_resource, sender=cls)

Advisor_potential_student.connect_signal()


class RelatedPotentialStudent(models.Model):
    potential = models.ForeignKey(Advisor_potential_student, null=True)
    related_potential = models.ForeignKey(Advisor_potential_student,
                                          related_name='related_potential',
                                          null=True, blank=True)


class Advisor_student_remark(models.Model):
    potential_id = models.IntegerField(null=True)
    advisor_uid = models.IntegerField(null=True)
    content = models.TextField(blank=True, null=True)
    create_at = models.DateTimeField(auto_now_add=True)
    modify_at = models.DateTimeField(auto_now=True)
    potential_foreign = models.ForeignKey(Advisor_potential_student,
                                          null=True,
                                          related_name='related_remarks')


class Unfollowed_potential_student(models.Model):
    """记录预期未跟进的资源
    """
    potential_id = models.IntegerField()        # 意向客户表ID
    advisor_uid = models.IntegerField()         # 顾问uid
    owned_hours = models.IntegerField()         # 预期跟进时间上限小时数
    expire_flag = models.IntegerField()         # 资源过期类型（0-即将过期, 1-已经过期）
    create_at = models.DateTimeField(auto_now_add=True)   # 记录时间
    followed = models.IntegerField(default=0)   # 是否在记录后已跟进


class AdvisorServiceExperience(models.Model):
    uid = models.IntegerField(null=True, blank=True)
    is_vip = models.NullBooleanField(default=False)
    customer_city = models.CharField(max_length=25, blank=True, null=True)
    customer_application_city = models.CharField(max_length=25, blank=True, null=True)
    customer_program = models.CharField(max_length=25, null=True)
    customer_application_season = models.CharField(max_length=25, null=True)
    customer_current_degree = models.CharField(max_length=25, blank=True, null=True)
    customer_current_country = models.CharField(max_length=25, blank=True, null=True)
    customer_name = models.CharField(max_length=25, null=True)
    operation_advisor = models.CharField(max_length=25, null=True)
    service_advisor = models.CharField(max_length=25, null=True)
    customer_current_school = models.CharField(max_length=50, null=True)
    customer_current_major = models.CharField(max_length=50, blank=True, null=True)
    customer_current_major_type = models.CharField(max_length=50, blank=True, null=True)
    service_advisor = models.CharField(max_length=50, blank=True, null=True)
    customer_application_transfer_credit = models.CharField(max_length=50,
                                                            blank=True, null=True)
    customer_application_Nuffic = models.CharField(max_length=50, blank=True, null=True)
    customer_application_rejected_country = models.CharField(max_length=50,
                                                             blank=True, null=True)
    location = models.CharField(max_length=50, blank=True, null=True)
    create_time = models.DateTimeField(auto_now_add=True)
    customer_GPA = models.FloatField(blank=True, null=True, default=0)
    customer_average_score = models.CharField(blank=True, null=True, max_length=16)
    customer_application_year = models.IntegerField(null=True, blank=True)
    customer_service_description = models.TextField(null=True, blank=True)
    customer_service_title = models.CharField(null=True, blank=True, max_length=255)
    remark = models.TextField(blank=True, null=True)
    application_major_detail = models.CharField(max_length=24, null=True, blank=True)
    current_school_level = models.CharField(max_length=24, null=True, blank=True)
    is_new = models.NullBooleanField(null=True, blank=True, default=False)

    class Meta:
        ordering = ['-create_time']


class AddActivity(models.Model):
    advisor_service_experience = models.ForeignKey(
        AdvisorServiceExperience, related_name="add_activities")
    name = models.CharField(max_length=255)
    position = models.CharField(max_length=255, blank=True)
    activity_type = models.CharField(max_length=25, blank=True)
    des = models.TextField(blank=True)
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('advisor_service_experience', "name", "position")
        ordering = ['create_time']


class Advisor_score(models.Model):
    advisor_uid = models.IntegerField(unique=True)
    total_score = models.FloatField(null=True, blank=True, default=10)
    deduct_score = models.FloatField(null=True, blank=True, default=0)
    deduct_reason = models.TextField(null=True, blank=True)  # history 0-24
    remain_score = models.FloatField(null=True, blank=True, default=10)
    expire_1 = models.TextField(null=True, blank=True)  # history 0-24
    expire_3 = models.TextField(null=True, blank=True)  # history 24-72
    expire_5 = models.TextField(null=True, blank=True)  # history 72-120
    expire_10 = models.TextField(null=True, blank=True)  # history 120-240
    expire_long = models.TextField(null=True, blank=True)  # history > 30
    # Score of the exam of rule
    exam1_score = models.IntegerField(null=True, blank=True)
    exam2_score = models.IntegerField(null=True, blank=True)
    exam3_score = models.IntegerField(null=True, blank=True)
    new_1 = models.TextField(null=True, blank=True)  # new 0-24
    new_3 = models.TextField(null=True, blank=True)  # new 24-72
    new_5 = models.TextField(null=True, blank=True)  # new 72-120
    new_10 = models.TextField(null=True, blank=True)  # new 120-240
    new_long = models.TextField(null=True, blank=True)  # new > 30
    soon_expire_1 = models.TextField(null=True, blank=True)
    soon_expire_3 = models.TextField(null=True, blank=True)
    soon_expire_5 = models.TextField(null=True, blank=True)
    soon_expire_10 = models.TextField(null=True, blank=True)
    soon_expire_long = models.TextField(null=True, blank=True)
    last_reset = models.DateTimeField(null=True)  # last time of reset
    month_zero_count = models.IntegerField(default=0)
    zero_count = models.IntegerField(default=0)


class Admission(models.Model):
    advisor_service_experience = models.ForeignKey(
        AdvisorServiceExperience, related_name="admissions")
    country = models.CharField(max_length=25, null=True, blank=True)
    degree = models.CharField(max_length=25, blank=True, null=True)
    school = models.CharField(max_length=50, null=True, blank=True)
    major = models.CharField(verbose_name=u"录取专业", max_length=50,
                             blank=True)
    scholarship = models.IntegerField(null=True, blank=True)
    EA_ED_RD = models.CharField(max_length=25, blank=True, null=True)
    is_chosen = models.BooleanField(default=False)
    create_time = models.DateTimeField(auto_now_add=True)
    upload_dir = os.path.join(settings.MEDIA_ROOT, "badge")
    badge = models.ImageField(upload_to=upload_dir, null=True, blank=True)
    english_name = models.CharField(max_length=255, null=True, blank=True)
    received_time = models.DateField(null=True, blank=True)
    major_type = models.CharField(max_length=32, blank=True, null=True)
    major_detail = models.CharField(max_length=32, blank=True, null=True)
    year = models.IntegerField(null=True, blank=True)
    term = models.CharField(max_length=8, null=True, blank=True)

    class Meta:
        ordering = ['create_time']


class Exam(models.Model):
    advisor_service_experience = models.ForeignKey(
        AdvisorServiceExperience, related_name="exams")
    name = models.CharField(max_length=25)
    score = models.FloatField(null=True, blank=True, default=10)
    create_time = models.DateTimeField(auto_now_add=True)
    related_id = models.IntegerField(null=True, blank=True)

    class Meta:
        unique_together = ('advisor_service_experience', "name", "score")
        ordering = ['create_time']


class Advisor_student_country(models.Model):
    """移民申请国家数据
    """
    country = models.CharField(max_length=32, null=True, verbose_name=u'国家')
    has_visa = models.NullBooleanField(verbose_name=u'有无签证')
    has_relatives = models.NullBooleanField(verbose_name=u'有无亲属')
    type = models.IntegerField(default=0, null=True, verbose_name=u'国家')
    potential_id = models.IntegerField(null=True)
    advisor_uid = models.IntegerField(null=True)
    student_uid = models.IntegerField(null=True)
    create_at = models.DateTimeField(auto_now_add=True)
    modify_at = models.DateTimeField(auto_now=True)
    potential_foreign = models.ForeignKey(Advisor_potential_student,
                                          null=True,
                                          related_name='related_countries')


class Advisor_student_program(models.Model):
    """移民项目信息数据
    """
    country = models.CharField(max_length=32, null=True)    # 该项目对应的国家
    program = models.CharField(max_length=64, null=True)    # 技术移民，投资移民
    type = models.IntegerField(default=0, null=True)        # 1首选项目，0候选项目
    potential_id = models.IntegerField(null=True)
    advisor_uid = models.IntegerField(null=True)
    student_uid = models.IntegerField(null=True)
    create_at = models.DateTimeField(auto_now_add=True)
    modify_at = models.DateTimeField(auto_now=True)
    potential_foreign = models.ForeignKey(Advisor_potential_student,
                                          null=True,
                                          related_name='related_programs')
