# coding: utf-8

from django.db import models
from audit_log.models.managers import AuditLog


class AdvisorPotentialStudentAuditLog(AuditLog):

    ignore_update_fields = ('modify_at',)

    def create_log_entry(self, instance, action_type):
        manager = getattr(instance, self.manager_name)
        attrs = {}
        update_fields = []
        for field in instance._meta.fields:
            if field.attname not in self._exclude:
                attrs[field.attname] = getattr(instance, field.attname)
                if getattr(instance, field.attname) != getattr(instance._init_instance, field.attname) and \
                        action_type == "U" and field.attname not in self.ignore_update_fields:
                    update_fields.append(field.attname)
        if update_fields:
            attrs["update_fields"] = ",".join(update_fields)
        manager.create(action_type=action_type, **attrs)

    def get_logging_fields(self, model):
        fields = super(AdvisorPotentialStudentAuditLog, self).get_logging_fields(model)
        fields["update_fields"] = models.CharField(max_length=128, null=True)
        return fields
