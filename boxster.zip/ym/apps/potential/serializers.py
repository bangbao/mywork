# coding: utf-8

import datetime
from rest_framework import serializers
from shunlib.utilities.serializerutils import UnixEpochDateField
from ym.utilities.crmcomm import MyCrmComm
from .models import (
    Advisor_info,
    Advisor_score,
    Advisor_student_program,
    Advisor_student_country,
    Advisor_student_remark,
    Advisor_potential_student,
    Advisor_service_experience,
)


class AdvisorInfoSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    uid = serializers.IntegerField()
    first_name = serializers.CharField(required=True)
    last_name = serializers.CharField(required=False, allow_blank=True, max_length=20)
    full_name = serializers.CharField(required=False, allow_blank=True, max_length=20)
    english_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    advisor_type = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    identity_number = serializers.CharField(required=True, allow_blank=True, allow_null=True)
    birthday = serializers.DateField(required=False, allow_null=True)
    email = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    address_province = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    address_city = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    address_district = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    address_detail = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    address_postcode = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    strength_program = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    mobile = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    gender = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    visible = serializers.IntegerField(required=False)
    pause_start = UnixEpochDateField(required=False, allow_null=True)
    pause_end = UnixEpochDateField(required=False, allow_null=True)
    entry_time = UnixEpochDateField(required=False, allow_null=True)
    flag = serializers.IntegerField(required=False)
    main_qualification = serializers.IntegerField(required=False)  # 主要资质
    other_qualifications = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)  # 次要资质
    crp_advisor_id = serializers.CharField(required=False)              # crp顾问id

    def create(self, validated_data):
        return Advisor_info.objects.create(**validated_data)

    def update(self, instance, validated_data):
        field_names = instance._meta.get_all_field_names()
        for key, value in validated_data.iteritems():
            if key in field_names:
                setattr(instance, key, value)

        instance.save()
        return instance


class AdvisorServiceExperienceSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    uid = serializers.IntegerField()
    customer_name = serializers.CharField(required=True, allow_null=True, allow_blank=True)
    customer_city = serializers.CharField(required=True, allow_null=True, allow_blank=True)
    customer_program = serializers.CharField(required=True, allow_null=True, allow_blank=True)
    customer_service_result = serializers.CharField(
        required=True, allow_null=True, allow_blank=True)
    customer_service_description = serializers.CharField(
        required=True, allow_null=True, allow_blank=True)

    def create(self, validated_data):
        return Advisor_service_experience.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.uid = validated_data.get('uid', instance.uid)
        instance.customer_name = validated_data.get('customer_name', instance.customer_name)
        instance.customer_city = validated_data.get('customer_city', instance.customer_city)
        instance.customer_program = validated_data.get(
            'customer_program', instance.customer_program)
        instance.customer_service_result = validated_data.get(
            'customer_service_result', instance.customer_service_result)
        instance.customer_service_description = validated_data.get(
            'customer_service_description', instance.customer_service_description)
        instance.save()
        return instance


class AdvisorPotentialStudentSerializer(serializers.Serializer):
    uid = serializers.IntegerField(required=True)
    id = serializers.IntegerField(read_only=True)
    student_uid = serializers.IntegerField(required=False, allow_null=True)
    user_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    first_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    last_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    full_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    mobile = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    phone = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    other_phone = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    qq = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    email = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    wechat = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    current_school = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    current_grade = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    apply_country = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    country = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    education = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    program_title = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    planning_year = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    gender = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    gpa = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    SSAT = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    SSAT_percent = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    SAT = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    SLEP = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    toefl_total = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    product_id = serializers.IntegerField(required=False, default=0, allow_null=True)
    is_chosen = serializers.IntegerField(required=False, default=0)
    status = serializers.IntegerField(default=0, allow_null=True)
    rate = serializers.IntegerField(default=1, allow_null=True)    # 评星
    comefrom = serializers.CharField(required=False, allow_blank=True, allow_null=True)   # 来源
    xifenqudao = serializers.CharField(required=False, allow_blank=True, allow_null=True)  # 细分渠道
    entry_time = UnixEpochDateField(required=False, allow_null=True)   # 录入时间
    rebate = serializers.CharField(default=0, allow_null=True)                # 返点
    create_at = UnixEpochDateField(required=False, allow_null=True)
    modify_at = UnixEpochDateField(required=False, allow_null=True)
    alloc_at = UnixEpochDateField(required=False, allow_null=True)
    source = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)  # 数据来源（crm／channel等）
    qudao_details = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    houxuan_country1 = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    houxuan_country2 = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    houxuan_country3 = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    origin_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    crm_create_user = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)  # crm座席ID
    chosen_time = UnixEpochDateField(required=False, allow_null=True)
    follow_person = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    resource_address = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)   # 归属地区
    latest_remark_time = UnixEpochDateField(required=False, allow_null=True)   # 备注时间
    visit_reminder_time = UnixEpochDateField(required=False, allow_null=True)  # 资源回访提醒时间
    freezing_end_time = UnixEpochDateField(required=False, allow_null=True)  # 资源冻结结束时间
    expire_time = UnixEpochDateField(required=False, allow_null=True)   # 过期时间
    expire_level = serializers.IntegerField(required=False, allow_null=True)  # 应回访天
    VIP_intent = serializers.NullBooleanField(required=False, default=0)   # 尊享意向
    marital_status = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)         # 婚姻状况
    linguistic_competence = serializers.CharField(
        required=False, allow_blank=True, allow_null=True)  # 语言能力
    gross_assets = serializers.IntegerField(
        required=False, default=0, allow_null=True,)                           # 总资产
    follow_status = serializers.IntegerField(required=False, default=0, allow_null=True)
    expendable_fund = serializers.IntegerField(required=False, default=0, allow_null=True)
    bm_experience = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    crp_potential_id = serializers.IntegerField(required=False, allow_null=True)       # crp推送资源id
    ym_mobile = serializers.CharField(required=False, allow_blank=True,
                                      allow_null=True)
    ym_username = serializers.CharField(required=False, allow_blank=True,
                                        allow_null=True)
    tuijian_name = serializers.CharField(required=False, allow_blank=True,
                                         allow_null=True)
    tuijian_mobile = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)
    tuijian_branch = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)
    tuijian_depart = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)
    attribution = serializers.CharField(required=False, allow_blank=True,
                                        allow_null=True)
    is_push_crp = serializers.NullBooleanField(required=False, default=False)
    is_pending = serializers.SerializerMethodField('check_is_pending')

    def check_is_pending(self, obj):
        """检测是否待跟进
        """
        if isinstance(obj, Advisor_potential_student) and obj.latest_remark_time:
            now = datetime.datetime.now(obj.latest_remark_time.tzinfo)
            pending_time = now - datetime.timedelta(days=14)
            return (str(obj.status) not in ('10', '50') and
                    str(obj.follow_status) not in ('66',) and
                    obj.latest_remark_time <= pending_time)
        return False

    def create(self, validated_data):
        return Advisor_potential_student.objects.create(**validated_data)

    def update(self, instance, validated_data):
        field_names = instance._meta.get_all_field_names()
        for key, value in validated_data.iteritems():
            if key in field_names:
                setattr(instance, key, value)

        if not instance.full_name and instance.first_name and instance.last_name:
            instance.full_name = instance.first_name + instance.last_name

        if instance.country:
            instance.program_title = instance.country + (instance.education or '')

        instance.save()
        return instance

    def is_valid(self, *args, **kwargs):
        from ym.apps.crm.models import Crm_User_info

        res = super(AdvisorPotentialStudentSerializer, self).is_valid(*args, **kwargs)
        # 检查手机号格式
        if self.initial_data.get('mobile'):
            mobile = self.initial_data['mobile']
            if not mobile.isdigit():
                mobile = ''.join([x for x in mobile if x.isdigit()])
            # if not re.match(settings.MOBILE_REGEX, mobile):
            if not mobile.isdigit() or len(mobile) < 8:
                res = False
                self._errors.setdefault('mobile', []).append(u'手机号码格式不对')
            self.initial_data['mobile'] = mobile
        # if str(self.data.get('status')) == '12':
        #     res = False
        if (self.instance and self.initial_data.get("mobile") and
                self.initial_data.get("mobile") != self.instance.mobile):
            update_data = {
                "mobile": (self.initial_data.get("mobile") or
                           self.instance.mobile),
                # "phone": self.initial_data.get('phone'),
                # "other_phone": self.initial_data.get('other_phone'),
            }
            crm_qs = Crm_User_info.objects.filter(
                mobile=self.instance.mobile, cuscode__isnull=False
            ).values('cuscode')
            try:
                update_data["cuscode"] = crm_qs[0]['cuscode']
            except IndexError:
                pass
            result = MyCrmComm().crm_potential_info_update(update_data,
                                                           return_reason=True)
            if result == "S11":
                res = False
                self._errors.setdefault('mobile', []).append(
                    u'CRM系统手机号码已存在')
        return res


class AdvisorStudentRemarkSerializer(serializers.ModelSerializer):

    class Meta:
        model = Advisor_student_remark
        exclude = ('potential_foreign',)

    create_at = UnixEpochDateField(required=False, allow_null=True)
    modify_at = UnixEpochDateField(required=False, allow_null=True)


class AdvisorStudentCountrySerializer(serializers.ModelSerializer):

    class Meta:
        model = Advisor_student_country
        exclude = ('potential_foreign',)

    create_at = UnixEpochDateField(required=False, allow_null=True)
    modify_at = UnixEpochDateField(required=False, allow_null=True)


class AdvisorStudentProgramSerializer(serializers.ModelSerializer):

    class Meta:
        model = Advisor_student_program
        exclude = ('potential_foreign',)

    create_at = UnixEpochDateField(required=False, allow_null=True)
    modify_at = UnixEpochDateField(required=False, allow_null=True)


class AdvisorScoreSerializer(serializers.ModelSerializer):

    class Meta:
        model = Advisor_score

    last_reset = UnixEpochDateField(required=False, allow_null=True)
