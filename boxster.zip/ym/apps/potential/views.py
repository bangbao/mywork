# coding: utf-8

import datetime
from rest_framework import status
from rest_framework.response import Response
from django.http import StreamingHttpResponse
from django.db.models import Q
from django.db import transaction
from django.utils import timezone
from shunlib import crp
from shunlib.utilities import utils
from shunlib.utilities import fileutils
from shunlib.utilities.decorators import api_view
from ym.apps.crm.models import ResourceToCrm
from ym.apps.option import logics as option_logics
from ym.apps.perm import consts as perm_consts
from ym.apps.perm import manager as perm_manager
from ym.apps.perm.manager import require_perm
from ym.apps.potential import logics as potential_logics
from ym.apps.potential import consts as potential_consts
from ym.apps.potential.serializers import (
    AdvisorPotentialStudentSerializer,
    AdvisorStudentRemarkSerializer,
    AdvisorStudentCountrySerializer,
    AdvisorStudentProgramSerializer,
)
from ym.apps.potential.models import (
    Advisor_info,
    Advisor_potential_student,
    Advisor_student_country,
    Advisor_student_program,
)


@api_view(['GET'])
@require_perm(perm_consts.PERM_POTENTIAL_LIST)
def advisor_potential_student_list(request):
    """获取顾问自己的资源
    Args:
        filters: {} (optional, json字符串) // 详情参考BI中筛选条件参数
        keywords: - 搜索关键词，多个词用空格隔开
        order_by - 排序字段，array
        page - 页数（从0开始），默认为0
        length - 每页返回客户数量，默认为10 #### 获取资源列表 [GET]
    """
    user = request.user

    conditions = request.query_params.get("filters")            # 过滤条件
    # potential_id = request.query_params.get("potential_id")
    keywords = request.query_params.get("keywords")             # 搜索
    order_by = request.query_params.get("order_by")             # 排序
    page = int(request.query_params.get("page") or 0)           # 分页页数
    length = int(request.query_params.get("length") or 10)      # 每页长度

    result = potential_logics.query_potential_muti(
        user,
        conditions=conditions,
        keywords=keywords,
        order_by=order_by,
        page=page,
        length=length)

    return {'result': result, 'code': 0}


@api_view(['GET', 'PUT'])
@require_perm(perm_consts.PERM_POTENTIAL_EDIT, ['PUT'])
def advisor_potential_student_handle(request, potential_id):
    """获取/更新单个资源
    Args:
        potential_id: advisor_potential_student表id
    """
    user = request.user
    potential_id = int(potential_id)
    if request.method == 'GET':
        try:
            potential = Advisor_potential_student.objects.get(pk=potential_id)
        except Advisor_potential_student.DoesNotExist:
            return Response({'result': u'id错误'},
                            status=status.HTTP_400_BAD_REQUEST)

        result = potential_logics.get_potential_info(user, potential)

        return Response({'result': result},
                        status=status.HTTP_200_OK)

    elif request.method == 'PUT':
        data = request.data.copy()
        if not potential_id:
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            advisor_potential_student = Advisor_potential_student.objects.get(
                pk=potential_id)
        except Advisor_potential_student.DoesNotExist:
            return Response({'result': u'id错误'},
                            status=status.HTTP_400_BAD_REQUEST)

        serializer = AdvisorPotentialStudentSerializer(
            advisor_potential_student,
            data=data,
            partial=True)

        if not serializer.is_valid():
            return Response({'result': serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)

        advisor_potential_student = serializer.save()
        # 自动转移废弃资源
        potential_logics.auto_trans_invaild_potential(advisor_potential_student)

        serializer = AdvisorPotentialStudentSerializer(
            advisor_potential_student)
        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)


@api_view(['POST', 'GET'])
@require_perm(perm_consts.PERM_POTENTIAL_SIGN)
def advisor_potential_student_sign(request, potential_id):
    """签约
    Args:
        potential_id: advisor_potential_student表id
    """
    if request.method == 'POST':
        if not potential_id:
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            advisor_potential_student = Advisor_potential_student.objects.get(
                pk=potential_id)
        except Advisor_potential_student.DoesNotExist:
            return Response({'result': u'id错误'},
                            status=status.HTTP_400_BAD_REQUEST)

        # 66表示已签约
        advisor_potential_student.follow_status = 66
        advisor_potential_student.save()
        serializer = AdvisorPotentialStudentSerializer(
            advisor_potential_student,
            partial=True)

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)


@api_view(['POST', 'GET'])
@require_perm(perm_consts.PERM_POTENTIAL_REMARK)
def advisor_student_remark(request):
    """添加备注
    Args:
        potential_id: advisor_potential_student表id
        content: 备注内容
    """
    if request.method == 'POST':
        potential_id = request.data.get('potential_id')
        content = request.data.get('content')

        if not (potential_id and content):
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            try:
                potential_query = Advisor_potential_student.objects.\
                    select_for_update().get(id=potential_id)
            except Advisor_potential_student.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)
            advisor_uid = request.uid
            advisor_name = request.user.users.user_name
            remark_data = {
                "potential_id": potential_id,
                "advisor_uid": advisor_uid,
                "content": content + '——来自顾问 {}'.format(advisor_name),
            }
            serializer = AdvisorStudentRemarkSerializer(data=remark_data)
            if not serializer.is_valid():
                return Response({'result': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            potential_query.related_remarks.create(**remark_data)

            # 记录最新跟进时间
            potential_query.latest_remark_time = timezone.now()
            potential_query.expire_time = None
            potential_query.expire_level = None
            potential_query.save()

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)


@api_view(['POST', 'GET'])
def advisor_student_country(request):
    """添加意向国家
    """
    if request.method == 'POST':
        advisor_uid = request.uid
        potential_id = request.data.get('potential_id')
        # country = request.data.get('country')
        # has_visa = request.data.get('has_visa')
        # has_relatives = request.data.get('has_relatives')
        _type = request.data.get('type', 0)
        country_data = request.data.copy()

        if not request.data:
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            try:
                student_query = Advisor_potential_student.objects.get(
                    id=potential_id)
            except Advisor_potential_student.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)

            country_data.update({
                "potential_id": potential_id,
                "advisor_uid": advisor_uid,
                "student_uid": student_query.student_uid,
                # "country": country,
                # "has_visa": has_visa,
                # "has_relatives": has_relatives,
                # "type": _type,
            })
            serializer = AdvisorStudentCountrySerializer(data=country_data)
            if not serializer.is_valid():
                return Response({'result': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            country_query = student_query.related_countries.create(
                **country_data)

            # 同一人申请国家列表中字段type 只能有一个为1
            if _type == 1:
                student_query.related_countries.filter(
                    type=1).exclude(id=country_query.id).update(type=0)

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)


@api_view(['PUT', 'DELETE', 'GET'])
def advisor_student_country_handle(request, cid):
    """修改/删除意向国家
    Args:
        cid: Advisor_student_country国家表中id
    """
    if request.method == 'PUT':
        cid = int(cid)
        # country = request.data.get('country')
        # has_visa = request.data.get('has_visa')
        # has_relatives = request.data.get('has_relatives')
        _type = request.data.get('type', 0)
        country_data = request.data.copy()

        with transaction.atomic():
            try:
                country_query = Advisor_student_country.objects.get(id=cid)
            except Advisor_student_country.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)

            serializer = AdvisorStudentCountrySerializer(country_query,
                                                         data=country_data)
            if not serializer.is_valid():
                return Response({'result': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            serializer.save()

            # 同一人申请国家列表中字段type 只能有一个为1
            if _type == 1:
                Advisor_student_country.objects.filter(
                    potential_id=country_query.potential_id, type=1,
                ).exclude(id=cid).update(type=0)

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)

    elif request.method == 'DELETE':
        with transaction.atomic():
            try:
                country_query = Advisor_student_country.objects.get(id=cid)
            except Advisor_student_country.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)
            country_query.delete()
            # 同时删除国家对应的项目
            Advisor_student_program.objects.filter(
                country=country_query.country,
                potential_id=country_query.potential_id,
            ).delete()

        return Response({'result': 'OK'},
                        status=status.HTTP_204_NO_CONTENT)


@api_view(['POST', 'GET'])
def advisor_student_program(request):
    """添加意向项目
    """
    if request.method == 'POST':
        advisor_uid = request.uid
        potential_id = request.data.get('potential_id')
        # program = request.data.get('program')
        _type = request.data.get('type', 0)
        program_data = request.data.copy()

        if not program_data:
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            try:
                student_query = Advisor_potential_student.objects.get(
                    id=potential_id)
            except Advisor_potential_student.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)

            program_data.update({
                "potential_id": potential_id,
                "advisor_uid": advisor_uid,
                "student_uid": student_query.student_uid,
            })
            serializer = AdvisorStudentProgramSerializer(data=program_data)
            if not serializer.is_valid():
                return Response({'result': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            program_query = student_query.related_programs.create(
                **program_data)
            serializer = AdvisorStudentProgramSerializer(program_query)

            # 同一人申请项目表中字段type 只能有一个为1
            if _type == 1:
                student_query.related_programs.filter(
                    type=1).exclude(id=program_query.id).update(type=0)

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)


@api_view(['PUT', 'DELETE', 'GET'])
def advisor_student_program_handle(request, pid):
    """修改/删除意向项目
    Args:
        pid: Advisor_student_program表中id
    """
    if request.method == 'PUT':
        pid = int(pid)
        _type = request.data.get('type')
        program_data = request.data.copy()

        if not program_data:
            return Response({'result': u'缺少参数'},
                            status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            try:
                program_query = Advisor_student_program.objects.get(id=pid)
            except Advisor_student_program.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)

            serializer = AdvisorStudentProgramSerializer(program_query,
                                                         data=program_data)
            if not serializer.is_valid():
                return Response({'result': serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            serializer.save()

            # 同一人申请项目表中字段type 只能有一个为1
            if _type == 1:
                Advisor_student_program.objects.filter(
                    potential_id=program_query.potential_id, type=1,
                ).exclude(id=pid).update(type=0)

        return Response({'result': serializer.data},
                        status=status.HTTP_200_OK)

    elif request.method == 'DELETE':
        with transaction.atomic():
            try:
                program_query = Advisor_student_program.objects.get(id=pid)
            except Advisor_student_program.DoesNotExist:
                return Response({'result': u'ID不存在'},
                                status=status.HTTP_400_BAD_REQUEST)
            program_query.delete()

        return Response({'result': 'OK'},
                        status=status.HTTP_204_NO_CONTENT)


@api_view(['GET'])
def advisor_potential_export_xlsx(request):
    """顾问资源导出excel
    获取资源列表 [GET] 导出筛选查询搜索条件下所有数据
    Args:
        filters: {} (optional, json字符串) // 详情参考BI中筛选条件参数
        keywords: - 搜索关键词，多个词用空格隔开
        order_by - 排序字段，array
    """
    if request.method == 'GET':
        user = request.user
        conditions = request.query_params.get("filters")
        keywords = request.query_params.get("keywords")
        order_by = request.query_params.get("order_by")

        result = potential_logics.query_potential_muti(
            user,
            conditions=conditions,
            keywords=keywords,
            order_by=order_by)

        filename = '{}_query_result.xlsx'.format(user.users.user_name)
        filepath = potential_logics.trans_potential_result2xlsx(result,
                                                                filename)

        response = StreamingHttpResponse(fileutils.file_iterator(filepath))
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="{0}"'.format(
            filename)
        return response


@api_view(['POST'])
@require_perm(perm_consts.PERM_POTENTIAL_ADD)
def advisor_potential_add(request):
    """新增资源录入接口 新建意向客户记录
    """
    user = request.user
    uid = request.uid
    data = request.data
    full_name = data.get('full_name')
    mobile = data.get('mobile')
    wechat = data.get('wechat')
    comefrom = data.get('comefrom') or '集团渠道'
    xifenqudao = data.get('xifenqudao') or None
    qudao_details = data.get('qudao_details') or None
    follow_person = data.get('follow_person') or None
    remark = data.get('remark')

    if not full_name:
        return Response({'result': u'姓名必须填写'},
                        status=status.HTTP_400_BAD_REQUEST)

    if not (mobile or wechat):
        return Response({'result': u'电话和微信必须填写一个'},
                        status=status.HTTP_400_BAD_REQUEST)

    # Don't check duplicate resource 2016-03-21
    filters_exist = Q()
    if mobile:
        filters_exist |= Q(mobile=mobile)
    if wechat:
        filters_exist |= Q(wechat=wechat)
    pot_query = Advisor_potential_student.objects.filter(filters_exist)
    res_query = ResourceToCrm.objects.filter(filters_exist).filter(flag=1)
    if pot_query.exists() or res_query.exists():
        return Response({'result': u'联系方式已存在'},
                        status=status.HTTP_400_BAD_REQUEST)

    if follow_person:
        try:
            query = Advisor_info.objects.get(full_name=follow_person)
            advisor_uid = query.uid
        except Advisor_info.DoesNotExist:
            msg = u"指定顾问({})不存在".format(follow_person)
            return Response({"result": msg},
                            status=status.HTTP_400_BAD_REQUEST)
    else:
        try:
            query = Advisor_info.objects.get(uid=uid)
            advisor_uid = query.uid
            follow_person = query.full_name
        except Advisor_info.DoesNotExist:
            return Response({"result": u"您不是顾问, 请指定顾问在提交"},
                            status=status.HTTP_400_BAD_REQUEST)

    comefrom = option_logics.get_comefrom_by_xifenqudao(xifenqudao, comefrom)
    insert_data = data.copy()
    insert_data["follow_person"] = follow_person
    insert_data["user_name"] = full_name
    insert_data["name"] = full_name
    insert_data["mobile"] = mobile
    insert_data["uid"] = advisor_uid
    insert_data["comefrom"] = comefrom
    insert_data["xifenqudao"] = xifenqudao
    insert_data["qudao_details"] = qudao_details
    insert_data["source"] = 'online'                # 标识线上录入
    insert_data["create_user"] = uid                # 记录录入者uid
    insert_data["crm_create_user"] = uid            # 记录录入者uid
    insert_data['level_adjust'] = int(data.get('rate', 0))
    countries_programs = insert_data.pop("countries_programs", [])
    if countries_programs:
        insert_data['apply_contry'] = countries_programs[0]['country']
    # 记录最新跟进时间
    if remark:
        insert_data['latest_remark_time'] = datetime.datetime.now()

    serializer = AdvisorPotentialStudentSerializer(data=insert_data)
    if not serializer.is_valid():
        return Response({"result": serializer.errors},
                        status=status.HTTP_400_BAD_REQUEST)

    res_flag, data = potential_logics.prepare_for_crm(insert_data)

    if res_flag == 1:
        return Response({"result": data}, status=status.HTTP_400_BAD_REQUEST)

    alert_msg = None
    if res_flag == 2:
        alert_msg = data

    # 数据校验正确, 开始批量写数据
    potential_query = serializer.save()
    country_creates = []
    program_creates = []
    for cidx, country_data in enumerate(countries_programs):
        cdata = {
            'country': country_data['country'],
            'has_visa': bool(country_data['has_visa']),
            'type': 1 if cidx == 0 else 0,
            'potential_id': potential_query.id,
            'advisor_uid': potential_query.uid,
            'potential_foreign_id': potential_query.id,
        }
        country_serializer = AdvisorStudentCountrySerializer(
            data=cdata)
        if country_serializer.is_valid(raise_exception=True):
            country_creates.append(Advisor_student_country(**cdata))
            programs = country_data['programs']
            for pidx, program_data in enumerate(programs):
                pdata = {
                    'country': country_data['country'],
                    'program': program_data['program'],
                    'type': 1 if pidx == 0 else 0,
                    'potential_id': potential_query.id,
                    'advisor_uid': potential_query.uid,
                    'potential_foreign_id': potential_query.id,
                }
                program_serializer = AdvisorStudentProgramSerializer(
                    data=pdata)
                if program_serializer.is_valid(raise_exception=True):
                    program_creates.append(
                        Advisor_student_program(**pdata))
    # 手动设置potential_foreign_id值
    if country_creates:
        potential_query.related_countries.bulk_create(country_creates)
    if program_creates:
        potential_query.related_programs.bulk_create(program_creates)
    if remark:
        advisor_name = user.users.user_name
        remark_data = {
            "potential_id": potential_query.id,
            "advisor_uid": advisor_uid,
            "content": remark + '——来自顾问 {}'.format(advisor_name),
        }
        serializer = AdvisorStudentRemarkSerializer(data=remark_data)
        if not serializer.is_valid():
            return Response({'result': serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        potential_query.related_remarks.create(**remark_data)

    return Response({'result': 'success', 'alert_msg': alert_msg},
                    status=status.HTTP_200_OK)


@api_view(['POST'])
@require_perm(perm_consts.PERM_POTENTIAL_PROGRAM)
def potential_country_program_add(request):
    """添加新的国家项目
    """
    potential_id = request.data.get('potential_id')
    country = request.data.get('country')
    has_visa = request.data.get('has_visa')
    programs = request.data.get('programs')

    try:
        potential_query = Advisor_potential_student.objects.get(
            id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return Response({'result': u'ID不存在'},
                        status=status.HTTP_400_BAD_REQUEST)

    with transaction.atomic():
        try:
            country_query = potential_query.related_countries.get(
                country=country)
            if country_query.has_visa != has_visa:
                country_query.has_visa = has_visa
                country_query.save()
        except Advisor_student_country.DoesNotExist:
            cdata = {
                'country': country,
                'has_visa': has_visa,
                'potential_id': potential_query.id,
                'advisor_uid': potential_query.uid,
            }
            country_serializer = AdvisorStudentCountrySerializer(data=cdata)
            if not country_serializer.is_valid():
                return Response({'result': country_serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            potential_query.related_countries.create(**cdata)

        program_creates = []
        for program_data in programs:
            pdata = {
                'country': country,
                'program': program_data['program'],
                'potential_id': potential_query.id,
                'advisor_uid': potential_query.uid,
                'potential_foreign_id': potential_query.id,  # 手动设置值
            }
            program_serializer = AdvisorStudentProgramSerializer(data=pdata)
            if not program_serializer.is_valid():
                return Response({'result': program_serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)
            program_creates.append(Advisor_student_program(**pdata))
        if program_creates:
            potential_query.related_programs.bulk_create(program_creates)

    return Response({'result': 'success'}, status=status.HTTP_200_OK)


@api_view(['POST'])
@require_perm(perm_consts.PERM_POTENTIAL_PROGRAM)
def potential_country_program_handle(request, country_id):
    """修改国家项目
    """
    country_id = int(country_id)
    country_data = request.data.copy()
    potential_id = country_data.get('potential_id')
    programs = country_data.pop('programs', [])

    try:
        potential_query = Advisor_potential_student.objects.get(
            id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return Response({'result': u'资源ID不存在'},
                        status=status.HTTP_400_BAD_REQUEST)

    try:
        country_query = potential_query.related_countries.get(id=country_id)
    except Advisor_student_country.DoesNotExist:
        return Response({'result': u'国家ID不存在'},
                        status=status.HTTP_400_BAD_REQUEST)

    if country_query.potential_id != potential_id:
        return Response({'result': u'无权修改此资源'},
                        status=status.HTTP_400_BAD_REQUEST)

    country_serializer = AdvisorStudentCountrySerializer(country_query,
                                                         data=country_data)
    if not country_serializer.is_valid():
        return Response({'result': country_serializer.errors},
                        status=status.HTTP_400_BAD_REQUEST)

    country_query = country_serializer.save()

    program_creates = []
    for program_data in programs:
        pdata = {
            'country': country_query.country,
            'program': program_data['program'],
            'potential_id': potential_query.id,
            'advisor_uid': potential_query.uid,
            'potential_foreign_id': potential_query.id,  # 手动设置值
        }
        program_serializer = AdvisorStudentProgramSerializer(data=pdata)
        if not program_serializer.is_valid():
            return Response({'result': program_serializer.errors},
                            status=status.HTTP_400_BAD_REQUEST)
        program_creates.append(Advisor_student_program(**pdata))
    if program_creates:
        potential_query.related_programs.bulk_create(program_creates)

    return Response({'result': 'success'}, status=status.HTTP_200_OK)


@api_view(['GET'])
def searchadvisors(request):
    """搜索顾问
    """
    user = request.user
    keywords = request.query_params.get('keywords')

    filters = Q(visible=1)
    if keywords:
        filters &= Q(full_name__icontains=keywords)

    if (not user.perm_manager.is_super() and
            not perm_manager.can_potential_view(user)):
        child_uids = perm_manager.get_userlevel_childs(user)
        child_uids.append(user.id)
        filters &= Q(uid__in=child_uids)

    advisor_query = Advisor_info.objects.filter(filters)
    result = [data for data in advisor_query.values('id', 'uid', 'full_name')]

    return Response({'result': result}, status=status.HTTP_200_OK)


@api_view(['POST'])
@require_perm(perm_consts.PERM_APPOINT_ADVISOR)
def appoint_advisor(request):
    """分配指定顾问
    """
    user = request.user
    advisor_id = request.data.get('advisor_id')
    potential_id = request.data.get('potential_id')

    try:
        potential = Advisor_potential_student.objects.get(id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return Response({'result': u'没找到资源{}'.format(potential_id)},
                        status=status.HTTP_400_BAD_REQUEST)

    try:
        advisor = Advisor_info.objects.get(id=advisor_id)
    except Advisor_potential_student.DoesNotExist:
        return Response({'result': u'没找到顾问{}'.format(advisor_id)},
                        status=status.HTTP_400_BAD_REQUEST)

    if potential.uid == advisor.uid:
        return Response({'result': u'同一个人, 不用重新分配'},
                        status=status.HTTP_400_BAD_REQUEST)

    update_data = {
        'uid': advisor.uid,
        'follow_person': advisor.full_name,
    }
    potential_serializer = AdvisorPotentialStudentSerializer(potential,
                                                             data=update_data)
    if not potential_serializer.is_valid():
        return Response({'result': potential_serializer.errors},
                        status=status.HTTP_400_BAD_REQUEST)

    potential = potential_logics.appoint_advisor(potential, advisor)
    potential.save()

    result = potential_logics.get_potential_info(user, potential)
    return Response({'result': result},
                    status=status.HTTP_200_OK)


@api_view(['GET'])
@require_perm(perm_consts.PERM_PUSH_CRP)
def push_to_crp_info(request):
    """移民推送留学页面数据
    """
    potential_id = request.query_params.get('potential_id')

    try:
        potential = Advisor_potential_student.objects.get(id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return {'result': u'没找到对应资源', 'code': 1}

    options = option_logics.get_crp_planning_countryies_programs()
    result = {
        'id': potential.id,
        'full_name': potential.full_name,
        'mobile': potential.mobile,
        'countries': options['planning_countries'],
        'educations': options['planning_programs'],
    }
    return {'result': result, 'code': 0}


@api_view(['POST'])
@require_perm(perm_consts.PERM_PUSH_CRP)
def push_to_crp(request):
    """移民推送资源到留学
    Args:
        "potential_id": 137,        # 资源ID
        "full_name": "张先生",       # 资源姓名
        "mobile": "18911001212",    # 手机号
        "country": "瑞士",           # 留学国家
        "education": "夏校",         # 留学项目
        "planning_year": "",        # 留学时间
        "remark": "",               # 备注 非必填
        "follow_person": "王硕",     # 指定顾问 非必填
    """
    user = request.user
    push_data = dict(request.data)

    push_keys = ('potential_id', 'mobile', 'country', 'education', 'planning_year',
                 'remark', 'follow_person')
    for key in push_keys:
        if key not in push_data:
            if key in ('remark', 'follow_person'):
                push_data[key] = None
            else:
                return {'result': u'请填写必填项', 'code': 1}

    potential_id = push_data['potential_id']
    try:
        potential = Advisor_potential_student.objects.get(id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return {'result': u'没找到对应资源', 'code': 1}

    if potential.crp_potential_id or potential.is_push_crp:
        return {'result': u'留学已存在此资源', 'code': 2}

    user_name = user.users.name or user.users.user_name
    if push_data['remark']:
        push_data['remark'] = u'%s——来自 %s' % (push_data['remark'], user_name)
    push_data.update(
        phone=potential.phone,
        other_phone=potential.other_phone,
        email=potential.email,
        qq=potential.qq,
        wechat=potential.wechat,
        gender=potential.gender,
        comefrom=potential_consts.PUSH_TO_CRP_COMEFROM,
        xifenqudao=potential_consts.PUSH_TO_CRP_XIFENQUDAO,
        qudao_details=user_name,
        tuijian_name=user_name,
        tuijian_mobile=user.users.mobile,
        branch_company=user.users.attribution or u'北京市',
    )
    push_data['sign'] = utils.signature_data(push_data, key='boxster')

    result = crp.push_potential_to_crp(push_data)

    if result['code'] != 0:
        return {'result': result['result'], 'code': 1}

    crp_potential_id = result['result']['crp_potential_id']
    potential.crp_potential_id = crp_potential_id
    potential.is_push_crp = True
    potential.save()

    return {'result': 'ok', 'code': 0}


@api_view(['GET'])
def get_crp_remarks(request):
    """获取该资源在crp里的相关备注
    """
    potential_id = request.query_params.get('potential_id')

    try:
        potential = Advisor_potential_student.objects.get(id=potential_id)
    except Advisor_potential_student.DoesNotExist:
        return {'result': u'找不到对应资源', 'code': 1}

    if not potential.crp_potential_id:
        return {'result': u'未推送到留学', 'code': 2}

    data = crp.get_potential_by_id(potential.crp_potential_id)
    if not data:
        return {'result': u'留学找不到对应资源', 'code': 3}

    remarks = [{'create_at': obj['create_at'], 'content': obj['content']}
               for obj in data['remarks']]
    result = {
        'remarks': remarks,
        'follow_status': data['follow_status'],
        'follow_person': data['advisor_name'],
    }
    return {'result': result, 'code': 0}
