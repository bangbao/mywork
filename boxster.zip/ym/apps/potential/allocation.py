# coding: utf-8

import re
import datetime
from collections import OrderedDict
from django.db.models import F, Min  # , Q
from ym.apps.potential.models import (
    Advisor_info,
    Advisor_potential_student,
    Advisor_alloc_num,
    Advisor_alloc_statistics,
)
from ym.apps.potential.serializers import AdvisorPotentialStudentSerializer
# from ym.apps.user.models import Users


class Allocation:

    DEFAULT_WEIGHT = 10

    @property
    def crp_xifenqudao_code_map(self):
        """缓存crp细分渠道到code的映射
        """
        if not hasattr(self, '_crp_xifenqudao_code_map'):
            from ym.apps.option import logics as option_logics
            crp_xifenqudao_code_map = option_logics.get_crp_xifenqudao_code_map()
            self._crp_xifenqudao_code_map = crp_xifenqudao_code_map
        return self._crp_xifenqudao_code_map

    def get_next_advisor(self, city, country):
        """根据城市和国家，获取下一个应分配资源的顾问
        """
#         if not city or not country:
#             print '>> no address or country info, match SUNJUN!'
#             advisor = Advisor_info.objects.get(uid=3867)    # 孙军
#             return advisor

        # 测试
        # advisor = Advisor_info.objects.get(uid=6)
        # return advisor
        # 查找本地区擅长该国家的顾问
        advisor_query = self.get_advisor_qs(city, country,
                                            only_accept_resource=True)
        if advisor_query.exists():
            alloc_city = city
        else:
            # 没找到擅长的重新分配
            advisor_query = Advisor_info.objects.all().order_by('uid')
            alloc_city = '*'
            # alloc_city = u'*'
            # print '>> finding Beijing advisor'
            # advisor_query = self.get_advisor_qs(u'北京', country,
            #                                    only_accept_resource=True)
            # if not advisor_query.exists():
            #    print '>>> match SUNJUN!'       # 分不出去的资源分给孙军
            #    advisor = Advisor_info.objects.get(uid=3867)
            #    return advisor

            # 2016-3-4 刘雨骁：只是上海的这样 湖南的这样 都分给这个人(祝蓓)
            # if city.startswith(u'长沙') or city.startswith(u'上海'):
            #    print '>>> match ZHUBEI!'       # 祝蓓
            #    advisor = Advisor_info.objects.get(uid=11409)
            #    return advisor

            # 2016-2-2 荀：其他分公司的没有项目线的，先分给我账号
            # print '>>> match SUNJUN!'       # 分不出去的资源分给孙军
            # advisor = Advisor_info.objects.get(uid=6)
            # return advisor

        print '>>> match advisor success!'
        advisor_uids = [a.uid for a in advisor_query]
        alloc_query = Advisor_alloc_num.objects.filter(
            advisor_uid__in=advisor_uids, city=alloc_city,
            country=country).order_by('advisor_uid')
        alloc_query_list = list(alloc_query)
        last_alloc_advisor_uid = None           # 上次分配的顾问uid
        min_weight = self.DEFAULT_WEIGHT        # 此分组最小权重值
        if alloc_query_list:
            # min_weight = min([q.weight for q in alloc_query_list\
            #                  if q.weight>0])
            last_alloc_advisor = filter(
                lambda x: x.last_alloc_flag == 1, alloc_query_list
            )
            if last_alloc_advisor:
                last_alloc_advisor_uid = last_alloc_advisor[0].advisor_uid
            # 检查如果全部顾问的动态权重都小于0，则全部加自己的默认权重
            qs_gt_0 = alloc_query.filter(weight__gt=0)
            if qs_gt_0.exists():
                while max([q.dynamic_weight for q in qs_gt_0]) <= 0:
                    qs_gt_0.update(
                        dynamic_weight=F('dynamic_weight') + F('weight'))
        # 生成新顾问的分配记录
        alloc_query_uids = [q.advisor_uid for q in alloc_query_list]
        new_advisor_uids = [uid for uid in advisor_uids
                            if uid not in alloc_query_uids]
        if new_advisor_uids:
            create_list = []
            for uid in new_advisor_uids:
                create_list.append(Advisor_alloc_num(
                    advisor_uid=uid, city=alloc_city, country=country,
                    weight=min_weight, dynamic_weight=min_weight
                ))
            Advisor_alloc_num.objects.bulk_create(create_list)
            self.reset(city=alloc_city, country=country)

        # 查找下一个顾问
        if last_alloc_advisor_uid is None:
            next_index = 0
        else:
            next_index = advisor_uids.index(last_alloc_advisor_uid) + 1
        indexes = range(advisor_query.count())
        indexes = indexes[next_index:] + indexes[:next_index]
        alloc_query = alloc_query.all()     # 强制重新查询数据库
        advisor = None
        for index in indexes:
            alloc_info = alloc_query[index]
            if alloc_info.dynamic_weight > 0:
                advisor = Advisor_info.objects.get(uid=alloc_info.advisor_uid)
                break
        if advisor is None:
            advisor = Advisor_info.objects.get(uid=1)
        return advisor

    def alloc_follow_person(self, crm_info):
        """指定顾问的资源分配
        """
        print '\ncrm info [', crm_info.id, '] has follow_person info'
        try:
            advisor = Advisor_info.objects.get(
                full_name=crm_info.follow_person)
        except Advisor_info.DoesNotExist:
            print 'advisor not match'       # 顾问未找到，跳过
            return None
        except Advisor_info.MultipleObjectsReturned:
            # 重名，根据地区匹配
            city = self._get_city(crm_info)
            if not city:
                print 'no city info'        # 没有城市，跳过
                return None
            advisor_query = Advisor_info.objects.filter(
                full_name=crm_info.follow_person,
                address_city__startswith=city)
            if advisor_query.count != 1:
                print 'no matched city or matched multiple advisors'
                return None
            advisor = advisor_query[0]
        print '>>> followed person:', advisor.uid
        return self.alloc(crm_info, advisor)

    def alloc(self, crm_info, advisor=None, update=False):
        """分配一条资源
        """
        data = {}
        if update:
            try:
                potential_info = Advisor_potential_student.objects.get(
                    mobile=crm_info.mobile)
            except Advisor_potential_student.DoesNotExist:
                print '>>> cannot find potential info.'
                return
            except Advisor_potential_student.MultipleObjectsReturned:
                print '>>> mobile %s has multiple results' % crm_info.mobile
                return
            serializer = AdvisorPotentialStudentSerializer(
                potential_info, data=data, partial=True)
        else:
            serializer = AdvisorPotentialStudentSerializer(data=data)

        country = self._get_country(crm_info)
        city = self._get_city(crm_info)
        # try:
        #    user = Users.objects.get(mobile=crm_info.mobile)
        #    data['student_uid'] = user.uid
        # except Users.DoesNotExist:
        #    pass
        data['country'] = country
        crm_fields = crm_info._meta.get_all_field_names()
        potential_fields = Advisor_potential_student._meta.get_all_field_names()
        exclude_fields = ('flag', 'crm_update_flag', 'create_at', 'cuscode')
        for crm_name in crm_fields:
            if crm_name in exclude_fields:
                continue
            if crm_name == 'name':
                data['full_name'] = self._vs(crm_info.name)
            elif crm_name == 'sex':
                data['gender'] = self._vs(crm_info.sex)
            elif crm_name == 'gpa_performance':
                data['gpa'] = self._vs(crm_info.gpa_performance)
            elif crm_name == 'comefrompoint':
                data['rebate'] = crm_info.comefrompoint or None
            elif crm_name == 'graduate_school':
                data['current_school'] = self._vs(crm_info.graduate_school)
            elif crm_name == 'current_education':
                data['current_grade'] = self._vs(crm_info.current_education)
            elif crm_name == 'apply_education':
                data['education'] = self._vs(crm_info.apply_education)
                data['program_title'] = (country or '') + self._vs(
                    crm_info.apply_education, allow_null=False)
            elif crm_name == 'apply_professional':
                data['professional'] = self._vs(crm_info.apply_professional)
            elif crm_name == 'level_adjust':
                data['rate'] = self._vs(crm_info.level_adjust)
            elif crm_name == 'create_time':
                data['entry_time'] = crm_info.create_time or None
            elif crm_name == 'create_user':
                data['crm_create_user'] = self._vs(crm_info.create_user)
            else:
                if crm_name in potential_fields:
                    crm_value = getattr(crm_info, crm_name, None)
                    data[crm_name] = self._vs(crm_value)

        # 细分渠道需要转换成s代码展示
        xifenqudao = data['xifenqudao']
        if xifenqudao in self.crp_xifenqudao_code_map:
            xifenqudao_code = self.crp_xifenqudao_code_map[xifenqudao]
            data['xifenqudao'] = xifenqudao_code

        if not update:
            data['uid'] = advisor.uid
            data["mobile"] = self._vs(crm_info.mobile)
            data["source"] = 'crp' if crm_info.crp_potential_id >= 1 else 'crm'
            data["is_chosen"] = 0
            data["follow_person"] = crm_info.follow_person
            data["resource_address"] = (city + u'市') if city else None
            # 记录最新跟进时间
            if crm_info.remark:
                data['latest_remark_time'] = datetime.datetime.now()

        if not serializer.is_valid(raise_exception=True):
            print '>>> potential info error:',
            print serializer.errors
            return None

        crm_info.flag = 1
        crm_info.save()

        advisor_potential_student = serializer.save()
        print '>>> saved'

        if not update:
            # 存储评论
            if crm_info.remark:
                advisor_potential_student.related_remarks.create(
                    potential_id=advisor_potential_student.id,
                    content=crm_info.remark,
                )

            # 初始化移民申请国家
            if crm_info.apply_contry:
                advisor_potential_student.related_countries.create(
                    potential_id=advisor_potential_student.id,
                    advisor_uid=advisor.uid,
                    student_uid=advisor_potential_student.student_uid,
                    country=advisor_potential_student.country,
                    has_visa=False,
                    has_relatives=False,
                    type=1,
                )
            # 初始化移民申请项目
            if crm_info.apply_program:
                advisor_potential_student.related_programs.create(
                    country=advisor_potential_student.country,
                    program=crm_info.apply_program,
                    potential_id=advisor_potential_student.id,
                    advisor_uid=advisor.uid,
                    type=1,
                )

        if update or advisor.full_name == u'孙军':
            return advisor_potential_student

        # 记录分配数据
        if city and advisor.address_city.startswith(city):
            alloc_city = city
        else:
            alloc_city = u"*"
        alloc_query = Advisor_alloc_num.objects.filter(
            city=alloc_city, country=country)
        try:
            row = alloc_query.get(advisor_uid=advisor.uid)
        except Advisor_alloc_num.DoesNotExist:
            self.change_weight(city=alloc_city, country=country,
                               weight_map={advisor.uid: self.DEFAULT_WEIGHT})
            row = alloc_query.get(advisor_uid=advisor.uid)

        min_weight = alloc_query.filter(weight__gt=0).aggregate(
            min_w=Min('weight'))['min_w']
        if not crm_info.follow_person:
            alloc_query.update(last_alloc_flag=0)
            row.last_alloc_flag = 1
        row.dynamic_weight -= min_weight
        row.save()
        # 记录统计数据
        statistics = Advisor_alloc_statistics(
            advisor_uid=advisor.uid,
            potential_id=advisor_potential_student.id,
            city=alloc_city,
            country=country,
            is_specific=crm_info.follow_person == advisor.full_name
        )
        statistics.save()
        return advisor_potential_student

    def change_weight(self, city, country, weight_map):
        """修改一个顾问的权重
        """
        city = city.rstrip(u'市')
        for advisor_uid, weight in weight_map.iteritems():
            weight = int(weight)
            if weight < 0:
                raise ValueError("`weight` must greater than 0.")
            alloc_info, created = Advisor_alloc_num.objects.get_or_create(
                advisor_uid=advisor_uid, city=city, country=country,
                defaults={"weight": weight})
            if not created and alloc_info.weight != weight:
                alloc_info.weight = weight
                alloc_info.save()
        self.reset(city, country)

    def get_advisor_qs(self, city, country, only_accept_resource=False,
                       only_refuse_resource=False):
        """用城市和国家获取顾问queryset
        """
        qs = Advisor_info.objects.filter(
            address_city__istartswith=city,
            strength_program__iregex=u'(^|;)%s(:|;|$)' % country)
        if only_accept_resource:
            qs = qs.filter(Advisor_info.get_accept_source_query())
        elif only_refuse_resource:
            qs = qs.filter(Advisor_info.get_refuse_source_query())
        return qs.order_by('uid')

    def reset(self, city, country):
        """重置某分组的顾问权重
        """
        # 查找符合条件的顾问
        advisor_query = self.get_advisor_qs(
            city, country, only_accept_resource=True)
        advisor_uids = [r.uid for r in advisor_query]

        # 清除现有分配数据
        alloc_query = Advisor_alloc_num.objects.filter(
            city=city, country=country)
        # alloc_query.exclude(advisor_uid__in=advisor_uids).delete()
        alloc_query.update(dynamic_weight=F("weight"))

        if not advisor_uids:
            return
        alloc_uids = []
        min_weight = 10
        for alloc_info in alloc_query:
            alloc_uids.append(alloc_info.advisor_uid)
            min_weight = min(min_weight, alloc_info.weight)
        need_create_uid = [uid for uid in advisor_uids
                           if uid not in alloc_uids]
        if not need_create_uid:
            return
        create_list = []
        for uid in need_create_uid:
            create_list.append(Advisor_alloc_num(
                advisor_uid=uid, city=city, country=country,
                weight=min_weight, dynamic_weight=min_weight
            ))
        Advisor_alloc_num.objects.bulk_create(create_list)

    def update_potential(self, crm_info):
        """用crm user info对象更新意向客户信息
        """
        print 'Updating potential info'
        if not crm_info.mobile:
            print 'no mobile when update potential student info'
            return
        return self.alloc(crm_info, update=True)

    def _vs(self, value, allow_null=True):
        if not value or value in ('', '0', 'null', 'none'):
            return None if allow_null else ''
        if not isinstance(value, str) and not isinstance(value, unicode):
            return str(value)
        return value

    def _get_country(self, crm_info):
        country = self._vs(crm_info.apply_contry)
        if country == u'澳大利亚':
            country = u'澳洲'
        return country

    def _get_city(self, crm_info):
        city = None
        if crm_info.branch_company:
            city = crm_info.branch_company[:-3]
        if not city and crm_info.attribution:
            # 如果没有匹配的顾问，再检查归属地
            match = re.match('\[(.+):(.+)\]', crm_info.attribution)
            if match:
                _province, city = match.groups()
        return city.rstrip(u'市') if city else None

allocator = Allocation()


#####################
# 分配算法演示Demo  #
#####################


WEIGHTS = OrderedDict()
WEIGHTS["A"] = 10
WEIGHTS["B"] = 9


class AllocDemo:

    def __init__(self):
        self.weights = OrderedDict()
        self.init_weight()

    def alloc(self, advisor, resource_num=1):
        """分配资源
        """
        self.resource_counter.setdefault(advisor, 0)
        self.resource_counter[advisor] += resource_num
        self.weights[advisor] -= self.min_weight * resource_num

    def coming_resource(self, resource_num, force_advisor=None):
        """新进资源
        """
        if force_advisor is None:
            allocated = 0
            for advisor in self.advisor_iterator():
                if advisor == self.first_advisor\
                        and max(self.weights.values()) <= 0:
                    for _advisor in self.weights:
                        self.weights[_advisor] += WEIGHTS[_advisor]
                if self.weights[advisor] > 0:
                    self.alloc(advisor)
                    allocated += 1
                    if allocated >= resource_num:
                        break
        else:
            self.alloc(force_advisor, resource_num)
            advisor = force_advisor
        self.resource_sum += resource_num
        self.last_alloc_advisor = advisor

        self.trace()

    def advisor_iterator(self):
        """顾问迭代器
        """
        i = 0
        advisors = self.weights.keys()
        while 1:
            if self.last_alloc_advisor is not None:
                if advisors[i] == self.last_alloc_advisor:
                    self.last_alloc_advisor = None
            else:
                yield advisors[i]
            i += 1
            if i >= len(advisors):
                i = 0

    def change_weight(self, advisor, weight):
        """修改顾问的权重
        """
        if advisor in WEIGHTS and WEIGHTS[advisor] == weight:
            return

        self.trace()
        WEIGHTS[advisor] = weight
        self.init_weight()
        self.trace()

    def _default_weight(self):
        weights = OrderedDict().fromkeys(self.weights, 1)
        weights.update(WEIGHTS)
        return weights

    def init_weight(self):
        """初始化所有顾问的权重
        """
        self.weights = self._default_weight()
        self.min_weight = min([v for v in self.weights.values() if v > 0])
        self.first_advisor = self.weights.keys()[0]
        self.resource_counter = OrderedDict().fromkeys(self.weights, 0)
        self.resource_sum = 0
        self.last_alloc_advisor = None

    def trace(self):
        """输出分配情况
        """
        print '\nAllocated sum: %d' % self.resource_sum

        advisors = self.weights.keys()
        line1 = "\t".join(advisors)
        line2 = "\t".join([str(WEIGHTS.get(k, 1)) for k in advisors])
        line3 = "\t".join([str(self.resource_counter.get(k, 0))
                           for k in advisors])
        if self.resource_sum is 0:
            line4 = "\t".join(["0.0%"] * len(advisors))
        else:
            line4 = "\t".join(
                ['%.1f%%' % (1.0 * self.resource_counter.get(k, 0) /
                             self.resource_sum * 100) for k in advisors])
        print "Advisor:\t" + line1
        print "Weight:\t\t" + line2
        print "Allocated:\t" + line3
        print "Percent:\t" + line4
