# coding: utf-8

PUSH_TO_CRP_COMEFROM = u'集团渠道'
PUSH_TO_CRP_XIFENQUDAO = u'移民推荐'

FOLLOW_PERSON_DEFUALT = u'王硕'
