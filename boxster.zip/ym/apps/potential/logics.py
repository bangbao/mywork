# coding: utf-8

import os
import re
import json
import datetime
from django.utils import timezone
from django.conf import settings
from django.db.models import Q
from shunlib.utilities import utils
from shunlib.utilities import mytime
from ym.apps.crm.serializers import ResourceToCrmSerializer
from ym.apps.perm import potential as perm_potential
from ym.apps.perm import manager as perm_manager
from ym.apps.potential.models import (
    Advisor_potential_student,
    Advisor_student_country,
    Advisor_student_program,
    Advisor_student_remark,
    Advisor_info,
)
from ym.apps.potential.serializers import (
    AdvisorPotentialStudentSerializer,
    AdvisorStudentCountrySerializer,
    AdvisorStudentProgramSerializer,
    AdvisorStudentRemarkSerializer,
)


qudao_mark = {}

mark_qudao = {}
for k, v in qudao_mark.items():
    if mark_qudao.get(v):
        mark_qudao[v].append(k)
    else:
        mark_qudao[v] = [k]

# SEO: S2, 在线表单: S8, 在线注册: S19, SEM: S20, SJ: S21, 400电话: S22,
# c1: S23, IAPP: S24, AAPP: S25
special_groups = ['S2', 'S8', 'S19', 'S20', 'S21', 'S22', 'S23', 'S24', 'S25']
special_chs = []
for chs in special_groups:
    try:
        special_chs += mark_qudao[chs]
    except KeyError:
        pass


def get_potential_page(one, many, length):
    groups = []
    while many:
        group = []
        for _ in range(length):
            try:
                group.append(many.pop(0))
            except IndexError:
                break
        groups.append(group)
    page = 0
    for group in groups:
        if one in group:
            return(page)
        page += 1


def query_potential_muti(user, conditions=None, keywords=None, order_by=None,
                         page=None, length=None):
    """条件查询各种资源
    Args:
        user: 查询用户对象
        filters: {} (optional, json字符串) // 详情参考BI中筛选条件参数
        keywords: - 搜索关键词，多个词用空格隔开
        order_by - 排序字段，array
        page - 页数（从0开始），默认为0
        length - 每页返回客户数量，默认为10
    Returns:
        result: 结果
    """
    uid = user.id
    sql = "IF(alloc_at is null OR create_at=alloc_at, entry_time, alloc_at)"
    q = Advisor_potential_student.objects.extra(
        select={"transfer_at": sql})

    can_see_mobile = perm_manager.can_mobile_view(user)
    # 某些用户可看所有资源
    if perm_manager.can_potential_view(user):
        potential_students_query = q.filter()
    else:
        childs = perm_manager.get_userlevel_childs(user)
        childs.append(uid)
        potential_students_query = q.filter(uid__in=childs)

    is_pending_filters = get_is_pending_filters()
    if conditions:
        conditions = json.loads(conditions)
        filter_country_program_once = False
        for filter_field, value in conditions.iteritems():
            if value is None:           # 忽略null
                continue
            # 申请国家和项目
            if filter_field in ('country', 'program'):
                if filter_country_program_once:
                    continue
                countries = conditions.get('country', [])
                programs = conditions.get('program', [])
                potential_students_query = \
                    potential_students_query.filter2(
                        filter_country_program=True,
                        countries=countries,
                        programs=programs)
                filter_country_program_once = True
                continue
            # 录入日期
            if filter_field == "create_at":
                start_time = mytime.timestamp2dt(value[0] / 1000)
                end_time = mytime.timestamp2dt(value[1] / 1000)
                filters = Q(create_at__isnull=False,
                            create_at__gte=start_time,
                            create_at__lt=end_time)
                potential_students_query = potential_students_query.filter(
                    filters)
                continue
            # 按星级
            if filter_field == 'rate':
                potential_students_query = potential_students_query.filter(
                    rate__in=value)
                continue
            # 跟进顾问
            if filter_field == 'follow_person':
                if value:
                    potential_students_query = \
                        potential_students_query.filter(
                            follow_person__icontains=value)
                continue
            # 跟进状态
            if filter_field == 'follow_status':
                potential_students_query = potential_students_query.filter(
                    follow_status__in=value)
                continue
            # 资源状态
            if filter_field == 'status':
                potential_students_query = potential_students_query.filter(
                    status__in=value)
                continue
            # 来源
            if filter_field == 'comefrom':
                potential_students_query = potential_students_query.filter(
                    comefrom__in=value)
                continue
            # 待跟进资源
            if filter_field == 'is_pending':
                potential_students_query = potential_students_query.filter(
                    is_pending_filters)
                continue

            # 动态兼容列表搜索
            if isinstance(value, (list, tuple)):
                filter_field = '%s__in' % filter_field
            potential_students_query = potential_students_query.filter(
                **{filter_field: value})

    # 搜索
    if keywords:
        keywords = re.sub(' +', ' ', keywords.strip())
        keywords = keywords.split(' ')
        potential_students_query = potential_students_query.search(
            keywords, search_remark=True)

    # 排序
    if order_by:
        order_by = order_by.replace('remarks', 'latest_remark_time')
        order_fields = json.loads(order_by)
        field_names = [filed.attname
                       for filed in Advisor_potential_student._meta.fields]
        order_fields = [key for key in order_fields
                        if key and key.lstrip('-') in field_names]
        potential_students_query = potential_students_query.order_by(
            *order_fields)

    # 分页
    # transfer_at was used 'HAVING', but queryset.count
    # doesn't support count method with 'HAVING'
    # count = potential_students_query.count()
    # 待跟进资源数
    pending_count = potential_students_query.filter(
        is_pending_filters).count()
    count = len(potential_students_query)

    result_dict = {
        "count": count,
        "page": page,
        "pending_count": pending_count,
        "dlist": [],
    }

    # potential_ids = [int(p.id) for p in potential_students_query]
    # return potential's page
    # if potential_id:
    #     potential_id = int(potential_id)
    #     # potential_ids = [int(p.id) for p in potential_students_query]
    #     at_page = get_potential_page(potential_id, potential_ids, length)
    #     if at_page:
    #         print('at_page: {}'.format(at_page))
    #         page = at_page
    #         result_dict['page'] = page

    potential_students_query = potential_students_query[
        page * length:(page + 1) * length]
    potential_ids = [int(p.id) for p in potential_students_query]
    serializer = AdvisorPotentialStudentSerializer(
        potential_students_query, many=True)
    result = []
    # advisor_uids = [p.uid for p in potential_students_query]
    # 顾问名字们
    # advisor_names = dict(Advisor_info.objects.filter(
    #     uid__in=advisor_uids).values_list('uid', 'full_name'))
    # 备注
    remarks_query = Advisor_student_remark.objects.order_by(
        'create_at', 'id').filter(potential_id__in=potential_ids)
    remarks_data = AdvisorStudentRemarkSerializer(
        remarks_query, many=True).data
    # 移民国家
    applied_countries_query = Advisor_student_country.objects.order_by(
        'create_at', 'id').filter(potential_id__in=potential_ids)
    applied_countries_data = AdvisorStudentCountrySerializer(
        applied_countries_query, many=True).data
    # 移民项目
    applied_programs_query = Advisor_student_program.objects.order_by(
        'create_at', 'id').filter(potential_id__in=potential_ids)
    applied_programs_data = AdvisorStudentProgramSerializer(
        applied_programs_query, many=True).data

    forbidden_fields = perm_potential.get_forbidden_perm_fields(user)
    for row in serializer.data:
        # row['follow_person'] = advisor_names.get(row['uid'])
        if not can_see_mobile and row['mobile']:
            row['mobile'] = utils.cover_mobile(row['mobile'])
        row.setdefault('remarks', [])
        for remark in remarks_data:
            if row["id"] == remark["potential_id"]:
                row["remarks"].append(remark)

        row.setdefault('countries_programs', [])
        for c_data in applied_countries_data:
            if row['id'] == c_data['potential_id']:
                c_data = dict(c_data)
                row['countries_programs'].append(c_data)
                c_data.setdefault('programs', [])
                for p_data in applied_programs_data:
                    if (c_data['country'] == p_data['country'] and
                            row['id'] == p_data['potential_id']):
                        c_data['programs'].append(p_data)

        # replace xifenqudao to code
        if row["xifenqudao"] in qudao_mark:
            if row["xifenqudao"] in special_chs:
                if row['comefrom'] == '集团渠道':
                    row["xifenqudao"] = qudao_mark[row["xifenqudao"]]
            else:
                row["xifenqudao"] = qudao_mark[row["xifenqudao"]]

        row = perm_potential.get_potential_forbidden_result(user, row,
                                                            forbidden_fields)
        result.append(row)

    result_dict['dlist'] = result
    return result_dict


def get_is_pending_filters():
    """待跟进判断filters
    """
    pending_time = timezone.now() - datetime.timedelta(days=14)
    filters = Q(latest_remark_time__lte=pending_time) & \
        ~Q(status__in=(10, 50)) & \
        ~Q(follow_status__in=(66,))
    return filters


def trans_potential_result2xlsx(result, filename):
    """把结果写入到文件
    TODO: 完善
    """
    filepath = os.path.join(settings.STATIC_ROOT, 'test_download.txt')
    return filepath


def calc_potential_rate(gross_assets, expendable_fund):
    """计算客户资源评价星级
    Args:
        gross_assets: 总资产
        expendable_fund: 可用资产
    Returns:
        评价星级
    """
    score1 = min(5, expendable_fund * 5.0 / 500)
    score2 = min(5, gross_assets * 5.0 / 500)
    score = score1 + score2

    if score >= 10:
        return 5
    if 5.5 <= score < 10:
        return 4
    if 3.5 <= score < 5.5:
        return 3
    if 3 <= score < 3.5:
        return 2
    return 1


def get_potential_info(user, potential):
    """获取一条资源的详细数据
    Args:
        user: 用户对象
        potential: 资源对象
    Returns:
        资源详细
    """
    serializer = AdvisorPotentialStudentSerializer(potential)

    remark_query = potential.related_remarks.order_by('create_at', 'id')
    remarks_data = AdvisorStudentRemarkSerializer(
        remark_query, many=True).data
    # 移民国家
    country_query = potential.related_countries.order_by('create_at', 'id')
    countries_data = AdvisorStudentCountrySerializer(
        country_query, many=True).data
    # 移民项目
    program_query = potential.related_programs.order_by('create_at', 'id')
    programs_data = AdvisorStudentProgramSerializer(
        program_query, many=True).data

    result = serializer.data
    result['remarks'] = remarks_data
    result['countries_programs'] = []
    for c_data in countries_data:
        result['countries_programs'].append(c_data)
        c_data.setdefault('programs', [])
        for p_data in programs_data:
            if c_data['country'] == p_data['country']:
                c_data['programs'].append(p_data)

    return perm_potential.get_potential_forbidden_result(user, result)


def appoint_advisor(potential, advisor):
    """给资源分配顾问
    Args:
        potential: Advisor_potential_student对象
        advisor: Advisor_info对象
    Returns:
        potential: 修改后的Advisor_potential_student对象
    """
    potential.uid = advisor.uid
    potential.follow_person = advisor.full_name

    return potential


def auto_trans_invaild_potential(potential=None):
    """自动把废弃资源转移到固定顾问上
    资源状态＋跟进状态双无效时，资源自动转给mktbd@sihaiyimin.com
    """
    email = 'mktbd@sihaiyimin.com'
    try:
        advisor = Advisor_info.objects.get(email=email)
    except Advisor_info.DoesNotExist:
        print 'Advisor email (%s) not exists, break!' % email
        return

    if potential is None:
        Advisor_potential_student.objects.filter(
            follow_status=10, status=10).exclude(uid=advisor.uid).update(
                uid=advisor.uid, follow_person=advisor.full_name)
    else:
        if (int(potential.follow_status) == 10 and int(potential.status) == 10 and
                potential.uid != advisor.uid):
            potential = appoint_advisor(potential, advisor)
            potential.save()


def set_chosen(potential):
    pass


def prepare_for_crm(resource_data, many=None):
    """暂存准备推送到CRM的数据
    """
    serializer = ResourceToCrmSerializer(data=resource_data, many=many is True)
    if not serializer.is_valid():
        return 1, serializer.errors    # 字段校验失败, 不能保存到数据库

    res_query = serializer.save()
    if res_query.flag == 2:
        return 2, u'该资源可能已存在于CRP客户资源库中，有撞单风险'

    return 0, {}
