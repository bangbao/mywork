# coding: utf-8


def sync_user_advisor_info(sender, instance, created, **kwargs):
    """自动同步用户信息到advisor_info表中
    """
    from ym.apps.potential.models import Advisor_info

    users = instance
    nickname = users.name or users.user_name
    Advisor_info.objects.filter(uid=users.uid).exclude(
        full_name=nickname,
        email=users.email,
        mobile=users.mobile,
        advisor_type=users.user_type).update(
            first_name=nickname[0],
            last_name=nickname[1:],
            full_name=nickname,
            advisor_type=users.user_type,
            email=users.email)
