# coding: utf-8

import json
from django.db.models import Q
from shunlib.utilities import utils
from shunlib.utilities.decorators import api_view
from ym.apps.option import logics as option_logic
from ym.apps.potential import logics as potential_logic
from ym.apps.option.models import Advisor_student_follow_status_list
from ym.apps.crm.models import Crm_User_info
from ym.apps.crm.serializers import CrmUserInfoSerializer
from ym.apps.potential.models import (Advisor_potential_student,
                                      Advisor_info,
                                      Advisor_student_remark)
from ym.apps.potential.serializers import AdvisorStudentRemarkSerializer
from . import consts


@api_view(['POST'])
def crm_potential_insert(request):
    """crm系统推送资源
    """
    output_dict = dict()
    insert_data = request.data.copy()

    insert_data.pop('flag', None)
    insert_data.pop('crm_update_flag', None)
    insert_data.pop('create_time', None)

    cuscode = insert_data.get('cuscode')
    mobile = insert_data.get('mobile')
    if mobile:
        crm_query = Crm_User_info.objects.filter(mobile=mobile)
    elif cuscode:
        crm_query = Crm_User_info.objects.filter(cuscode=cuscode)
    else:
        crm_query = None

    if crm_query and crm_query.exists():
        output_dict['cuscode'] = cuscode
        output_dict['mobile'] = mobile
        output_dict['success'] = False
        output_dict['reason'] = u'资源已存在:{}'.format(mobile)
        output_dict['code'] = 1
        print '>>>crm_potential_insert: {}'.format(output_dict['reason'])
        return output_dict

    # 设定默认推荐人信息
    insert_data.update(consts.CRM_TUIJIAN_INFO_DEFAULT)
    # 统一由``分配资源
    insert_data['follow_person'] = Advisor_info.get_default_advisor(only_name=True)
    # 确定数据源
    insert_data['source'] = 'crm'
    insert_serializer = CrmUserInfoSerializer(data=insert_data, partial=True)
    if not insert_serializer.is_valid():
        output_dict['cuscode'] = cuscode
        output_dict['success'] = False
        output_dict['reason'] = insert_serializer.errors
        output_dict['code'] = 2
        print '>>>crm_potential_insert: {}'.format(output_dict['reason'])
        return output_dict

    insert_serializer.save()
    output_dict['success'] = True
    output_dict['reason'] = ''
    output_dict['code'] = 0
    return output_dict


@api_view(['POST'])
def crp_potential_insert(request):
    """CRP系统资源推送
    """
    insert_data = request.data.get('data', '{}')
    output_dict = {}

    try:
        insert_data = json.loads(insert_data)
    except Exception as e:
        output_dict['code'] = 6
        output_dict['result'] = u'json.loads error %r' % e
        return output_dict

    try:
        sign = insert_data.pop('sign', '')
        sign_key = 'boxster'

        if not utils.verifiy_sign(insert_data, sign_key, sign):
            output_dict['code'] = 1
            output_dict['result'] = u'签名错误'
            return output_dict

        if not insert_data.get('mobile'):
            output_dict['code'] = 7
            output_dict['result'] = u'意向客户手机号不能为空'
            return output_dict

        if (not insert_data.get('ym_mobile') or
                not insert_data.get('ym_username')):
            output_dict['code'] = 8
            output_dict['result'] = u'移民联系人及电话必填'
            return output_dict

        advisor_name = insert_data.pop('advisor_name', None)
        advisor_id = insert_data.pop('advisor_id', None)
        potential_id = insert_data.pop('potential_id', None)
        # 删除所有为None的字段, 防止数据库校验报错
        for k, v in insert_data.items():
            if v is None:
                insert_data.pop(k, None)
        filters_exist = (Q(mobile=insert_data['mobile']) |
                         Q(crp_potential_id=potential_id))
        crm_query = Crm_User_info.objects.filter(filters_exist)
        pot_query = Advisor_potential_student.objects.filter(filters_exist)

        if crm_query.exists() or pot_query.exists():
            output_dict['code'] = 2
            output_dict['result'] = u'该资源已存在，无法推送'
            return output_dict

        # 自动计算评价星级
        if not insert_data.get('rate'):
            gross_assets = insert_data.get('gross_assets') or 0
            expendable_fund = insert_data.get('expendable_fund') or 0
            rate = potential_logic.calc_potential_rate(gross_assets,
                                                       expendable_fund)
            insert_data['gross_assets'] = gross_assets
            insert_data['expendable_fund'] = expendable_fund
            insert_data['rate'] = rate

        if advisor_name and advisor_id:
            filter_advisor = (Q(full_name=advisor_name) |
                              Q(crp_advisor_id=advisor_id))
            try:
                advisor_query = Advisor_info.objects.get(filter_advisor)
            except Advisor_info.DoesNotExist:
                pass
            else:
                if advisor_query.crp_advisor_id != advisor_id:
                    advisor_query.crp_advisor_id = advisor_id
                    advisor_query.save()
                insert_data['follow_person'] = advisor_query.full_name
                insert_data['pusher'] = advisor_name
                insert_data['create_user'] = advisor_id

        # 没有指定, 默认分配给``
        if not insert_data.get('follow_person'):
            default_advisor = Advisor_info.get_default_advisor(only_name=True)
            insert_data['follow_person'] = default_advisor

        # 确定数据源
        insert_data['source'] = 'crp'
        insert_data['crp_potential_id'] = potential_id
        insert_data['cuscode'] = 'crp{}'.format(potential_id)
        insert_data['level_adjust'] = insert_data.get('rate', 1)
        insert_data['apply_contry'] = insert_data.get('country', '')
        insert_data['apply_program'] = insert_data.get('program', '')
        insert_data['business_unit'] = u'海外移民'
        if insert_data['advisor_city'].endswith(u'市'):
            branch_company = insert_data['advisor_city'][:-1] + u'分公司'
            insert_data['branch_company'] = branch_company
        else:
            output_dict['code'] = 5
            output_dict['result'] = u'顾问城市错误'
            return output_dict

        insert_serializer = CrmUserInfoSerializer(data=insert_data,
                                                  partial=True)
        if insert_serializer.is_valid():
            insert_serializer.save()
            output_dict['code'] = 0
            output_dict['result'] = {'potential_id': potential_id}
        else:
            output_dict['code'] = 3
            output_dict['result'] = insert_serializer.errors
    except Exception as e:
        output_dict['code'] = 4
        output_dict['result'] = repr(e)

    return output_dict


@api_view(['GET'])
def crp_potential_info(request):
    """crp获取ym系统对应资源的一些信息
    """
    crp_potential_id = request.query_params.get('potential_id')

    if not crp_potential_id.isdigit():
        return {'result': u'资源ID只能为数字', 'code': 2}

    crp_potential_id = int(crp_potential_id)

    try:
        potential_query = Advisor_potential_student.objects.get(
            crp_potential_id=crp_potential_id)
    except Advisor_potential_student.DoesNotExist:
        crm_query = Crm_User_info.objects.filter(
            crp_potential_id=crp_potential_id)
        if crm_query.exists():
            return {'result': u'系统正在分配资源, 请稍后', 'code': 1}
        return {'result': u'没找到对应资源', 'code': 1}

    remarks_query = Advisor_student_remark.objects.order_by(
        'create_at', 'id').filter(potential_id=potential_query.id)
    remarks_data = AdvisorStudentRemarkSerializer(
        remarks_query, many=True).data
    remarks = [{'id': obj['id'], 'create_at': obj['create_at'],
                'modify_at': obj['modify_at'],
                'content': obj['content'], 'potential_id': obj['potential_id']}
               for obj in remarks_data]
    text_data = Advisor_student_follow_status_list.objects.filter(
        value=potential_query.follow_status).values('text')
    follow_status_text = text_data[0]['text']
    result = {
        'remarks': remarks,
        'follow_status': follow_status_text,
        'follow_person': potential_query.follow_person,
        'potential_id': crp_potential_id,
    }
    return {'result': result, 'code': 0}


@api_view(['GET'])
def crp_option_info(request):
    """crp获取下拉选项数据
    """
    result = {
        'countries_programs': option_logic.get_countries_programs_list(),
        'bm_experiences': option_logic.get_bm_experiences_list(),
        'rates': option_logic.get_rates_list(),
    }
    return {'result': result, 'code': 0}
