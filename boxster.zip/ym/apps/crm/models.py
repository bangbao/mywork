# -*- coding: utf-8 -*-

from django.db import models
from audit_log.models.managers import AuditLog
from django.db.models.signals import pre_save


class Crm_User_info(models.Model):
    cuscode = models.CharField(max_length=20, null=True, blank=True)             # 客户CRM编号
    name = models.CharField(max_length=30, null=True, blank=True)                # 客户姓名
    phone = models.CharField(max_length=20, null=True, blank=True)               # 客户电话
    mobile = models.CharField(max_length=20, null=True, blank=True)              # 客户电话
    other_phone = models.CharField(max_length=20, null=True, blank=True)         # 客户其它电话
    sex = models.CharField(max_length=10, null=True, blank=True)                 # 性别 男/女
    comefrom = models.CharField(max_length=50, null=True, blank=True)            # 来源渠道
    create_user = models.CharField(max_length=10, null=True, blank=True)         # 创建人员
    line_item = models.CharField(max_length=30, null=True, blank=True)           # 项目线
    follow_person = models.CharField(max_length=20, null=True, blank=True)       # 指定顾问
    level_adjust = models.CharField(max_length=30, null=True, blank=True)        # 星级
    latest_status = models.CharField(max_length=30, null=True, blank=True)       # 最新状态
    age = models.CharField(max_length=10, null=True, blank=True)                 # 年龄
    attribution = models.CharField(max_length=20, null=True, blank=True)         # 归属地
    branch_company = models.CharField(max_length=20, null=True, blank=True)      # 分公司名称
    graduate_school = models.CharField(max_length=50, null=True, blank=True)     # 毕业院校
    current_education = models.CharField(max_length=30, null=True, blank=True)   # 目前学历
    current_professional = models.CharField(max_length=30, null=True, blank=True)  # 目前专业
    gpa_performance = models.CharField(max_length=30, null=True, blank=True)     # GPA绩点
    average_score = models.CharField(max_length=30, null=True, blank=True)       # 平均分
    apply_contry = models.CharField(max_length=30, null=True, blank=True)        # 申请国家
    target_school = models.CharField(max_length=30, null=True, blank=True)       # 目标院校
    apply_education = models.CharField(max_length=30, null=True, blank=True)     # 申请学历
    apply_professional = models.CharField(max_length=30, null=True, blank=True)  # 申请专业
    comefrompoint = models.CharField(max_length=20, null=True)       # 渠道返点
    email = models.CharField(max_length=30, null=True, blank=True)               # 邮件
    create_time = models.DateTimeField(auto_now_add=True)              # 创建时间
    flag = models.IntegerField(default=0)                            # 记录标记
    planning_year = models.CharField(max_length=10, null=True, blank=True)
    follow_road = models.CharField(max_length=50, null=True, blank=True)
    origin_id = models.CharField(max_length=10, null=True, blank=True)
    current_grade = models.CharField(max_length=10, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    contacts_type = models.CharField(max_length=50, null=True, blank=True)
    contacts_name = models.CharField(max_length=40, null=True, blank=True)
    qq = models.CharField(max_length=20, null=True, blank=True)
    wechat = models.CharField(max_length=20, null=True, blank=True)
    convenient_time = models.CharField(max_length=20, null=True, blank=True)
    crm_update_flag = models.IntegerField(default=0, null=True, blank=True)
    business_unit = models.CharField(max_length=20, null=True, blank=True)
    xifenqudao = models.CharField(max_length=20)
    create_at = models.DateTimeField(auto_now_add=True)
    qudao_details = models.CharField(max_length=32, null=True, blank=True)
    houxuan_country1 = models.CharField(max_length=32, null=True, blank=True)
    houxuan_country2 = models.CharField(max_length=32, null=True, blank=True)
    houxuan_country3 = models.CharField(max_length=32, null=True, blank=True)
    ignore_advisor = models.CharField(max_length=32, null=True, blank=True)   # 不分配的顾问名字
    pusher = models.CharField(max_length=32, null=True, blank=True)           # 推送人
    crp_potential_id = models.IntegerField(null=True, blank=True)             # crp推送资源id
    gross_assets = models.IntegerField(default=0)                       # 总资产
    expendable_fund = models.IntegerField(default=0)                    # 可用资金
    bm_experience = models.CharField(max_length=32, null=True)          # 商业管理经验
    apply_program = models.CharField(max_length=64, null=True)          # 申请项目
    ym_mobile = models.CharField(max_length=20, blank=True, null=True)  # 移民联系人手机
    ym_username = models.CharField(max_length=30, blank=True, null=True)  # 移民联系人
    tuijian_name = models.CharField(max_length=30, blank=True, null=True)  # 推荐人姓名
    tuijian_mobile = models.CharField(max_length=20, blank=True, null=True)  # 推荐人手机
    tuijian_branch = models.CharField(max_length=20, blank=True, null=True)  # 推荐人分公司
    tuijian_depart = models.CharField(max_length=20, blank=True, null=True)  # 推荐人部门

    audit_log = AuditLog()

    class Meta:
        verbose_name = "资源"
        verbose_name_plural = "资源暂存池"


class AdvisorRemainRecord(models.Model):
    """顾问预期未跟进提醒记录
    """
    advisor_uid = models.IntegerField()
    create_at = models.DateTimeField(auto_now_add=True)


class ResourceToCrm(models.Model):
    """准备发送给CRM的资源
    """
    flag = models.IntegerField(default=0)       # 状态 0:未发送 1:已发送, 2发送失败
    name = models.CharField(max_length=30, null=True, blank=True)       # 客户姓名
    sex = models.CharField(max_length=10, null=True, blank=True)        # 性别 男/女
    mobile = models.CharField(max_length=20, null=True, blank=True)       # 客户电话
    phone = models.CharField(max_length=20, null=True, blank=True)        # 客户电话
    other_phone = models.CharField(max_length=20, null=True, blank=True)  # 客户其它电话
    wechat = models.CharField(max_length=32, null=True, blank=True)       # wechat
    email = models.CharField(max_length=255, null=True, blank=True)     # email
    attribution = models.CharField(max_length=20, null=True, blank=True)  # 归属地
    apply_contry = models.CharField(max_length=30, null=True, blank=True)   # 申请国家
    apply_education = models.CharField(max_length=30, null=True, blank=True)  # 申请学历
    graduate_school = models.CharField(max_length=50, null=True, blank=True)  # 毕业院校
    current_education = models.CharField(max_length=30, null=True, blank=True)  # 目前学历
    gpa_performance = models.CharField(max_length=30, null=True, blank=True)  # GPA绩点
    average_score = models.CharField(max_length=30, null=True, blank=True)  # 平均分
    level_adjust = models.CharField(max_length=30, null=True, blank=True)   # 星级
    comefrom = models.CharField(max_length=50, null=True, blank=True)       # 来源渠道
    xifenqudao = models.CharField(max_length=50, null=True, blank=True)     # 细分渠道
    qudao_details = models.CharField(max_length=32, null=True, blank=True)  # 渠道详情
    follow_person = models.CharField(max_length=20, null=True, blank=True)  # 指定顾问
    remark = models.TextField(null=True, blank=True)
    planning_year = models.CharField(max_length=10, null=True, blank=True)  # 计划出国时间
    create_user = models.CharField(  # CRM创建用户
        max_length=12, null=True, default='9003')
    line_item = models.CharField(max_length=32, null=True, blank=True)  # 项目线
    create_at = models.DateTimeField(auto_now_add=True)
    wap_source = models.CharField(max_length=32, null=True, blank=True)  # WAP广告调用信息
    wap_page = models.CharField(max_length=32, null=True, blank=True)  # WAP页面信息
    ym_mobile = models.CharField(max_length=20, blank=True, null=True)  # 移民联系人手机
    ym_username = models.CharField(max_length=30, blank=True, null=True)  # 移民联系人
    tuijian_name = models.CharField(max_length=30, blank=True, null=True)  # 推荐人姓名
    tuijian_mobile = models.CharField(max_length=20, blank=True, null=True)  # 推荐人手机
    tuijian_branch = models.CharField(max_length=20, blank=True, null=True)  # 推荐人分公司
    tuijian_depart = models.CharField(max_length=20, blank=True, null=True)  # 推荐人部门

    @classmethod
    def connect_signal(cls):
        pre_save.connect(receiver=resource_to_crm, sender=cls)


def resource_to_crm(sender, instance, **kwargs):
    """将resourcetocrm表的数据推送到CRM
    """
    from ym.utilities.crmcomm import MyCrmComm
    print('Push {}({}) to crm'.format(instance.name, instance.mobile))

    insert_data = dict()
    update_keys = (
        'name', 'sex', 'mobile', 'phone', 'other_phone',
        'attribution', 'planning_year', 'line_item',
        'apply_contry', 'apply_education', 'graduate_school',
        'current_education', 'gpa_performance', 'average_score',
        'level_adjust', 'comefrom', 'xifenqudao', 'qudao_details',
        'follow_person', 'remark', 'create_user')
    for key in update_keys:
        insert_data[key] = getattr(instance, key)

    insert_data.update(
        business_unit=u'海外移民',
        comefrom=u'集团渠道',
        xifenqudao=u'移民推荐',
        qudao_details=u'移民推荐',
        create_user=7001,
        level_adjust=insert_data['level_adjust'] and int(insert_data['level_adjust']) or 1,
        contacts_type=u'其他',
        apply_contry=insert_data['apply_contry'] or u'其它',
        branch_company=u'北京分公司',
    )
    res = MyCrmComm().crm_potential_info_update(insert_data)
    if res:
        instance.flag = 1
    else:
        instance.flag = 2

ResourceToCrm.connect_signal()


class PushCrmFailed(models.Model):
    name = models.CharField(max_length=30, null=True)
    mobile = models.CharField(max_length=20)
    reason = models.CharField(max_length=32)
    cuscode = models.CharField(max_length=20, null=True)
    create_at = models.DateTimeField(auto_now_add=True)
