# -*- coding: utf-8 -*-

from rest_framework import serializers
from .models import Crm_User_info, ResourceToCrm


class CrmUserInfoSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    cuscode = serializers.CharField(required=True)
    name = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    phone = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    mobile = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    other_phone = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    sex = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    comefrom = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    create_user = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    line_item = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    follow_person = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    level_adjust = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    latest_status = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    age = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    attribution = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    branch_company = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    graduate_school = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    current_education = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    current_professional = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    gpa_performance = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    average_score = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    apply_contry = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    target_school = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    apply_education = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    apply_professional = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    comefrompoint = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    email = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    create_time = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    planning_year = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    follow_road = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    origin_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    current_grade = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    remark = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    contacts_type = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    contacts_name = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    qq = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    wechat = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    convenient_time = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    business_unit = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    xifenqudao = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    crm_update_flag = serializers.IntegerField(required=False, default=0)
    flag = serializers.IntegerField(required=False, default=1)
    qudao_details = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    pusher = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    crp_potential_id = serializers.IntegerField(required=False)                 # crp推送资源id
    gross_assets = serializers.IntegerField(required=False, default=0, allow_null=True)  # 总资产
    expendable_fund = serializers.IntegerField(required=False, default=0, allow_null=True)   # 可用资金
    bm_experience = serializers.CharField(required=False, allow_blank=True, allow_null=True)  # 商业管理经验
    apply_program = serializers.CharField(required=False, allow_blank=True, allow_null=True)  # 申请项目
    ym_mobile = serializers.CharField(required=False, allow_blank=True, allow_null=True)  # 移民联系人手机号
    ym_username = serializers.CharField(required=False, allow_blank=True, allow_null=True)  # 移民联系人
    tuijian_name = serializers.CharField(required=False, allow_blank=True,
                                         allow_null=True)
    tuijian_mobile = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)
    tuijian_branch = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)
    tuijian_depart = serializers.CharField(required=False, allow_blank=True,
                                           allow_null=True)

    def create(self, validated_data):
        return Crm_User_info.objects.create(**validated_data)

    def update(self, instance, validated_data):
        field_names = instance._meta.get_all_field_names()
        for key, value in validated_data.iteritems():
            if key in field_names:
                setattr(instance, key, value)

        instance.save()
        return instance


class ResourceToCrmSerializer(serializers.ModelSerializer):

    class Meta:
        model = ResourceToCrm
