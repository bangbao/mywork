# coding: utf-8

from shunlib.utilities.decorators import api_view
from . import logics as option_logic


@api_view(['POST', 'GET'])
def countries_list(request):
    """移民国家列表
    """
    result = option_logic.get_countries_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def programs_list(request):
    """移民项目列表
    """
    result = option_logic.get_programs_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def countries_programs_list(request):
    """移民国家项目列表
    """
    result = option_logic.get_countries_programs_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def linguistic_competences_list(request):
    """语言能力列表
    """
    result = option_logic.get_linguistic_competences_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def marital_statuses_list(request):
    """婚姻状态列表
    """
    result = option_logic.get_marital_statuses_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def follow_statuses_list(request):
    """跟进状态列表
    """
    result = option_logic.get_follow_statuses_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def statuses_list(request):
    """资源状态列表
    """
    result = option_logic.get_statuses_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def country_types_list(request):
    """移民国家类型列表
    """
    result = option_logic.get_country_types_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def program_types_list(request):
    """移民项目类型列表
    """
    result = option_logic.get_program_types_list()

    return {'code': 0, 'result': result}


@api_view(['POST', 'GET'])
def comefroms_list(request):
    """移民来源列表
    """
    result = option_logic.get_comefroms_list()

    return {'code': 0, 'result': result}


@api_view(['GET'])
def branch_companies_list(request):
    """分公司列表
    """
    result = option_logic.get_branch_companies_list()

    return {'code': 0, 'result': result}


@api_view(['GET'])
def mobile_attribution(request):
    """手机号归属地
    """
    mobile = request.query_params.get('mobile')

    result = option_logic.get_mobile_attribution(mobile)

    return {'code': 0, 'result': result}


@api_view(['GET'])
def xifenqudaos_list(request):
    """细分渠道列表
    """
    result = option_logic.get_xifenqudaos_list()

    return {'code': 0, 'result': result}


@api_view(['GET'])
def bm_experiences_list(request):
    """商业管理经验列表
    """
    result = option_logic.get_bm_experiences_list()

    return {'code': 0, 'result': result}
