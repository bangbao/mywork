# coding: utf-8

from django.db import models


class Advisor_student_xifenqudao_list(models.Model):
    """细分渠道表
    """
    xifenqudao = models.CharField(max_length=32, null=True, verbose_name='xifenqudao')
    comefrom = models.CharField(max_length=32, null=True, verbose_name='comefrom')

    class Meta:
        verbose_name = verbose_name_plural = u"细分渠道表"


class Advisor_student_country_list(models.Model):
    """移民国家列表说明
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.CharField(max_length=32, null=True, verbose_name='value')

    class Meta:
        verbose_name = verbose_name_plural = "移民国家列表"


class Advisor_student_program_list(models.Model):
    """移民项目列表说明
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.CharField(max_length=32, null=True, verbose_name='value')

    class Meta:
        verbose_name = verbose_name_plural = "移民项目列表"


class Advisor_student_country_program_list(models.Model):
    """移民国家项目列表说明
    """
    country = models.CharField(max_length=32, null=True, verbose_name='country')
    category = models.CharField(max_length=32, null=True, verbose_name='category')
    program = models.CharField(max_length=64, null=True, verbose_name='program')

    class Meta:
        verbose_name = verbose_name_plural = "移民国家项目列表"


class Advisor_student_comefrom_list(models.Model):
    """移民来源列表说明
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.CharField(max_length=32, null=True, verbose_name='value')

    class Meta:
        verbose_name = verbose_name_plural = "移民来源列表"


class Advisor_student_follow_status_list(models.Model):
    """移民跟进状态列表说明
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.IntegerField(null=True, verbose_name='value')
    disabled = models.BooleanField(default=False, verbose_name='disabled')

    class Meta:
        verbose_name = verbose_name_plural = "移民跟进状态列表"


class Advisor_student_branch_company_list(models.Model):
    """分公司名下拉表
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.CharField(max_length=32, null=True, verbose_name='value')

    class Meta:
        verbose_name = verbose_name_plural = "分公司名下拉表"


class Advisor_student_bm_experience_list(models.Model):
    """商业管理经验下拉列表
    """
    text = models.CharField(max_length=32, null=True, verbose_name='text')
    value = models.CharField(max_length=32, null=True, verbose_name='value')

    class Meta:
        verbose_name = verbose_name_plural = "商业管理经验下拉列表"
