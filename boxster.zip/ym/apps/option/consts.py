# coding: utf-8

LINGUISTIC_COMPETENCES_LIST = [
    {"text": u"初级", "value": u"初级"},
    {"text": u"中级", "value": u"中级"},
    {"text": u"高级", "value": u"高级"},
]
MARITAL_STATUSES_LIST = [
    {"text": u"未婚", "value": u"未婚"},
    {"text": u"已婚", "value": u"已婚"},
    {"text": u"已婚离异", "value": u"已婚离异"},
]
COUNTRY_TYPES_LIST = [
    {"text": u"候选国家", "value": 0},
    {"text": u"首选国家", "value": 1},
]
PROGRAM_TYPES_LIST = [
    {"text": u"候选项目", "value": 0},
    {"text": u"首选项目", "value": 1},
]
RATES_LIST = range(1, 6)
