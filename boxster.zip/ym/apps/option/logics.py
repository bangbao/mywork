# coding: utf-8

import re
import json
import urllib
from django.conf import settings
from shunlib.utilities import http
from shunlib.utilities import utils
from . import consts
from .models import (
    Advisor_student_country_list,
    Advisor_student_program_list,
    Advisor_student_country_program_list,
    Advisor_student_branch_company_list,
    Advisor_student_follow_status_list,
    Advisor_student_xifenqudao_list,
    Advisor_student_bm_experience_list,
)


def get_countries_list():
    """移民国家列表
    """
    country_list = Advisor_student_country_list.objects.all()

    result = [{'text': obj.text, 'value': obj.value}
              for obj in country_list]

    return result


def get_programs_list():
    """移民项目列表
    """
    program_list = Advisor_student_program_list.objects.all()

    result = [{'text': obj.text, 'value': obj.value}
              for obj in program_list]

    return result


def get_countries_programs_list(need_other=True):
    """移民国家项目列表
    """
    query_list = Advisor_student_country_program_list.objects.all()
    index_caches = {}
    result = []

    for obj in query_list:
        country, program = obj.country, obj.program
        if not need_other and country == u'其他':
            continue
        if country not in index_caches:
            result.append({'text': country, 'value': country,
                           'programs': [{'text': program, 'value': program}]})
            index = len(result) - 1
            index_caches[country] = index
        else:
            index = index_caches[country]
            result[index]['programs'].append({'text': program,
                                              'value': program})

    return result


def get_linguistic_competences_list():
    """语言能力列表
    """
    result = consts.LINGUISTIC_COMPETENCES_LIST

    return result


def get_marital_statuses_list():
    """婚姻状态列表
    """
    result = consts.MARITAL_STATUSES_LIST

    return result


def get_follow_statuses_list():
    """跟进状态列表
    """
    status_list = Advisor_student_follow_status_list.objects.all()

    result = [{'text': obj.text, 'value': obj.value, 'disabled': obj.disabled}
              for obj in status_list]

    return result


def get_country_types_list():
    """移民国家类型列表
    """
    result = consts.COUNTRY_TYPES_LIST

    return result


def get_program_types_list():
    """移民项目类型列表
    """
    result = consts.PROGRAM_TYPES_LIST

    return result


def get_comefroms_list():
    """移民来源列表
    """
    data_list = Advisor_student_xifenqudao_list.objects.distinct().values('comefrom')

    result = [{'text': obj['comefrom'], 'value': obj['comefrom']}
              for obj in data_list]

    return result


def get_bm_experiences_list():
    """商业管理经验列表
    """
    data_list = Advisor_student_bm_experience_list.objects.all()

    result = [{'text': obj.text, 'value': obj.value}
              for obj in data_list]

    return result


def get_rates_list():
    """客户星级列表
    """
    return [{'text': i, 'value': i} for i in consts.RATES_LIST]


def get_branch_companies_list():
    """分公司列表
    """
    data_list = Advisor_student_branch_company_list.objects.all()

    result = [{'text': obj.text, 'value': obj.value}
              for obj in data_list]

    return result


def get_mobile_attribution(mobile):
    """获取手机归属地
    """
    mobile_re = re.compile('((^(13\d|14[57]|15[^4,\D]|17[345678]|18\d)'
                           '\d{8}|170[059]\d{7})(|\+\d))$')
    if not mobile_re.match(mobile):
        return {'province': None}

    mobile = mobile[:11]
    url = 'http://tcc.taobao.com/cc/json/mobile_tel_segment.htm?tel={tel}'
    url = url.format(tel=mobile)

    _, result = http.get(url)
    result = result.decode('gb2312')
    match = re.search("province:'(?P<province>.*?)',", result)
    if match:
        province = match.group('province')
    else:
        province = None

    return {
        'province': province,      # 归属地省份
    }


def get_xifenqudaos_list():
    """获取细分渠道列表
    """
    data_list = Advisor_student_xifenqudao_list.objects.all()

    result = [{'text': obj.xifenqudao, 'value': obj.xifenqudao}
              for obj in data_list]

    return result


def get_statuses_list():
    """资源状态列表
    """
    category = "48"
    path = '/info/multi/?category=%s' % category
    url = '%s%s' % (settings.SCHOOL_HOST, path)

    _, content = http.get(url)
    content = json.loads(content)

    result = [{'text': obj['name'], 'value': int(obj['value'])}
              for obj in content['result'][category]]

    return result


def get_comefrom_by_xifenqudao(xifenqudao, default=None):
    """获取细分渠道对应的来源
    Args:
        xifenqudao: 细分渠道
        default: 默认来源
    Returns:
        来源
    """
    comefrom_values = Advisor_student_xifenqudao_list.objects.filter(
        xifenqudao=xifenqudao).values('comefrom')
    if comefrom_values:
        return comefrom_values[0]['comefrom']
    return default


def get_crp_planning_countryies_programs():
    """获取crp留学国家和项目列表
    """
    category_map = {
        'planning_countries': '8',                 # 申请国家
        'planning_programs': '7',                  # 申请项目
    }
    category = ','.join(category_map.itervalues())
    path = '/info/multi/?category=%s' % category
    url = '%s%s' % (settings.SCHOOL_HOST, path)

    _, content = http.get(url)
    result = json.loads(content)['result']

    return_data = {}
    for key, value in category_map.iteritems():
        if value not in result:
            continue
        dlist = [{'text': d['name'], 'value': d['value']}
                 for d in result[value]]
        return_data[key] = dlist

    return return_data


def get_crp_xifenqudao_code_map():
    """获取crp系统细分渠道-code的映射
    """
    path = '/aws/channels_info/'
    query_string = urllib.urlencode({
        'token': 'boxster',
        'hash_key': utils.hashlib_md5_sign('boxster'),
    })
    url = '%s%s?%s' % (settings.CRP_HOST, path, query_string)

    _, content = http.get(url)
    result = json.loads(content)['result']

    xc_map = dict((obj['xifenqudao'], obj['code']) for obj in result)
    return xc_map
