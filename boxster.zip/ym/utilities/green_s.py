# coding: utf8


def get_green():
    from ym.apps.potential.logics import qudao_mark

    mark_qudao = {}
    for k, v in qudao_mark.items():
        if mark_qudao.get(v):
            mark_qudao[v].append(k)
        else:
            mark_qudao[v] = [k]

    # SEO: S2, 在线表单: S8, 在线注册: S19, SEM: S20, SJ: S21, 400电话: S22,
    # c1: S23, IAPP: S24, AAPP: S25
    special_groups = [
        'S2', 'S8', 'S19', 'S20', 'S21', 'S22', 'S23', 'S24', 'S25']
    special_chs = []
    for chs in special_groups:
        try:
            special_chs += mark_qudao[chs]
        except KeyError:
            pass

    return(special_groups, special_chs)
