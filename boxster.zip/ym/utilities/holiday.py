#!/usr/bin/env python
# -*- coding: utf8 -*-

import datetime
import calendar

legal_holiday = []


def get_holidays(start, end):
    '''Return the holidays from start to end

    @return days: int
    '''
    off_days = holidays(start.year, start.month)
    if start.month != end.month:
        off_days += holidays(end.year, end.month)

    check_days = []
    while start <= end:
        check_days.append(start.strftime('%Y%m%d'))
        start += datetime.timedelta(days=1)

    return(set(check_days) & set(off_days))


def holidays(year, month):
    off_days = []
    week, month_range = calendar.monthrange(year, month)
    sunday_saturday = [6, 0]
    for day in range(1, month_range + 1):
        if (week + day) % 7 in sunday_saturday:
            off_days.append('{}{:0>2}{:0>2}'.format(year, month, day))

    # TODO configuration
    vacations = ['20160101', '20160108', '20160111', '20160112', '20160113',
                 '20160205', '20160206', '20160207', '20160208', '20160209',
                 '20160210', '20160211', '20160212', '20160213', '20160214',
                 '20160215', '20160216']
    off_days.extend(vacations)

    return(off_days)


def get_date_range(start_date, end_date):
    start_range = []
    end_range = []

    start_year = int(start_date[:4])
    start_month = int(start_date[4:6])
    end_year = int(end_date[:4])
    end_month = int(end_date[4:6])

    _, start_days = calendar.monthrange(start_year, start_month)
    start_range = ['{}{:0>2}{:0>2}'.format(start_year, start_month, i)
                   for i in range(1, start_days + 1)]
    result_range = start_range

    if start_month != end_month:
        _, end_days = calendar.monthrange(end_year, end_month)
        end_range = ['{}{:0>2}{:0>2}'.format(end_year, end_month, i)
                     for i in range(1, end_days + 1)]
        result_range += end_range

    start_index = result_range.index(start_date) + 1
    end_index = result_range.index(end_date)
    return(result_range[start_index:end_index])

if __name__ == '__main__':
    end = datetime.datetime.now()
    start = end - datetime.timedelta(hours=240)
    print('from {} to {}'.format(start, end))
    print(get_holidays(start, end))
