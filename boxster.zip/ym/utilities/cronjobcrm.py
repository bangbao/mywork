# coding: utf-8

import os
import json
import logging
import requests
from collections import defaultdict
from datetime import datetime, date

from django.conf import settings
from django.db.models import Q
from django.utils import timezone
from datetime import timedelta
from shunlib.utilities.decorators import cronjob_decorator
from ym.apps.crm.models import Crm_User_info, ResourceToCrm
from ym.apps.potential.models import (
    Advisor_info,
    Advisor_potential_student,
    Advisor_student_remark,
    Advisor_score,
)
from ym.apps.potential.serializers import AdvisorScoreSerializer
from ym.apps.potential.allocation import allocator
from ym.utilities.crmcomm import MyCrmComm
from .holiday import get_date_range
from .green_s import get_green


def init_log(fn):
    logger_dir = os.path.join(
        settings.PROJECT_DIR, "logs", "%(folder_name)s", fn)

    folder_name = date.today().strftime("%Y%m%d")
    filename = logger_dir % {"folder_name": folder_name}
    if not os.path.exists(os.path.dirname(filename)):
        os.makedirs(os.path.dirname(filename))
    logger = logging.getLogger(__name__)
    ch = logging.FileHandler(filename)
    logger.setLevel(logging.DEBUG)
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        '[%(levelname)s %(asctime)s %(name)s:%(lineno)d] %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    return(logger, ch)


def transmission(potential):
    logger, ch = init_log("crp_transmission.log")
    try:
        post_data = {}
        post_data['student_uid'] = potential.student_uid
        post_data['advisor_uid'] = potential.uid
        logger.debug('student_uid: {}'.format(post_data['student_uid']))
        logger.debug('advisor_uid: {}'.format(post_data['advisor_uid']))
        url = ('http://api.shunshunliuxue.com/home/api/'
               'potential_transmission/')
        logger.debug('Transmission: student_uid({}) advisor_uid({})'.format(
            post_data['student_uid'], post_data['advisor_uid']))

        resp = requests.post(url, data=post_data, allow_redirects=True).json()
        logger.debug('status: {}'.format(resp['result']['status']))
        logger.debug('error msg: {}'.format(
            resp['result']['error']['errorMessage']))
    except Exception as e:
        logger.debug('Exception: {}'.format(e))
    logger.removeHandler(ch)


@cronjob_decorator
def crm_cronjob():
    """定时迁移Crm_User_info表中数据到Advisor_potential_student中
    """
    crm_user_info_qs = Crm_User_info.objects.exclude(
        xifenqudao__isnull=True).exclude(xifenqudao='').filter(
            flag=0)
    for crm_info in crm_user_info_qs:
        mobile_query = Advisor_potential_student.objects.filter(
            mobile=crm_info.mobile)
        if mobile_query.exists():
            # 如果手机号已存在，则更新数据或直接跳过
            print '>>> potential mobile exists: {}'.format(crm_info.mobile)
            if crm_info.pusher == 'sunnysun':
                print '>>> pusher is sunnysun, update it.'
                allocator.update_potential(crm_info)
            continue

        if crm_info.follow_person:
            potential = allocator.alloc_follow_person(crm_info)
        else:
            print '>>> start match advisor:', crm_info.id
            city = allocator._get_city(crm_info)
            country = allocator._get_country(crm_info)
            advisor = allocator.get_next_advisor(city, country)
            potential = allocator.alloc(crm_info, advisor)
        # New potentials transmission
        if potential:
            transmission(potential)
            advisor = Advisor_info.objects.get(uid=potential.uid)
            sendsms(advisor.mobile, potential, green_s=True)


def sendsms(mobile, potential, transfer=False, green_s=False):
    return
    logger, ch = init_log("sms.log")
    name = potential.full_name
    sms_template = 'SMS_5625208'

    try:
        xifenqudao = potential.xifenqudao
        student_mobile = potential.mobile
    except AttributeError:
        logger.debug("potential({}) hasn't 'xifenqudao' or 'mobile'".format(
            potential.full_name))
        logger.removeHandler(ch)
        return

    if green_s:
        # Send sms(Green S)
        green_code, green_chs = get_green()
        if xifenqudao in green_code + green_chs:
            # 卓小源、杨茜、张玮、游昕曜、周小珂、杨虹、王先鹏上海、
            # 王先鹏南京、胡静、饶芳、王玉伟
            unsend_list = [9328, 5705, 3833, 4074, 1282, 4483, 6104,
                           6541, 6149, 8387, 10328]
            if transfer:
                sms_template = 'SMS_5575249'
                if potential.uid in unsend_list:
                    logger.debug('Send green_S({}) sms to {}({})'.format(
                        student_mobile, mobile, sms_template))
                    sendsmsfunction2(mobile, sms_template,
                                     name=name, student_mobile=student_mobile)
            else:
                if potential.uid not in unsend_list:
                    logger.debug('Send green_S({}) sms to {}({})'.format(
                        student_mobile, mobile, sms_template))
                    sendsmsfunction2(mobile, sms_template,
                                     name=name, student_mobile=student_mobile)
    else:
        logger.debug('Normal sms send')
        sendsmsfunction2(mobile, sms_template, name=name,
                         student_mobile=potential.mobile)
    logger.removeHandler(ch)


def check_remark(querys, remarker_filters, start_hours):
    '''
    @return: {uid: [potential_ids]}}
    '''
    now = datetime.now()
    result_dict = defaultdict(list)
    remark_dict = defaultdict(list)
    potential_dict = {i.id: (i.uid, i.alloc_at) for i in querys}
    remarks = Advisor_student_remark.objects.filter(
        remarker_filters, potential_id__in=potential_dict)
    [remark_dict[remark.potential_id].append(remark) for remark in remarks]
    no_remark = set(potential_dict) - set(remark_dict)
    [remark_dict[pid].extend([]) for pid in no_remark]

    for potential_id, remarks in remark_dict.items():
        expired = True
        remark_start = potential_dict[potential_id][1]

        if start_hours:
            # 3 5 10 30
            # eg. potential entry at first day 14:00
            # remark check conditions: create_at> second day 23:59
            remark_start = remark_start + timedelta(hours=start_hours + 8)
            remark_day = remark_start.strftime('%Y%m%d')
            remark_start = datetime.strptime(
                '{} 155959'.format(remark_day), '%Y%m%d %H%M%S')
            reason = get_date_range(remark_day, now.strftime('%Y%m%d'))
        else:
            reason = []
            reason.append(
                (remark_start + timedelta(days=1, hours=8)).strftime('%Y%m%d'))

        # Translate offset-aware to offset-naive
        remark_start = remark_start.replace(tzinfo=timezone.utc)
        for remark in remarks:
            if remark.create_at > remark_start:
                expired = False
                break

        if expired:
            result_dict[potential_dict[potential_id][0]].append(
                {potential_id: reason})

    return(result_dict)


def sync_advisor_score(data_dict):
    '''sync advisor score table

       @param data_dict: {uid: {level: [potential_ids]}}
       @param levels: days level
    '''
    expire_levels = {
        1: 'new_1',
        2: 'new_3',
        # 3: 'new_5',  # Delete 3-5 days 2016-03-10
        3: 'new_10',
        4: 'new_long',
        }

    sync_advisor(True)

    for advisor_uid, levels_dict in data_dict.items():
        advisor_score = Advisor_score.objects.get(advisor_uid=advisor_uid)
        # Get potential_ids of one advisor
        for level, potential_ids in levels_dict.items():
            # Translate list to support TextField
            expire_potentials = json.dumps(potential_ids)
            setattr(advisor_score, expire_levels[level], expire_potentials)

        advisor_score.save()


def sync_soon_expire(soon_expire_dict):
    '''Save potential's expire time to Advisor_potential_student

    @ param soon_expire_dict: {level: [pids]}
    '''
    # day_map = {1: 1, 2: 3, 3: 5, 4: 10, 5: 30}
    day_map = {1: 1, 2: 3, 3: 10, 4: 30}  # Delete 3-5 days 2016-03-10
    now = timezone.now()
    for level, pids in soon_expire_dict.items():
        pids = [d.keys()[0] for d in pids]
        potentials = Advisor_potential_student.objects.filter(
            Q(expire_time__lte=now) | Q(expire_time__isnull=True), id__in=pids)
        for potential in potentials:
            expire_time = potential.alloc_at + timedelta(
                days=day_map[level], hours=8)

            expire_day = expire_time.strftime('%Y%m%d')
            expire_time = datetime.strptime(
                '{} 155959'.format(expire_day), '%Y%m%d %H%M%S')
            potential.expire_time = expire_time.replace(tzinfo=timezone.utc)
            potential.expire_level = day_map[level]
            potential.save()


def sync_advisor(save=False):
    '''Synchronous advisors from Advisor_info to Advisor_score
    '''
    advisor_uids = [i['uid'] for i in Advisor_info.objects.values('uid')]
    score_uids = [i['advisor_uid'] for i in
                  Advisor_score.objects.values('advisor_uid')]

    new_uids = set(advisor_uids) - set(score_uids)
    for uid in new_uids:
        advisor_score_serializer = AdvisorScoreSerializer(
            data={'advisor_uid': uid})
        if advisor_score_serializer.is_valid() and save:
            advisor_score_serializer.save()
        else:
            print(advisor_score_serializer.errors)


def resource_to_crm():
    """将resourcetocrm表的数据推送到CRM
    """
    qs = ResourceToCrm.objects.filter(flag=0)
    for one in qs:
        insert_data = dict()
        update_keys = (
            'name', 'sex', 'mobile', 'phone', 'other_phone',
            'attribution', 'planning_year',
            'apply_contry', 'apply_education', 'graduate_school',
            'current_education', 'gpa_performance', 'average_score',
            'level_adjust', 'comefrom', 'xifenqudao', 'qudao_details',
            'follow_person', 'remark', 'create_user')
        for key in update_keys:
            insert_data[key] = getattr(one, key)

        res = MyCrmComm().crm_potential_info_update(insert_data)
        if res:
            one.flag = 1
        else:
            one.flag = 2
        one.save()
