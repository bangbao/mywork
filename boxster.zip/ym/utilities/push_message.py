# coding: utf-8

from rest_framework.decorators import api_view as rest_api_view
from shunlib.redis_model import HashModel
from shunlib.redis_model import ListModel
from ym.apps.user.models import Users


class MessageCache(HashModel):
    pass


class MessageQueue(ListModel):
    pass

IGNORE_METHOD = ()


def api_view(http_method_names=None):
    def decorator(func):
        def handler(*args, **kwargs):
            rest_api = rest_api_view(http_method_names)
            rest_method = rest_api(func)
            response = rest_method(*args, **kwargs)
            if response.status_code != 200:
                return response
            request = args[0]
            path_name = request.path.split('/')[1]
            method_name = request.path.split('/')[2]
            if method_name in IGNORE_METHOD:
                return response

#             if path_name == "ym":
#                 uid = getattr(request, "uid", None)
#                 if uid:
#                     try:
#                         user = Users.objects.get(uid=uid)
#                         user_type = user.user_type if user.user_type else "学生"
#                         check_message(uid, user_type, response)
#                     except:
#                         return response
            return response
        return handler
    return decorator
