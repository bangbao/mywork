# coding: utf-8

import base64
import json
import hashlib
import requests
from urllib import quote_plus

parternID = '123456'


# def save_failed(data_dict, reason):
#     failed = PushCrmFailed()
#     failed.name = data_dict.get('name', '')
#     failed.mobile = data_dict.get('mobile', '')
#     failed.reason = reason
#     failed.save()


def is_prd():
    """return whether PRD environment
    """
    from django.conf import settings
    return getattr(settings, 'IS_PROD', False)


class MyCrmComm():

    def crm_potential_info_update(self, update_info, return_reason=False):
        if not is_prd():
            print 'Not PROD, break send data to crm'
            return True

        try:
            update_info['msgtype'] = 2
            update_info_string = str(json.dumps(update_info))
            print update_info_string
            update_info_string_url_encode = quote_plus(update_info_string)
            update_info_string_url_encode_bs64 = base64.b64encode(update_info_string_url_encode)
            post_data = dict()
            post_data['logistics_interface'] = update_info_string_url_encode_bs64
            update_info_string_code = update_info_string+parternID
            update_info_string_code_md5 = hashlib.md5(update_info_string_code).hexdigest()
            update_info_string_code_md5_base64 = base64.b64encode(update_info_string_code_md5)
            update_info_string_code_md5_base64_urlencode = quote_plus(update_info_string_code_md5_base64)
            post_data['data_digest'] = update_info_string_code_md5_base64_urlencode
            post_data['msg_type'] = 'crminfoperate'
            post_data['eccompanyid'] = 'qdjy'

            resp = requests.post('http://183.239.189.114:8091/userweb/interface/crminterface.php', data=post_data, allow_redirects=True)
            # mystr = '{"cuscode": "086","success": "True","reason": ""}'
            print resp.text
            result_json = json.loads(resp.text)
            if return_reason:
                print "success"
                return result_json['reason']
            if result_json['success'] == 'True':
                print "sent to crm"
                return True
            else:
                # Waiting for potentials retry module
                # save_failed(update_info, result_json['reason'])
                return False
        except Exception, e:
            print e.message
            # Waiting for potentials retry module
            # save_failed(update_info, e.message)
            return False

    def push_crm_user_info_data(self, crm_user_info_obj):
        obj = crm_user_info_obj
        update_data = dict()
        if obj.cuscode:
            update_data['cuscode'] = obj.cuscode
            update_data['phone'] = obj.phone
            update_data['other_phone'] = obj.other_phone
            update_data['latest_status'] = obj.latest_status
            update_data['follow_person'] = obj.follow_person
            update_data['follow_road'] = obj.follow_road
            update_data['remark'] = obj.remark
        else:
            update_data['cuscode'] = obj.cuscode
            update_data['name'] = obj.name
            update_data['mobile'] = obj.mobile
            update_data['phone'] = obj.phone
            update_data['other_phone'] = obj.other_phone
            update_data['comefrom'] = obj.comefrom
            update_data['create_user'] = obj.create_user
            update_data['line_item'] = obj.line_item
            update_data['sex'] = obj.sex
            update_data['age'] = obj.age
            update_data['attribution'] = obj.attribution
            update_data['level_adjust'] = obj.level_adjust
            update_data['latest_status'] = obj.latest_status
            update_data['graduate_school'] = obj.graduate_school
            update_data['planning_year'] = obj.planning_year
            update_data['follow_person'] = obj.follow_person
            update_data['apply_contry'] = obj.apply_contry
            update_data['target_school'] = obj.target_school
            update_data['branch_company'] = obj.branch_company
            update_data['current_education'] = obj.current_education
            update_data['current_professional'] = obj.current_professional
            update_data['gpa_performance'] = obj.gpa_performance
            update_data['average_score'] = obj.average_score
            update_data['follow_road'] = obj.follow_road
            update_data['apply_education'] = obj.apply_education
            update_data['current_grade'] = obj.current_grade
            update_data['qq'] = obj.qq
            update_data['apply_professional'] = obj.apply_professional
            update_data['comefrompoint'] = obj.comefrompoint
            update_data['email'] = obj.email
            update_data['create_time'] = obj.create_time
            update_data['origin_id'] = obj.origin_id
            update_data['current_grade'] = obj.current_grade
            update_data['remark'] = obj.remark
            update_data['contacts_type'] = obj.contacts_type
            update_data['contacts_name'] = obj.contacts_name
            update_data['wechat'] = obj.wechat
            update_data['convenient_time'] = obj.convenient_time
            update_data['business_unit'] = obj.business_unit
            update_data['xifenqudao'] = obj.xifenqudao
        result = self.crm_potential_info_update(update_data)
        return result

