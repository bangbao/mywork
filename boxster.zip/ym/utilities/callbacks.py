# coding: utf-8

import datetime
import requests
from django.utils import timezone
# from django.db.models.signals import post_save, pre_save
# from django.dispatch import receiver
from django.conf import settings


def check_potential_change(sender, instance, **kwargs):
    """检查意向客户表的变化
    """
    if not hasattr(instance, "_init_instance"):
        return
    if str(instance._init_instance.uid) != str(instance.uid):
        instance.alloc_at = timezone.now()
    if str(instance._init_instance.status) == str(instance.status):
        return
    # Commit by Stephen 2015-11-18
    # if str(instance.status) == '11':
    #     # 检查状态被修改为“再激活”
    #     advisor = Advisor_info.objects.get(uid=int(instance.uid))
    #     mobile = advisor.mobile
    #     if mobile:
    #         content = '客户 {}（{}） 已重新激活，请登陆crp查看'
    #         content = content.format(instance.user_name, instance.mobile)
    #         sendsmsfunction(mobile, content)
    if instance.xifenqudao in (u'口碑推荐', u'留学客户宝'):
        # 将变化推送给客户宝
        kehubao_api = settings.KEHUBAO_SYNC_API
        status_text = settings.SOURCE_STATUS.get(int(instance.status))
        post_data = {"mobile": instance.mobile,
                     "status": status_text, }
        try:
            resp = requests.put(kehubao_api, data=post_data)
        except requests.ConnectionError, e:
            print '>>> ERROR: KeHuBao sync failed!!'
            print e
        return resp


def update_crm_resource(sender, instance, created, **kwargs):
    from ym.apps.potential.models import Advisor_info, Advisor_student_remark
    from ym.apps.potential.models import Advisor_potential_student
    from ym.apps.crm.models import Crm_User_info
    from ym.apps.crm.serializers import CrmUserInfoSerializer

    print '>>> post_save'
    try:
        potential = Advisor_potential_student.objects.get(id=instance.id)
    except Advisor_potential_student.DoesNotExist:
        print "[update_crm_resource] advisor does not exist"
        return "advisor does not exist"

    mobile = potential.mobile
    print "[update_crm_resource] pid:", potential.id, "mobile:", mobile
    crm_user_info_list = Crm_User_info.objects.filter(mobile=mobile, flag=1)
    if not crm_user_info_list.exists():
        print "[update_crm_resource] crm_user_info_list not exists"
        if potential.comefrom:
            print "[update_crm_resource] comefrom exists."
            if potential.comefrom in ('顾问口碑', '在线资源'):
                print "[update_crm_resource] comefrom 'zaixianziyuan'"
                crm_return_insert = dict()
                advisor_query = Advisor_info.objects.get(uid=potential.uid)
                if advisor_query.full_name:
                    crm_return_insert['follow_person'] = advisor_query.full_name
                if potential.full_name:
                    crm_return_insert['name'] = potential.full_name
                if potential.mobile:
                    crm_return_insert['mobile'] = potential.mobile
                if potential.phone:
                    crm_return_insert['phone'] = potential.phone
                if potential.other_phone:
                    crm_return_insert['other_phone'] = potential.other_phone
                if potential.gender:
                    crm_return_insert['sex'] = potential.gender
                if potential.country:
                    crm_return_insert['apply_contry'] = potential.country
                if potential.current_school:
                    crm_return_insert['graduate_school'] = potential.current_school
                if potential.gpa:
                    crm_return_insert['gpa_performance'] = potential.gpa
                if potential.education:
                    crm_return_insert['current_education'] = potential.education
                if potential.status:
                    if str(potential.status) == '0':
                        crm_return_insert['latest_status'] = '未跟进'
                    elif str(potential.status) == '10':
                        crm_return_insert['latest_status'] = '已放弃'
                    elif str(potential.status) == '11':
                        crm_return_insert['latest_status'] = '再激活'
                    else:
                        crm_return_insert['latest_status'] = '已跟进'
                crm_return_insert['create_user'] = '9001'
                crm_return_insert['crm_update_flag'] = 1
                crm_return_insert['level_adjust'] = 3
                crm_return_insert['flag'] = 1
                crm_return_insert['comefrom'] = potential.comefrom
                crm_return_insert['xifenqudao'] = potential.xifenqudao
                crm_return_insert['qudao_details'] = potential.qudao_details
                remarks_query = Advisor_student_remark.objects.filter(
                    potential_id=potential.id)
                try:
                    crm_return_insert['remark'] = remarks_query[0].content
                except IndexError:
                    crm_return_insert['remark'] = ''
                crm_insert_serializer = CrmUserInfoSerializer(
                    data=crm_return_insert, partial=True)
                if crm_insert_serializer.is_valid():
                    crm_insert_serializer.save()
                    print "[update_crm_resource] save 1"
                else:
                    crm_insert_serializer.save()
                    print "[update_crm_resource] save 2"
        return

    for crm_user_info in crm_user_info_list:
        print "[update_crm_resource] crm_user_info.id:", crm_user_info.id
        if potential.uid:
            try:
                advisor_query = Advisor_info.objects.get(uid=potential.uid)
                if advisor_query.full_name:
                    crm_user_info.follow_person = advisor_query.full_name
            except Advisor_info.DoesNotExist:
                print "[update_crm_resource] advisor name error"
        if potential.status:
            print "[update_crm_resource] potential_student.status:", potential.status
            if str(potential.status) == '0':
                crm_user_info.latest_status = '未跟进'
                if crm_user_info.follow_road:
                    crm_user_info.follow_road += "->未跟进"
                else:
                    crm_user_info.follow_road = "未跟进"
            elif str(potential.status) == '10':
                crm_user_info.latest_status = '已放弃'
                if crm_user_info.follow_road:
                    crm_user_info.follow_road += "->已放弃"
                else:
                    crm_user_info.follow_road = "已放弃"
            elif str(potential.status) == '11':
                crm_user_info.latest_status = '再激活'
                if crm_user_info.follow_road:
                    crm_user_info.follow_road += "->再激活"
                else:
                    crm_user_info.follow_road = "已放弃"
            elif str(potential.status) == '66':
                crm_user_info.latest_status = '已签约'
                if crm_user_info.follow_road:
                    crm_user_info.follow_road += "->已签约"
                else:
                    crm_user_info.follow_road = "已签约"
            else:
                crm_user_info.latest_status = '已跟进'
                if crm_user_info.follow_road:
                    crm_user_info.follow_road += "->已跟进"
                else:
                    crm_user_info.follow_road = "已跟进"
        if potential.current_school:
            crm_user_info.graduate_school = str(potential.current_school)
        if potential.country:
            crm_user_info.apply_contry = str(potential.country)
        if potential.education:
            crm_user_info.apply_education = str(potential.education)
        if potential.full_name:
            crm_user_info.name = str(potential.full_name)
        if potential.phone:
            crm_user_info.phone = str(potential.phone)
        if potential.other_phone:
            crm_user_info.other_phone = str(potential.other_phone)
        if potential.is_chosen:
            crm_user_info.latest_status = '已签约'
            if crm_user_info.follow_road:
                crm_user_info.follow_road = crm_user_info.follow_road + "->已签约"
            else:
                crm_user_info.follow_road = "已签约"
        if potential.current_grade:
            crm_user_info.current_grade = potential.current_grade
        crm_user_info.crm_update_flag = 1
        remarks_query = Advisor_student_remark.objects.filter(
            potential_id=potential.id)
        try:
            crm_user_info.remark = remarks_query[0].content
        except IndexError:
            crm_user_info.remark = ''
        crm_user_info.save()
        print "[update_crm_resource] crm_user_info saved."
    print "[update_crm_resource] ENDED."
