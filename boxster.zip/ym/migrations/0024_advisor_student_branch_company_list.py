# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0023_auto_20160414_1107'),
    ]

    operations = [
        migrations.CreateModel(
            name='Advisor_student_branch_company_list',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('text', models.CharField(max_length=32, null=True, verbose_name=b'text')),
                ('value', models.CharField(max_length=32, null=True, verbose_name=b'value')),
            ],
            options={
                'verbose_name': '\u5206\u516c\u53f8\u540d\u4e0b\u62c9\u8868',
                'verbose_name_plural': '\u5206\u516c\u53f8\u540d\u4e0b\u62c9\u8868',
            },
        ),
    ]
