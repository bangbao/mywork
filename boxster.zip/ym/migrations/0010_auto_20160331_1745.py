# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0009_auto_20160331_1738'),
    ]

    operations = [
        migrations.AddField(
            model_name='resourcetocrm',
            name='line_item',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='wap_page',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='wap_source',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='create_user',
            field=models.CharField(default=b'9003', max_length=12, null=True),
        ),
    ]
