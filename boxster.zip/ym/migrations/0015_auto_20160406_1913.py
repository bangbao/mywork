# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0014_auto_20160401_1821'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_info',
            name='crp_advisor_id',
            field=models.IntegerField(null=True),
        ),
        migrations.AddField(
            model_name='advisor_infoauditlogentry',
            name='crp_advisor_id',
            field=models.IntegerField(null=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_student',
            name='crp_potential_id',
            field=models.IntegerField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='crp_potential_id',
            field=models.IntegerField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='crp_potential_id',
            field=models.IntegerField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='crp_potential_id',
            field=models.IntegerField(null=True, blank=True),
        ),
    ]
