# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0022_auto_20160413_1333'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_potential_student',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_student',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_student',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_student',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='ym_mobile',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='resourcetocrm',
            name='ym_username',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
    ]
