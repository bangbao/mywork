# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0034_userlevel'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_potential_student',
            name='is_push_crp',
            field=models.NullBooleanField(default=False),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='is_push_crp',
            field=models.NullBooleanField(default=False),
        ),
    ]
