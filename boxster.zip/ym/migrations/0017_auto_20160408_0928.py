# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0016_auto_20160407_1911'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='advisor_student_remark',
            name='bi_user_id',
        ),
        migrations.RemoveField(
            model_name='advisor_student_remark',
            name='ipaddr',
        ),
        migrations.RemoveField(
            model_name='advisor_student_remark',
            name='student_uid',
        ),
    ]
