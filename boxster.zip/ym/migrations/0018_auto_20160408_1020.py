# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0017_auto_20160408_0928'),
    ]

    operations = [
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='expendable_fund',
            field=models.IntegerField(default=0, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='gross_assets',
            field=models.IntegerField(default=0, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='expendable_fund',
            field=models.IntegerField(default=0, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='gross_assets',
            field=models.IntegerField(default=0, null=True),
        ),
    ]
