# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0004_advisor_student_program_potential_foreign'),
    ]

    operations = [
        migrations.AlterField(
            model_name='admission',
            name='badge',
            field=models.ImageField(null=True, upload_to=b'/Users/zyw/work/boxster/media/badge', blank=True),
        ),
    ]
