# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0006_auto_20160330_1442'),
    ]

    operations = [
        migrations.CreateModel(
            name='Advisor_student_country_program_list',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('country', models.CharField(max_length=32, null=True, verbose_name=b'country')),
                ('category', models.CharField(max_length=32, null=True, verbose_name=b'category')),
                ('program', models.CharField(max_length=64, null=True, verbose_name=b'program')),
            ],
            options={
                'verbose_name': '\u79fb\u6c11\u56fd\u5bb6\u9879\u76ee\u5217\u8868',
                'verbose_name_plural': '\u79fb\u6c11\u56fd\u5bb6\u9879\u76ee\u5217\u8868',
            },
        ),
    ]
