# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0020_auto_20160412_1113'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_student_remark',
            name='potential_foreign',
            field=models.ForeignKey(related_name='related_remarks', to='ym.Advisor_potential_student', null=True),
        ),
    ]
