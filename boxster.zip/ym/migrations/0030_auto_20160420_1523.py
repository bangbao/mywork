# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0029_advisor_student_bm_experience_list'),
    ]

    operations = [
        migrations.AlterField(
            model_name='resourcetocrm',
            name='comefrom',
            field=models.CharField(max_length=50, null=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='xifenqudao',
            field=models.CharField(max_length=50, null=True),
        ),
    ]
