# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0032_auto_20160429_0921'),
    ]

    operations = [
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='attribution',
            field=models.CharField(max_length=20, null=True, verbose_name='\u7528\u6237\u6240\u5728\u5730', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5546\u4e1a\u7ba1\u7406\u7ecf\u9a8c'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='create_at',
            field=models.DateTimeField(auto_now_add=True, verbose_name='\u5f55\u5165\u65f6\u95f4'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='crp_potential_id',
            field=models.IntegerField(null=True, verbose_name='crp\u63a8\u9001\u8d44\u6e90id', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='expendable_fund',
            field=models.IntegerField(default=0, null=True, verbose_name='\u53ef\u7528\u8d44\u91d1'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='follow_person',
            field=models.CharField(max_length=32, null=True, verbose_name='\u8ddf\u8fdb\u987e\u95ee'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='follow_status',
            field=models.IntegerField(default=0, null=True, verbose_name='\u8ddf\u8fdb\u72b6\u6001'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='full_name',
            field=models.CharField(max_length=40, null=True, verbose_name='\u59d3\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='gross_assets',
            field=models.IntegerField(default=0, null=True, verbose_name='\u603b\u8d44\u4ea7'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='linguistic_competence',
            field=models.CharField(max_length=32, null=True, verbose_name='\u8bed\u8a00\u80fd\u529b'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='marital_status',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5a5a\u59fb\u72b6\u51b5'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u7535\u8bdd', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='rate',
            field=models.IntegerField(default=1, null=True, verbose_name='\u661f\u7ea7'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u6240\u5c5e\u5206\u516c\u53f8', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u6240\u5c5e\u90e8\u95e8', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u7535\u8bdd', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, verbose_name='\u63a8\u8350\u4eba\u59d3\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='wechat',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5fae\u4fe1', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='ym_mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u79fb\u6c11\u8054\u7cfb\u4eba\u8054\u7cfb\u65b9\u5f0f', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='ym_username',
            field=models.CharField(max_length=30, null=True, verbose_name='\u79fb\u6c11\u8054\u7cfb\u4eba\u59d3\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='attribution',
            field=models.CharField(max_length=20, null=True, verbose_name='\u7528\u6237\u6240\u5728\u5730', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5546\u4e1a\u7ba1\u7406\u7ecf\u9a8c'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='create_at',
            field=models.DateTimeField(auto_now_add=True, verbose_name='\u5f55\u5165\u65f6\u95f4'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='crp_potential_id',
            field=models.IntegerField(null=True, verbose_name='crp\u63a8\u9001\u8d44\u6e90id', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='expendable_fund',
            field=models.IntegerField(default=0, null=True, verbose_name='\u53ef\u7528\u8d44\u91d1'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='follow_person',
            field=models.CharField(max_length=32, null=True, verbose_name='\u8ddf\u8fdb\u987e\u95ee'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='follow_status',
            field=models.IntegerField(default=0, null=True, verbose_name='\u8ddf\u8fdb\u72b6\u6001'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='full_name',
            field=models.CharField(max_length=40, null=True, verbose_name='\u59d3\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='gross_assets',
            field=models.IntegerField(default=0, null=True, verbose_name='\u603b\u8d44\u4ea7'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='linguistic_competence',
            field=models.CharField(max_length=32, null=True, verbose_name='\u8bed\u8a00\u80fd\u529b'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='marital_status',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5a5a\u59fb\u72b6\u51b5'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u7535\u8bdd', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='rate',
            field=models.IntegerField(default=1, null=True, verbose_name='\u661f\u7ea7'),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_branch',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u6240\u5c5e\u5206\u516c\u53f8', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_depart',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u6240\u5c5e\u90e8\u95e8', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u63a8\u8350\u4eba\u7535\u8bdd', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='tuijian_name',
            field=models.CharField(max_length=30, null=True, verbose_name='\u63a8\u8350\u4eba\u59d3\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='wechat',
            field=models.CharField(max_length=32, null=True, verbose_name='\u5fae\u4fe1', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='ym_mobile',
            field=models.CharField(max_length=20, null=True, verbose_name='\u79fb\u6c11\u8054\u7cfb\u4eba\u8054\u7cfb\u65b9\u5f0f', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='ym_username',
            field=models.CharField(max_length=30, null=True, verbose_name='\u79fb\u6c11\u8054\u7cfb\u4eba\u59d3\u540d', blank=True),
        ),
    ]
