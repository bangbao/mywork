# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0035_auto_20160615_1053'),
    ]

    operations = [
        migrations.CreateModel(
            name='GroupLevel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('parent_id', models.CharField(max_length=128, null=True, verbose_name='\u4e0a\u7ea7key', blank=True)),
                ('group', models.OneToOneField(to='ym.Group')),
            ],
        ),
    ]
