# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0013_auto_20160401_0940'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_potential_student',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True),
        ),
    ]
