# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0015_auto_20160406_1913'),
    ]

    operations = [
        migrations.AddField(
            model_name='crm_user_info',
            name='apply_program',
            field=models.CharField(max_length=64, null=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='expendable_fund',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='crm_user_info',
            name='gross_assets',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='apply_program',
            field=models.CharField(max_length=64, null=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='bm_experience',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='expendable_fund',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='crm_user_infoauditlogentry',
            name='gross_assets',
            field=models.IntegerField(default=0),
        ),
    ]
