# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0021_advisor_student_remark_potential_foreign'),
    ]

    operations = [
        migrations.AlterField(
            model_name='advisor_potential_student',
            name='rate',
            field=models.IntegerField(default=1, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_potential_studentauditlogentry',
            name='rate',
            field=models.IntegerField(default=1, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_student_country',
            name='potential_foreign',
            field=models.ForeignKey(related_name='related_countries', to='ym.Advisor_potential_student', null=True),
        ),
        migrations.AlterField(
            model_name='advisor_student_program',
            name='potential_foreign',
            field=models.ForeignKey(related_name='related_programs', to='ym.Advisor_potential_student', null=True),
        ),
    ]
