# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0011_auto_20160331_1924'),
    ]

    operations = [
        migrations.AlterField(
            model_name='crm_user_info',
            name='create_time',
            field=models.DateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='crm_user_infoauditlogentry',
            name='create_time',
            field=models.DateTimeField(auto_now_add=True),
        ),
    ]
