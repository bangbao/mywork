# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0025_auto_20160414_1803'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_potential_student',
            name='attribution',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='advisor_potential_studentauditlogentry',
            name='attribution',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
    ]
