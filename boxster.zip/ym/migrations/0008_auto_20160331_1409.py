# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0007_advisor_student_country_program_list'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_student_program',
            name='country',
            field=models.CharField(max_length=32, null=True),
        ),
        migrations.AlterField(
            model_name='advisor_student_country',
            name='country',
            field=models.CharField(max_length=32, null=True, verbose_name='\u56fd\u5bb6'),
        ),
        migrations.AlterField(
            model_name='advisor_student_program',
            name='program',
            field=models.CharField(max_length=64, null=True),
        ),
    ]
