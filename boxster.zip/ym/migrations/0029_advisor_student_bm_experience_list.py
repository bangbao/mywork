# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0028_auto_20160418_1133'),
    ]

    operations = [
        migrations.CreateModel(
            name='Advisor_student_bm_experience_list',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('text', models.CharField(max_length=32, null=True, verbose_name=b'text')),
                ('value', models.CharField(max_length=32, null=True, verbose_name=b'value')),
            ],
            options={
                'verbose_name': '\u5546\u4e1a\u7ba1\u7406\u7ecf\u9a8c\u4e0b\u62c9\u5217\u8868',
                'verbose_name_plural': '\u5546\u4e1a\u7ba1\u7406\u7ecf\u9a8c\u4e0b\u62c9\u5217\u8868',
            },
        ),
    ]
