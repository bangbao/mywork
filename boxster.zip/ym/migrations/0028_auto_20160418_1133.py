# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0027_advisor_student_xifenqudao_list'),
    ]

    operations = [
        migrations.DeleteModel(
            name='Advisor_appointment',
        ),
        migrations.DeleteModel(
            name='Advisor_brand_info',
        ),
        migrations.DeleteModel(
            name='Advisor_education_info',
        ),
        migrations.DeleteModel(
            name='Advisor_service_tags',
        ),
        migrations.DeleteModel(
            name='ExperienceFeedback',
        ),
    ]
