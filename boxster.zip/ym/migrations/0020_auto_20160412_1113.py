# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0019_auto_20160411_1530'),
    ]

    operations = [
        migrations.RenameField(
            model_name='advisor_potential_student',
            old_name='appoint_advisor',
            new_name='follow_person',
        ),
        migrations.RenameField(
            model_name='advisor_potential_studentauditlogentry',
            old_name='appoint_advisor',
            new_name='follow_person',
        ),
    ]
