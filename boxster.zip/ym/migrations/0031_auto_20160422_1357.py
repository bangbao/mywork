# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0030_auto_20160420_1523'),
    ]

    operations = [
        migrations.AlterField(
            model_name='resourcetocrm',
            name='apply_contry',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='apply_education',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='attribution',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='average_score',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='comefrom',
            field=models.CharField(max_length=50, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='current_education',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='email',
            field=models.CharField(max_length=255, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='follow_person',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='gpa_performance',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='graduate_school',
            field=models.CharField(max_length=50, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='level_adjust',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='line_item',
            field=models.CharField(max_length=32, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='name',
            field=models.CharField(max_length=30, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='other_phone',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='phone',
            field=models.CharField(max_length=20, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='planning_year',
            field=models.CharField(max_length=10, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='qudao_details',
            field=models.CharField(max_length=32, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='remark',
            field=models.TextField(null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='sex',
            field=models.CharField(max_length=10, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='wap_page',
            field=models.CharField(max_length=32, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='wap_source',
            field=models.CharField(max_length=32, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='resourcetocrm',
            name='xifenqudao',
            field=models.CharField(max_length=50, null=True, blank=True),
        ),
    ]
