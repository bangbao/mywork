# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='admission',
            name='badge',
            field=models.ImageField(null=True, upload_to=b'/Users/zyw/work/boxster/boxster/media/badge', blank=True),
        ),
        migrations.AlterField(
            model_name='advisor_student_country',
            name='has_relatives',
            field=models.NullBooleanField(verbose_name='\u6709\u65e0\u4eb2\u5c5e'),
        ),
        migrations.AlterField(
            model_name='advisor_student_country',
            name='has_visa',
            field=models.NullBooleanField(verbose_name='\u6709\u65e0\u7b7e\u8bc1'),
        ),
    ]
