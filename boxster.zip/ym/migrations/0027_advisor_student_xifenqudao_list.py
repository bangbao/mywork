# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0026_auto_20160415_1403'),
    ]

    operations = [
        migrations.CreateModel(
            name='Advisor_student_xifenqudao_list',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('xifenqudao', models.CharField(max_length=32, null=True, verbose_name=b'xifenqudao')),
                ('comefrom', models.CharField(max_length=32, null=True, verbose_name=b'comefrom')),
            ],
            options={
                'verbose_name': '\u7ec6\u5206\u6e20\u9053\u8868',
                'verbose_name_plural': '\u7ec6\u5206\u6e20\u9053\u8868',
            },
        ),
    ]
