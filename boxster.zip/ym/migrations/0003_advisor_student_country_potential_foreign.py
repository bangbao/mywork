# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('ym', '0002_auto_20160322_1005'),
    ]

    operations = [
        migrations.AddField(
            model_name='advisor_student_country',
            name='potential_foreign',
            field=models.ForeignKey(related_name='applied_countries', to='ym.Advisor_potential_student', null=True),
        ),
    ]
