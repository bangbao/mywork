# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings
import shunlib.djhelper.base_model


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('ym', '0031_auto_20160422_1357'),
    ]

    operations = [
        migrations.CreateModel(
            name='Group',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=32)),
            ],
        ),
        migrations.CreateModel(
            name='GroupPerm',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('group', models.ForeignKey(related_name='related_groupperm', to='ym.Group', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Perm',
            fields=[
                ('codename', models.CharField(max_length=32, serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=32)),
            ],
        ),
        migrations.CreateModel(
            name='UserGroup',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('group', models.ForeignKey(related_name='related_usergroup', to='ym.Group', null=True)),
                ('user', models.ForeignKey(related_name='related_usergroup', to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='UserPerm',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('perm', models.ForeignKey(related_name='related_userperm', to='ym.Perm', null=True)),
                ('user', models.ForeignKey(related_name='related_userperm', to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
        migrations.DeleteModel(
            name='User_Follow',
        ),
        migrations.DeleteModel(
            name='User_info',
        ),
        migrations.RemoveField(
            model_name='users',
            name='agree_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='answer_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='birthday',
        ),
        migrations.RemoveField(
            model_name='users',
            name='fans_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='friend_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='invite_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='last_week_agree_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='password',
        ),
        migrations.RemoveField(
            model_name='users',
            name='province',
        ),
        migrations.RemoveField(
            model_name='users',
            name='question_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='recent_topics',
        ),
        migrations.RemoveField(
            model_name='users',
            name='reg_time',
        ),
        migrations.RemoveField(
            model_name='users',
            name='reputation',
        ),
        migrations.RemoveField(
            model_name='users',
            name='salt',
        ),
        migrations.RemoveField(
            model_name='users',
            name='thanks_count',
        ),
        migrations.RemoveField(
            model_name='users',
            name='views_count',
        ),
        migrations.AddField(
            model_name='users',
            name='attribution',
            field=models.CharField(max_length=128, null=True, verbose_name='\u5206\u516c\u53f8', blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='country',
            field=models.CharField(max_length=128, null=True, verbose_name='\u56fd\u5bb6', blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='levels',
            field=shunlib.djhelper.base_model.JSONField(null=True, verbose_name='\u5458\u5de5\u89d2\u8272', blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='name',
            field=models.CharField(max_length=128, null=True, verbose_name='\u5458\u5de5\u59d3\u540d', blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='sync_time',
            field=models.DateTimeField(max_length=20, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='sysid',
            field=models.IntegerField(null=True, verbose_name='\u5458\u5de5\u7f16\u53f7', blank=True),
        ),
        migrations.AddField(
            model_name='users',
            name='title',
            field=models.CharField(max_length=128, null=True, verbose_name='\u5c97\u4f4d', blank=True),
        ),
        migrations.AlterField(
            model_name='users',
            name='sex',
            field=models.CharField(max_length=12, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='users',
            name='user_type',
            field=models.CharField(max_length=10, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='groupperm',
            name='perm',
            field=models.ForeignKey(related_name='related_groupperm', to='ym.Perm', null=True),
        ),
    ]
