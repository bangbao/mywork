# coding: utf-8

from django.contrib import admin
from django.conf import settings
from django.conf.urls import include, url
from django.conf.urls.static import static
from ym.apps.user import views as user_views
from ym.apps.crm import views as crm_views
from ym.apps.option import views as option_views
from ym.apps.potential import views as potential_views
from ym.apps.adm import views as adm_views
from ym.apps.perm import views as perm_views


extra_urlpatterns = [
    url(r'^dtp/login/$', user_views.dtp_login),
    url(r'^dtp/sync_user_info/$', user_views.dtp_sync_user_info),
    url(r'^temp_login/$', user_views.userlogin),
    url(r'^logout/', user_views.userlogout),
    url(r'^auth/', user_views.get_auth),
    url(r'^crm_potential_user', crm_views.crm_potential_insert),
    url(r'^crp_potential_user/$', crm_views.crp_potential_insert),
    url(r'^crp_potential_info/$', crm_views.crp_potential_info),
    url(r'^crp_option_info/$', crm_views.crp_option_info),

    url(r'^countries/$', option_views.countries_list),
    url(r'^programs/$', option_views.programs_list),
    url(r'^linguistic_competences/$', option_views.linguistic_competences_list),
    url(r'^marital_statuses/$', option_views.marital_statuses_list),
    url(r'^follow_statuses/$', option_views.follow_statuses_list),
    url(r'^statuses/$', option_views.statuses_list),
    url(r'^country_types/$', option_views.country_types_list),
    url(r'^program_types/$', option_views.program_types_list),
    url(r'^comefroms/$', option_views.comefroms_list),
    url(r'^countries_programs/$', option_views.countries_programs_list),
    url(r'^branch_companies/$', option_views.branch_companies_list),
    url(r'^mobile_attribution/$', option_views.mobile_attribution),
    url(r'^xifenqudaos/$', option_views.xifenqudaos_list),
    url(r'^bm_experiences/$', option_views.bm_experiences_list),

    url(r'^potential/searchadvisors/$', potential_views.searchadvisors),
    url(r'^potential/appoint_advisor/$', potential_views.appoint_advisor),
    url(r'^advisor_potential_add/$', potential_views.advisor_potential_add),
    url(r'^potential_countries_programs/$',
        potential_views.potential_country_program_add),
    url(r'^potential_countries_programs/(?P<country_id>[0-9]+)/$',
        potential_views.potential_country_program_handle),

    url(r'^advisor_potentials/$',
        potential_views.advisor_potential_student_list),
    url(r'^advisor_potentials/(?P<potential_id>[0-9]+)/$',
        potential_views.advisor_potential_student_handle),
    url(r'^advisor_potentials/(?P<potential_id>[0-9]+)/sign/$',
        potential_views.advisor_potential_student_sign),
    url(r'^advisor_potentials.xlsx$',
        potential_views.advisor_potential_export_xlsx),

    url(r'^potential_remarks/$',
        potential_views.advisor_student_remark),
    url(r'^potential_applied_countries/$',
        potential_views.advisor_student_country),
    url(r'^potential_applied_countries/(?P<cid>[0-9]+)/$',
        potential_views.advisor_student_country_handle),
    url(r'^potential_applied_programs/$',
        potential_views.advisor_student_program),
    url(r'^potential_applied_programs/(?P<pid>[0-9]+)/$',
        potential_views.advisor_student_program_handle),
    url(r'^potential/push_to_crp_info/$', potential_views.push_to_crp_info),
    url(r'^potential/push_to_crp/$', potential_views.push_to_crp),
    url(r'^potential/get_crp_remarks/$', potential_views.get_crp_remarks),

    url(r'adm/staff_attributions/$', adm_views.staff_attributions),
    url(r'adm/staff_countries/$', adm_views.staff_countries),
    url(r'adm/staff_titles/$', adm_views.staff_titles),
    url(r'adm/staff_list/$', adm_views.staff_list),
    url(r'adm/staff_info/$', adm_views.staff_info),
    url(r'adm/staff_set_perm/$', adm_views.staff_set_perm),
    url(r'adm/staff_active_list/$', adm_views.staff_active_list),
    url(r'adm/staff_active/$', adm_views.staff_active),
    url(r'adm/staff_freeze/$', adm_views.staff_freeze),

    url(r'perm/perm_list/$', perm_views.perm_list),
    url(r'perm/group_list/$', perm_views.group_list),
    url(r'perm/group_info/$', perm_views.group_info),
    url(r'perm/group_edit/$', perm_views.group_edit),
    url(r'perm/group_add/$', perm_views.group_add),
    url(r'perm/group_delete/$', perm_views.group_delete),
]

urlpatterns = [
    url(r'^ym/', include(extra_urlpatterns)),
    url(r'^ydm/', include(admin.site.urls)),
]

urlpatterns += static(settings.FILE_URL, document_root=settings.UPLOAD_ROOT)
