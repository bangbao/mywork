# coding: utf-8

DEBUG = True
IS_PROD = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        # 测试环境
        'NAME': 'boxster',
        'USER': 'liuyuxiao',
        'PASSWORD': '19900410lyX',
        'HOST': 'testcrprds.mysql.rds.aliyuncs.com',
        'PORT': '3306',
    },
}

DTP_HOST = "http://123.57.72.210:9002"
CRP_HOST = "http://crpapitest.shunshunliuxue.com:7001"

# LOGGING = {
#     'version': 1,
#     'disable_existing_loggers': False,
#     'handlers': {
#         'console':{
#             'level': 'DEBUG',
#             'class': 'logging.StreamHandler',
#         },
#     },
#     'loggers': {
#         'django.db.backends': {
#             'handlers': ['console'],
#             'propagate': True,
#             'level': 'DEBUG',
#         },
#     }
# }
