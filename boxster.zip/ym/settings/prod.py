# coding: utf-8

DEBUG = False
IS_PROD = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        # 正式环境
        'NAME': 'boxster',
        'USER': 'liling',
        'PASSWORD': 'awsqpzlyX123',
        'HOST': 'rds6yh9rwvu69xwerx0qo.mysql.rds.aliyuncs.com',
        'PORT': '3306',
    },
}
